package discord4j.core.spec;

import com.google.errorprone.annotations.Var;
import discord4j.core.object.entity.Guild;
import discord4j.discordjson.possible.Possible;
import discord4j.rest.util.Color;
import discord4j.rest.util.PermissionSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.immutables.value.Generated;
import reactor.util.annotation.Nullable;

/**
 * Immutable implementation of {@link RoleCreateMonoGenerator}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code RoleCreateMono.of()}.
 */
@Generated(from = "RoleCreateMonoGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class RoleCreateMono extends RoleCreateMonoGenerator {
  private final @Nullable String reason;
  private final String name_value;
  private final boolean name_absent;
  private final PermissionSet permissions_value;
  private final boolean permissions_absent;
  private final Color color_value;
  private final boolean color_absent;
  private final Boolean hoist_value;
  private final boolean hoist_absent;
  private final Boolean mentionable_value;
  private final boolean mentionable_absent;
  private final String icon_value;
  private final boolean icon_absent;
  private final String unicodeEmoji_value;
  private final boolean unicodeEmoji_absent;
  private final Guild guild;

  private RoleCreateMono(Guild guild) {
    this.guild = Objects.requireNonNull(guild, "guild");
    this.reason = null;
    Possible<String> name$impl = Possible.absent();
    Possible<PermissionSet> permissions$impl = Possible.absent();
    Possible<Color> color$impl = Possible.absent();
    Possible<Boolean> hoist$impl = Possible.absent();
    Possible<Boolean> mentionable$impl = Possible.absent();
    Possible<Optional<String>> icon$impl = Possible.absent();
    Possible<Optional<String>> unicodeEmoji$impl = Possible.absent();
    this.name_value = name$impl.toOptional().orElse(null);
    this.name_absent = name$impl.isAbsent();
    this.permissions_value = permissions$impl.toOptional().orElse(null);
    this.permissions_absent = permissions$impl.isAbsent();
    this.color_value = color$impl.toOptional().orElse(null);
    this.color_absent = color$impl.isAbsent();
    this.hoist_value = hoist$impl.toOptional().orElse(null);
    this.hoist_absent = hoist$impl.isAbsent();
    this.mentionable_value = mentionable$impl.toOptional().orElse(null);
    this.mentionable_absent = mentionable$impl.isAbsent();
    this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
    this.icon_absent = icon$impl.isAbsent();
    this.unicodeEmoji_value = Possible.flatOpt(unicodeEmoji$impl).orElse(null);
    this.unicodeEmoji_absent = unicodeEmoji$impl.isAbsent();
    this.initShim = null;
  }

  private RoleCreateMono(
      @Nullable String reason,
      Possible<String> name,
      Possible<PermissionSet> permissions,
      Possible<Color> color,
      Possible<Boolean> hoist,
      Possible<Boolean> mentionable,
      Possible<Optional<String>> icon,
      Possible<Optional<String>> unicodeEmoji,
      Guild guild) {
    this.reason = reason;
    Possible<String> name$impl = name;
    Possible<PermissionSet> permissions$impl = permissions;
    Possible<Color> color$impl = color;
    Possible<Boolean> hoist$impl = hoist;
    Possible<Boolean> mentionable$impl = mentionable;
    Possible<Optional<String>> icon$impl = icon;
    Possible<Optional<String>> unicodeEmoji$impl = unicodeEmoji;
    this.guild = guild;
    this.name_value = name$impl.toOptional().orElse(null);
    this.name_absent = name$impl.isAbsent();
    this.permissions_value = permissions$impl.toOptional().orElse(null);
    this.permissions_absent = permissions$impl.isAbsent();
    this.color_value = color$impl.toOptional().orElse(null);
    this.color_absent = color$impl.isAbsent();
    this.hoist_value = hoist$impl.toOptional().orElse(null);
    this.hoist_absent = hoist$impl.isAbsent();
    this.mentionable_value = mentionable$impl.toOptional().orElse(null);
    this.mentionable_absent = mentionable$impl.isAbsent();
    this.icon_value = Possible.flatOpt(icon$impl).orElse(null);
    this.icon_absent = icon$impl.isAbsent();
    this.unicodeEmoji_value = Possible.flatOpt(unicodeEmoji$impl).orElse(null);
    this.unicodeEmoji_absent = unicodeEmoji$impl.isAbsent();
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "RoleCreateMonoGenerator", generator = "Immutables")
  private final class InitShim {
    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      return "Cannot build RoleCreateMono, attribute initializers form cycle " + attributes;
    }
  }

  /**
   * Returns the current audit log reason set on the spec.
   * @return The current audit log reason.
   */
  @Override
  public @Nullable String reason() {
    return reason;
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public Possible<String> name() {
    return name_absent ? Possible.absent() : Possible.of(name_value);
  }

  /**
   * @return The value of the {@code permissions} attribute
   */
  @Override
  public Possible<PermissionSet> permissions() {
    return permissions_absent ? Possible.absent() : Possible.of(permissions_value);
  }

  /**
   * @return The value of the {@code color} attribute
   */
  @Override
  public Possible<Color> color() {
    return color_absent ? Possible.absent() : Possible.of(color_value);
  }

  /**
   * @return The value of the {@code hoist} attribute
   */
  @Override
  public Possible<Boolean> hoist() {
    return hoist_absent ? Possible.absent() : Possible.of(hoist_value);
  }

  /**
   * @return The value of the {@code mentionable} attribute
   */
  @Override
  public Possible<Boolean> mentionable() {
    return mentionable_absent ? Possible.absent() : Possible.of(mentionable_value);
  }

  /**
   * @return The value of the {@code icon} attribute
   */
  @Override
  public Possible<Optional<String>> icon() {
    return icon_absent ? Possible.absent() :
        Possible.of(Optional.ofNullable(icon_value));
  }

  /**
   * @return The value of the {@code unicodeEmoji} attribute
   */
  @Override
  public Possible<Optional<String>> unicodeEmoji() {
    return unicodeEmoji_absent ? Possible.absent() :
        Possible.of(Optional.ofNullable(unicodeEmoji_value));
  }

  /**
   * @return The value of the {@code guild} attribute
   */
  @Override
  public Guild guild() {
    return guild;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link RoleCreateMono#reason() reason} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for reason (can be {@code null})
   * @return A modified copy of the {@code this} object
   */
  public final RoleCreateMono withReason(@Nullable String value) {
    if (Objects.equals(this.reason, value)) return this;
    return new RoleCreateMono(
        value,
        this.name(),
        this.permissions(),
        this.color(),
        this.hoist(),
        this.mentionable(),
        this.icon(),
        this.unicodeEmoji(),
        this.guild);
  }

  public RoleCreateMono withName(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return new RoleCreateMono(
        this.reason,
        newValue,
        this.permissions(),
        this.color(),
        this.hoist(),
        this.mentionable(),
        this.icon(),
        this.unicodeEmoji(),
        this.guild);
  }

  public RoleCreateMono withName(String value) {
    Possible<String> newValue = Possible.of(value);
    return new RoleCreateMono(
        this.reason,
        newValue,
        this.permissions(),
        this.color(),
        this.hoist(),
        this.mentionable(),
        this.icon(),
        this.unicodeEmoji(),
        this.guild);
  }

  public RoleCreateMono withPermissions(Possible<PermissionSet> value) {
    Possible<PermissionSet> newValue = Objects.requireNonNull(value);
    return new RoleCreateMono(
        this.reason,
        this.name(),
        newValue,
        this.color(),
        this.hoist(),
        this.mentionable(),
        this.icon(),
        this.unicodeEmoji(),
        this.guild);
  }

  public RoleCreateMono withPermissions(PermissionSet value) {
    Possible<PermissionSet> newValue = Possible.of(value);
    return new RoleCreateMono(
        this.reason,
        this.name(),
        newValue,
        this.color(),
        this.hoist(),
        this.mentionable(),
        this.icon(),
        this.unicodeEmoji(),
        this.guild);
  }

  public RoleCreateMono withColor(Possible<Color> value) {
    Possible<Color> newValue = Objects.requireNonNull(value);
    return new RoleCreateMono(
        this.reason,
        this.name(),
        this.permissions(),
        newValue,
        this.hoist(),
        this.mentionable(),
        this.icon(),
        this.unicodeEmoji(),
        this.guild);
  }

  public RoleCreateMono withColor(Color value) {
    Possible<Color> newValue = Possible.of(value);
    return new RoleCreateMono(
        this.reason,
        this.name(),
        this.permissions(),
        newValue,
        this.hoist(),
        this.mentionable(),
        this.icon(),
        this.unicodeEmoji(),
        this.guild);
  }

  public RoleCreateMono withHoist(Possible<Boolean> value) {
    Possible<Boolean> newValue = Objects.requireNonNull(value);
    return new RoleCreateMono(
        this.reason,
        this.name(),
        this.permissions(),
        this.color(),
        newValue,
        this.mentionable(),
        this.icon(),
        this.unicodeEmoji(),
        this.guild);
  }

  public RoleCreateMono withHoist(Boolean value) {
    Possible<Boolean> newValue = Possible.of(value);
    return new RoleCreateMono(
        this.reason,
        this.name(),
        this.permissions(),
        this.color(),
        newValue,
        this.mentionable(),
        this.icon(),
        this.unicodeEmoji(),
        this.guild);
  }

  public RoleCreateMono withMentionable(Possible<Boolean> value) {
    Possible<Boolean> newValue = Objects.requireNonNull(value);
    return new RoleCreateMono(
        this.reason,
        this.name(),
        this.permissions(),
        this.color(),
        this.hoist(),
        newValue,
        this.icon(),
        this.unicodeEmoji(),
        this.guild);
  }

  public RoleCreateMono withMentionable(Boolean value) {
    Possible<Boolean> newValue = Possible.of(value);
    return new RoleCreateMono(
        this.reason,
        this.name(),
        this.permissions(),
        this.color(),
        this.hoist(),
        newValue,
        this.icon(),
        this.unicodeEmoji(),
        this.guild);
  }

  public RoleCreateMono withIcon(Possible<Optional<String>> value) {
    Possible<Optional<String>> newValue = Objects.requireNonNull(value);
    return new RoleCreateMono(
        this.reason,
        this.name(),
        this.permissions(),
        this.color(),
        this.hoist(),
        this.mentionable(),
        newValue,
        this.unicodeEmoji(),
        this.guild);
  }

  @Deprecated
  public RoleCreateMono withIcon(@Nullable String value) {
    Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
    return new RoleCreateMono(
        this.reason,
        this.name(),
        this.permissions(),
        this.color(),
        this.hoist(),
        this.mentionable(),
        newValue,
        this.unicodeEmoji(),
        this.guild);
  }

  public RoleCreateMono withIconOrNull(@Nullable String value) {
    Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
    return new RoleCreateMono(
        this.reason,
        this.name(),
        this.permissions(),
        this.color(),
        this.hoist(),
        this.mentionable(),
        newValue,
        this.unicodeEmoji(),
        this.guild);
  }

  public RoleCreateMono withUnicodeEmoji(Possible<Optional<String>> value) {
    Possible<Optional<String>> newValue = Objects.requireNonNull(value);
    return new RoleCreateMono(
        this.reason,
        this.name(),
        this.permissions(),
        this.color(),
        this.hoist(),
        this.mentionable(),
        this.icon(),
        newValue,
        this.guild);
  }

  @Deprecated
  public RoleCreateMono withUnicodeEmoji(@Nullable String value) {
    Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
    return new RoleCreateMono(
        this.reason,
        this.name(),
        this.permissions(),
        this.color(),
        this.hoist(),
        this.mentionable(),
        this.icon(),
        newValue,
        this.guild);
  }

  public RoleCreateMono withUnicodeEmojiOrNull(@Nullable String value) {
    Possible<Optional<String>> newValue = Possible.of(Optional.ofNullable(value));
    return new RoleCreateMono(
        this.reason,
        this.name(),
        this.permissions(),
        this.color(),
        this.hoist(),
        this.mentionable(),
        this.icon(),
        newValue,
        this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link RoleCreateMono#guild() guild} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for guild
   * @return A modified copy of the {@code this} object
   */
  public final RoleCreateMono withGuild(Guild value) {
    if (this.guild == value) return this;
    Guild newValue = Objects.requireNonNull(value, "guild");
    return new RoleCreateMono(
        this.reason,
        this.name(),
        this.permissions(),
        this.color(),
        this.hoist(),
        this.mentionable(),
        this.icon(),
        this.unicodeEmoji(),
        newValue);
  }

  /**
   * This instance is equal to all instances of {@code RoleCreateMono} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof RoleCreateMono
        && equalTo(0, (RoleCreateMono) another);
  }

  private boolean equalTo(int synthetic, RoleCreateMono another) {
    return Objects.equals(reason, another.reason)
        && this.name().equals(another.name())
        && this.permissions().equals(another.permissions())
        && this.color().equals(another.color())
        && this.hoist().equals(another.hoist())
        && this.mentionable().equals(another.mentionable())
        && this.icon().equals(another.icon())
        && this.unicodeEmoji().equals(another.unicodeEmoji())
        && guild.equals(another.guild);
  }

  /**
   * Computes a hash code from attributes: {@code reason}, {@code name}, {@code permissions}, {@code color}, {@code hoist}, {@code mentionable}, {@code icon}, {@code unicodeEmoji}, {@code guild}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(reason);
    h += (h << 5) + (name().hashCode());
    h += (h << 5) + (permissions().hashCode());
    h += (h << 5) + (color().hashCode());
    h += (h << 5) + (hoist().hashCode());
    h += (h << 5) + (mentionable().hashCode());
    h += (h << 5) + (icon().hashCode());
    h += (h << 5) + (unicodeEmoji().hashCode());
    h += (h << 5) + guild.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code RoleCreateMono} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "RoleCreateMono{"
        + "reason=" + reason
        + ", name=" + (name().toString())
        + ", permissions=" + (permissions().toString())
        + ", color=" + (color().toString())
        + ", hoist=" + (hoist().toString())
        + ", mentionable=" + (mentionable().toString())
        + ", icon=" + (icon().toString())
        + ", unicodeEmoji=" + (unicodeEmoji().toString())
        + ", guild=" + guild
        + "}";
  }

  /**
   * Construct a new immutable {@code RoleCreateMono} instance.
   * @param guild The value for the {@code guild} attribute
   * @return An immutable RoleCreateMono instance
   */
  public static RoleCreateMono of(Guild guild) {
    return new RoleCreateMono(guild);
  }

  /**
   * Creates an immutable copy of a {@link RoleCreateMonoGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable RoleCreateMono instance
   */
  static RoleCreateMono copyOf(RoleCreateMonoGenerator instance) {
    if (instance instanceof RoleCreateMono) {
      return (RoleCreateMono) instance;
    }
    return RoleCreateMono.of(instance.guild())
        .withReason(instance.reason())
        .withName(instance.name())
        .withPermissions(instance.permissions())
        .withColor(instance.color())
        .withHoist(instance.hoist())
        .withMentionable(instance.mentionable())
        .withIcon(instance.icon())
        .withUnicodeEmoji(instance.unicodeEmoji());
  }

  public boolean isNamePresent() {
    return !name_absent;
  }

  public String nameOrElse(String defaultValue) {
    return !name_absent ? name_value : defaultValue;
  }

  public boolean isPermissionsPresent() {
    return !permissions_absent;
  }

  public PermissionSet permissionsOrElse(PermissionSet defaultValue) {
    return !permissions_absent ? permissions_value : defaultValue;
  }

  public boolean isColorPresent() {
    return !color_absent;
  }

  public Color colorOrElse(Color defaultValue) {
    return !color_absent ? color_value : defaultValue;
  }

  public boolean isHoistPresent() {
    return !hoist_absent;
  }

  public Boolean hoistOrElse(Boolean defaultValue) {
    return !hoist_absent ? hoist_value : defaultValue;
  }

  public boolean isMentionablePresent() {
    return !mentionable_absent;
  }

  public Boolean mentionableOrElse(Boolean defaultValue) {
    return !mentionable_absent ? mentionable_value : defaultValue;
  }

  public boolean isIconPresent() {
    return !icon_absent;
  }

  public String iconOrElse(String defaultValue) {
    return !icon_absent ? icon_value : defaultValue;
  }

  public boolean isUnicodeEmojiPresent() {
    return !unicodeEmoji_absent;
  }

  public String unicodeEmojiOrElse(String defaultValue) {
    return !unicodeEmoji_absent ? unicodeEmoji_value : defaultValue;
  }
}
