package discord4j.core.spec;

import com.google.errorprone.annotations.Var;
import discord4j.common.util.Snowflake;
import discord4j.core.object.entity.Guild;
import discord4j.discordjson.json.AutoModActionData;
import discord4j.discordjson.json.AutoModTriggerMetaData;
import discord4j.discordjson.possible.Possible;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.immutables.value.Generated;
import reactor.util.annotation.Nullable;

/**
 * Immutable implementation of {@link AutoModRuleCreateMonoGenerator}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code AutoModRuleCreateMono.of()}.
 */
@Generated(from = "AutoModRuleCreateMonoGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class AutoModRuleCreateMono extends AutoModRuleCreateMonoGenerator {
  private final @Nullable String reason;
  private final String name;
  private final int eventType;
  private final int triggerType;
  private final AutoModTriggerMetaData triggerMetaData_value;
  private final boolean triggerMetaData_absent;
  private final List<AutoModActionData> actions;
  private final Boolean enabled_value;
  private final boolean enabled_absent;
  private final List<Snowflake> exemptRoles_value;
  private final boolean exemptRoles_absent;
  private final List<Snowflake> exemptChannels_value;
  private final boolean exemptChannels_absent;
  private final Guild guild;

  private AutoModRuleCreateMono(String name, int eventType, int triggerType, Guild guild) {
    this.name = Objects.requireNonNull(name, "name");
    this.eventType = eventType;
    this.triggerType = triggerType;
    this.guild = Objects.requireNonNull(guild, "guild");
    this.reason = null;
    Possible<AutoModTriggerMetaData> triggerMetaData$impl = Possible.absent();
    Possible<Boolean> enabled$impl = Possible.absent();
    Possible<List<Snowflake>> exemptRoles$impl = Possible.absent();
    Possible<List<Snowflake>> exemptChannels$impl = Possible.absent();
    this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null);
    this.triggerMetaData_absent = triggerMetaData$impl.isAbsent();
    this.enabled_value = enabled$impl.toOptional().orElse(null);
    this.enabled_absent = enabled$impl.isAbsent();
    this.exemptRoles_value = exemptRoles$impl.toOptional().orElse(null);
    this.exemptRoles_absent = exemptRoles$impl.isAbsent();
    this.exemptChannels_value = exemptChannels$impl.toOptional().orElse(null);
    this.exemptChannels_absent = exemptChannels$impl.isAbsent();
    this.actions = initShim.actions();
    this.initShim = null;
  }

  private AutoModRuleCreateMono(
      @Nullable String reason,
      String name,
      int eventType,
      int triggerType,
      Possible<AutoModTriggerMetaData> triggerMetaData,
      List<AutoModActionData> actions,
      Possible<Boolean> enabled,
      Possible<List<Snowflake>> exemptRoles,
      Possible<List<Snowflake>> exemptChannels,
      Guild guild) {
    this.reason = reason;
    this.name = name;
    this.eventType = eventType;
    this.triggerType = triggerType;
    Possible<AutoModTriggerMetaData> triggerMetaData$impl = triggerMetaData;
    initShim.actions(actions);
    Possible<Boolean> enabled$impl = enabled;
    Possible<List<Snowflake>> exemptRoles$impl = exemptRoles;
    Possible<List<Snowflake>> exemptChannels$impl = exemptChannels;
    this.guild = guild;
    this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null);
    this.triggerMetaData_absent = triggerMetaData$impl.isAbsent();
    this.enabled_value = enabled$impl.toOptional().orElse(null);
    this.enabled_absent = enabled$impl.isAbsent();
    this.exemptRoles_value = exemptRoles$impl.toOptional().orElse(null);
    this.exemptRoles_absent = exemptRoles$impl.isAbsent();
    this.exemptChannels_value = exemptChannels$impl.toOptional().orElse(null);
    this.exemptChannels_absent = exemptChannels$impl.isAbsent();
    this.actions = initShim.actions();
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "AutoModRuleCreateMonoGenerator", generator = "Immutables")
  private final class InitShim {
    private byte actionsBuildStage = STAGE_UNINITIALIZED;
    private List<AutoModActionData> actions;

    List<AutoModActionData> actions() {
      if (actionsBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (actionsBuildStage == STAGE_UNINITIALIZED) {
        actionsBuildStage = STAGE_INITIALIZING;
        this.actions = createUnmodifiableList(false, createSafeList(AutoModRuleCreateMono.super.actions(), true, false));
        actionsBuildStage = STAGE_INITIALIZED;
      }
      return this.actions;
    }

    void actions(List<AutoModActionData> actions) {
      this.actions = actions;
      actionsBuildStage = STAGE_INITIALIZED;
    }

    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      if (actionsBuildStage == STAGE_INITIALIZING) attributes.add("actions");
      return "Cannot build AutoModRuleCreateMono, attribute initializers form cycle " + attributes;
    }
  }

  /**
   * Returns the current audit log reason set on the spec.
   * @return The current audit log reason.
   */
  @Override
  public @Nullable String reason() {
    return reason;
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public String name() {
    return name;
  }

  /**
   * @return The value of the {@code eventType} attribute
   */
  @Override
  public int eventType() {
    return eventType;
  }

  /**
   * @return The value of the {@code triggerType} attribute
   */
  @Override
  public int triggerType() {
    return triggerType;
  }

  /**
   * @return The value of the {@code triggerMetaData} attribute
   */
  @Override
  public Possible<AutoModTriggerMetaData> triggerMetaData() {
    return triggerMetaData_absent ? Possible.absent() : Possible.of(triggerMetaData_value);
  }

  /**
   * @return The value of the {@code actions} attribute
   */
  @Override
  public List<AutoModActionData> actions() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.actions()
        : this.actions;
  }

  /**
   * @return The value of the {@code enabled} attribute
   */
  @Override
  public Possible<Boolean> enabled() {
    return enabled_absent ? Possible.absent() : Possible.of(enabled_value);
  }

  /**
   * @return The value of the {@code exemptRoles} attribute
   */
  @Override
  public Possible<List<Snowflake>> exemptRoles() {
    return exemptRoles_absent ? Possible.absent() :
        Possible.of(exemptRoles_value);
  }

  /**
   * @return The value of the {@code exemptChannels} attribute
   */
  @Override
  public Possible<List<Snowflake>> exemptChannels() {
    return exemptChannels_absent ? Possible.absent() :
        Possible.of(exemptChannels_value);
  }

  /**
   * @return The value of the {@code guild} attribute
   */
  @Override
  public Guild guild() {
    return guild;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleCreateMono#reason() reason} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for reason (can be {@code null})
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleCreateMono withReason(@Nullable String value) {
    if (Objects.equals(this.reason, value)) return this;
    return new AutoModRuleCreateMono(
        value,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels(),
        this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleCreateMono#name() name} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for name
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleCreateMono withName(String value) {
    String newValue = Objects.requireNonNull(value, "name");
    if (this.name.equals(newValue)) return this;
    return new AutoModRuleCreateMono(
        this.reason,
        newValue,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels(),
        this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleCreateMono#eventType() eventType} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for eventType
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleCreateMono withEventType(int value) {
    if (this.eventType == value) return this;
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        value,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels(),
        this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleCreateMono#triggerType() triggerType} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for triggerType
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleCreateMono withTriggerType(int value) {
    if (this.triggerType == value) return this;
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        value,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels(),
        this.guild);
  }

  public AutoModRuleCreateMono withTriggerMetaData(Possible<AutoModTriggerMetaData> value) {
    Possible<AutoModTriggerMetaData> newValue = Objects.requireNonNull(value);
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        newValue,
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels(),
        this.guild);
  }

  public AutoModRuleCreateMono withTriggerMetaData(AutoModTriggerMetaData value) {
    Possible<AutoModTriggerMetaData> newValue = Possible.of(value);
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        newValue,
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels(),
        this.guild);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleCreateMono#actions() actions}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleCreateMono withActions(AutoModActionData... elements) {
    List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        newValue,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels(),
        this.guild);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleCreateMono#actions() actions}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of actions elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleCreateMono withActions(Iterable<? extends AutoModActionData> elements) {
    if (this.actions == elements) return this;
    List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        newValue,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels(),
        this.guild);
  }

  public AutoModRuleCreateMono withEnabled(Possible<Boolean> value) {
    Possible<Boolean> newValue = Objects.requireNonNull(value);
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        newValue,
        this.exemptRoles(),
        this.exemptChannels(),
        this.guild);
  }

  public AutoModRuleCreateMono withEnabled(Boolean value) {
    Possible<Boolean> newValue = Possible.of(value);
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        newValue,
        this.exemptRoles(),
        this.exemptChannels(),
        this.guild);
  }

  public AutoModRuleCreateMono withExemptRoles(Possible<List<Snowflake>> possible) {
    Possible<List<Snowflake>> newValue = Objects.requireNonNull(possible);
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        newValue,
        this.exemptChannels(),
        this.guild);
  }

  public AutoModRuleCreateMono withExemptRoles(java.lang.Iterable<Snowflake> elements) {
    Possible<List<Snowflake>> newValue = Possible.of(
      StreamSupport.stream(Objects.requireNonNull(elements).spliterator(), false).collect(Collectors.toList()));
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        newValue,
        this.exemptChannels(),
        this.guild);
  }

  @SafeVarargs
  public final AutoModRuleCreateMono withExemptRoles(Snowflake... elements) {
    Possible<List<Snowflake>> newValue = Possible.of(Arrays.asList(elements));
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        newValue,
        this.exemptChannels(),
        this.guild);
  }

  public AutoModRuleCreateMono withExemptChannels(Possible<List<Snowflake>> possible) {
    Possible<List<Snowflake>> newValue = Objects.requireNonNull(possible);
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        newValue,
        this.guild);
  }

  public AutoModRuleCreateMono withExemptChannels(java.lang.Iterable<Snowflake> elements) {
    Possible<List<Snowflake>> newValue = Possible.of(
      StreamSupport.stream(Objects.requireNonNull(elements).spliterator(), false).collect(Collectors.toList()));
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        newValue,
        this.guild);
  }

  @SafeVarargs
  public final AutoModRuleCreateMono withExemptChannels(Snowflake... elements) {
    Possible<List<Snowflake>> newValue = Possible.of(Arrays.asList(elements));
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        newValue,
        this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleCreateMono#guild() guild} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for guild
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleCreateMono withGuild(Guild value) {
    if (this.guild == value) return this;
    Guild newValue = Objects.requireNonNull(value, "guild");
    return new AutoModRuleCreateMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels(),
        newValue);
  }

  /**
   * This instance is equal to all instances of {@code AutoModRuleCreateMono} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof AutoModRuleCreateMono
        && equalTo(0, (AutoModRuleCreateMono) another);
  }

  private boolean equalTo(int synthetic, AutoModRuleCreateMono another) {
    return Objects.equals(reason, another.reason)
        && name.equals(another.name)
        && eventType == another.eventType
        && triggerType == another.triggerType
        && this.triggerMetaData().equals(another.triggerMetaData())
        && actions.equals(another.actions)
        && this.enabled().equals(another.enabled())
        && Objects.equals(exemptRoles_value, another.exemptRoles_value)
        && Objects.equals(exemptChannels_value, another.exemptChannels_value)
        && guild.equals(another.guild);
  }

  /**
   * Computes a hash code from attributes: {@code reason}, {@code name}, {@code eventType}, {@code triggerType}, {@code triggerMetaData}, {@code actions}, {@code enabled}, {@code exemptRoles}, {@code exemptChannels}, {@code guild}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(reason);
    h += (h << 5) + name.hashCode();
    h += (h << 5) + eventType;
    h += (h << 5) + triggerType;
    h += (h << 5) + (triggerMetaData().hashCode());
    h += (h << 5) + actions.hashCode();
    h += (h << 5) + (enabled().hashCode());
    h += (h << 5) + (Objects.hashCode(exemptRoles_value));
    h += (h << 5) + (Objects.hashCode(exemptChannels_value));
    h += (h << 5) + guild.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code AutoModRuleCreateMono} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "AutoModRuleCreateMono{"
        + "reason=" + reason
        + ", name=" + name
        + ", eventType=" + eventType
        + ", triggerType=" + triggerType
        + ", triggerMetaData=" + (triggerMetaData().toString())
        + ", actions=" + actions
        + ", enabled=" + (enabled().toString())
        + ", exemptRoles=" + (Objects.toString(exemptRoles_value))
        + ", exemptChannels=" + (Objects.toString(exemptChannels_value))
        + ", guild=" + guild
        + "}";
  }

  /**
   * Construct a new immutable {@code AutoModRuleCreateMono} instance.
   * @param name The value for the {@code name} attribute
   * @param eventType The value for the {@code eventType} attribute
   * @param triggerType The value for the {@code triggerType} attribute
   * @param guild The value for the {@code guild} attribute
   * @return An immutable AutoModRuleCreateMono instance
   */
  public static AutoModRuleCreateMono of(String name, int eventType, int triggerType, Guild guild) {
    return new AutoModRuleCreateMono(name, eventType, triggerType, guild);
  }

  /**
   * Creates an immutable copy of a {@link AutoModRuleCreateMonoGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable AutoModRuleCreateMono instance
   */
  static AutoModRuleCreateMono copyOf(AutoModRuleCreateMonoGenerator instance) {
    if (instance instanceof AutoModRuleCreateMono) {
      return (AutoModRuleCreateMono) instance;
    }
    return AutoModRuleCreateMono.of(instance.name(), instance.eventType(), instance.triggerType(), instance.guild())
        .withReason(instance.reason())
        .withTriggerMetaData(instance.triggerMetaData())
        .withActions(instance.actions())
        .withEnabled(instance.enabled())
        .withExemptRoles(instance.exemptRoles())
        .withExemptChannels(instance.exemptChannels());
  }

  public boolean isTriggerMetaDataPresent() {
    return !triggerMetaData_absent;
  }

  public AutoModTriggerMetaData triggerMetaDataOrElse(AutoModTriggerMetaData defaultValue) {
    return !triggerMetaData_absent ? triggerMetaData_value : defaultValue;
  }

  public boolean isEnabledPresent() {
    return !enabled_absent;
  }

  public Boolean enabledOrElse(Boolean defaultValue) {
    return !enabled_absent ? enabled_value : defaultValue;
  }

  public boolean isExemptRolesPresent() {
    return !exemptRoles_absent;
  }

  public List<Snowflake> exemptRolesOrElse(List<Snowflake> defaultValue) {
    return !exemptRoles_absent ? exemptRoles_value : defaultValue;
  }

  public boolean isExemptChannelsPresent() {
    return !exemptChannels_absent;
  }

  public List<Snowflake> exemptChannelsOrElse(List<Snowflake> defaultValue) {
    return !exemptChannels_absent ? exemptChannels_value : defaultValue;
  }

  private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
    ArrayList<T> list;
    if (iterable instanceof Collection<?>) {
      int size = ((Collection<?>) iterable).size();
      if (size == 0) return Collections.emptyList();
      list = new ArrayList<>();
    } else {
      list = new ArrayList<>();
    }
    for (T element : iterable) {
      if (skipNulls && element == null) continue;
      if (checkNulls) Objects.requireNonNull(element, "element");
      list.add(element);
    }
    return list;
  }

  private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
    switch(list.size()) {
    case 0: return Collections.emptyList();
    case 1: return Collections.singletonList(list.get(0));
    default:
      if (clone) {
        return Collections.unmodifiableList(new ArrayList<>(list));
      } else {
        if (list instanceof ArrayList<?>) {
          ((ArrayList<?>) list).trimToSize();
        }
        return Collections.unmodifiableList(list);
      }
    }
  }
}
