package discord4j.core.spec;

import com.google.errorprone.annotations.Var;
import discord4j.common.util.Snowflake;
import discord4j.core.object.automod.AutoModRule;
import discord4j.discordjson.json.AutoModActionData;
import discord4j.discordjson.json.AutoModTriggerMetaData;
import discord4j.discordjson.possible.Possible;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import org.immutables.value.Generated;
import reactor.util.annotation.Nullable;

/**
 * Immutable implementation of {@link AutoModRuleEditMonoGenerator}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code AutoModRuleEditMono.of()}.
 */
@Generated(from = "AutoModRuleEditMonoGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class AutoModRuleEditMono extends AutoModRuleEditMonoGenerator {
  private final @Nullable String reason;
  private final String name;
  private final int eventType;
  private final AutoModTriggerMetaData triggerMetaData_value;
  private final boolean triggerMetaData_absent;
  private final List<AutoModActionData> actions;
  private final boolean enabled;
  private final List<Snowflake> exemptRoles;
  private final List<Snowflake> exemptChannels;
  private final AutoModRule autoModRule;

  private AutoModRuleEditMono(
      String name,
      int eventType,
      boolean enabled,
      AutoModRule autoModRule) {
    this.name = Objects.requireNonNull(name, "name");
    this.eventType = eventType;
    this.enabled = enabled;
    this.autoModRule = Objects.requireNonNull(autoModRule, "autoModRule");
    this.reason = null;
    Possible<AutoModTriggerMetaData> triggerMetaData$impl = Possible.absent();
    this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null);
    this.triggerMetaData_absent = triggerMetaData$impl.isAbsent();
    this.actions = initShim.actions();
    this.exemptRoles = initShim.exemptRoles();
    this.exemptChannels = initShim.exemptChannels();
    this.initShim = null;
  }

  private AutoModRuleEditMono(
      @Nullable String reason,
      String name,
      int eventType,
      Possible<AutoModTriggerMetaData> triggerMetaData,
      List<AutoModActionData> actions,
      boolean enabled,
      List<Snowflake> exemptRoles,
      List<Snowflake> exemptChannels,
      AutoModRule autoModRule) {
    this.reason = reason;
    this.name = name;
    this.eventType = eventType;
    Possible<AutoModTriggerMetaData> triggerMetaData$impl = triggerMetaData;
    initShim.actions(actions);
    this.enabled = enabled;
    initShim.exemptRoles(exemptRoles);
    initShim.exemptChannels(exemptChannels);
    this.autoModRule = autoModRule;
    this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null);
    this.triggerMetaData_absent = triggerMetaData$impl.isAbsent();
    this.actions = initShim.actions();
    this.exemptRoles = initShim.exemptRoles();
    this.exemptChannels = initShim.exemptChannels();
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "AutoModRuleEditMonoGenerator", generator = "Immutables")
  private final class InitShim {
    private byte actionsBuildStage = STAGE_UNINITIALIZED;
    private List<AutoModActionData> actions;

    List<AutoModActionData> actions() {
      if (actionsBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (actionsBuildStage == STAGE_UNINITIALIZED) {
        actionsBuildStage = STAGE_INITIALIZING;
        this.actions = createUnmodifiableList(false, createSafeList(AutoModRuleEditMono.super.actions(), true, false));
        actionsBuildStage = STAGE_INITIALIZED;
      }
      return this.actions;
    }

    void actions(List<AutoModActionData> actions) {
      this.actions = actions;
      actionsBuildStage = STAGE_INITIALIZED;
    }

    private byte exemptRolesBuildStage = STAGE_UNINITIALIZED;
    private List<Snowflake> exemptRoles;

    List<Snowflake> exemptRoles() {
      if (exemptRolesBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (exemptRolesBuildStage == STAGE_UNINITIALIZED) {
        exemptRolesBuildStage = STAGE_INITIALIZING;
        this.exemptRoles = createUnmodifiableList(false, createSafeList(AutoModRuleEditMono.super.exemptRoles(), true, false));
        exemptRolesBuildStage = STAGE_INITIALIZED;
      }
      return this.exemptRoles;
    }

    void exemptRoles(List<Snowflake> exemptRoles) {
      this.exemptRoles = exemptRoles;
      exemptRolesBuildStage = STAGE_INITIALIZED;
    }

    private byte exemptChannelsBuildStage = STAGE_UNINITIALIZED;
    private List<Snowflake> exemptChannels;

    List<Snowflake> exemptChannels() {
      if (exemptChannelsBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (exemptChannelsBuildStage == STAGE_UNINITIALIZED) {
        exemptChannelsBuildStage = STAGE_INITIALIZING;
        this.exemptChannels = createUnmodifiableList(false, createSafeList(AutoModRuleEditMono.super.exemptChannels(), true, false));
        exemptChannelsBuildStage = STAGE_INITIALIZED;
      }
      return this.exemptChannels;
    }

    void exemptChannels(List<Snowflake> exemptChannels) {
      this.exemptChannels = exemptChannels;
      exemptChannelsBuildStage = STAGE_INITIALIZED;
    }

    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      if (actionsBuildStage == STAGE_INITIALIZING) attributes.add("actions");
      if (exemptRolesBuildStage == STAGE_INITIALIZING) attributes.add("exemptRoles");
      if (exemptChannelsBuildStage == STAGE_INITIALIZING) attributes.add("exemptChannels");
      return "Cannot build AutoModRuleEditMono, attribute initializers form cycle " + attributes;
    }
  }

  /**
   * Returns the current audit log reason set on the spec.
   * @return The current audit log reason.
   */
  @Override
  public @Nullable String reason() {
    return reason;
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public String name() {
    return name;
  }

  /**
   * @return The value of the {@code eventType} attribute
   */
  @Override
  public int eventType() {
    return eventType;
  }

  /**
   * @return The value of the {@code triggerMetaData} attribute
   */
  @Override
  public Possible<AutoModTriggerMetaData> triggerMetaData() {
    return triggerMetaData_absent ? Possible.absent() : Possible.of(triggerMetaData_value);
  }

  /**
   * @return The value of the {@code actions} attribute
   */
  @Override
  public List<AutoModActionData> actions() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.actions()
        : this.actions;
  }

  /**
   * @return The value of the {@code enabled} attribute
   */
  @Override
  public boolean enabled() {
    return enabled;
  }

  /**
   * @return The value of the {@code exemptRoles} attribute
   */
  @Override
  public List<Snowflake> exemptRoles() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.exemptRoles()
        : this.exemptRoles;
  }

  /**
   * @return The value of the {@code exemptChannels} attribute
   */
  @Override
  public List<Snowflake> exemptChannels() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.exemptChannels()
        : this.exemptChannels;
  }

  /**
   * @return The value of the {@code autoModRule} attribute
   */
  @Override
  public AutoModRule autoModRule() {
    return autoModRule;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleEditMono#reason() reason} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for reason (can be {@code null})
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleEditMono withReason(@Nullable String value) {
    if (Objects.equals(this.reason, value)) return this;
    return new AutoModRuleEditMono(
        value,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels,
        this.autoModRule);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleEditMono#name() name} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for name
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleEditMono withName(String value) {
    String newValue = Objects.requireNonNull(value, "name");
    if (this.name.equals(newValue)) return this;
    return new AutoModRuleEditMono(
        this.reason,
        newValue,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels,
        this.autoModRule);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleEditMono#eventType() eventType} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for eventType
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleEditMono withEventType(int value) {
    if (this.eventType == value) return this;
    return new AutoModRuleEditMono(
        this.reason,
        this.name,
        value,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels,
        this.autoModRule);
  }

  public AutoModRuleEditMono withTriggerMetaData(Possible<AutoModTriggerMetaData> value) {
    Possible<AutoModTriggerMetaData> newValue = Objects.requireNonNull(value);
    return new AutoModRuleEditMono(
        this.reason,
        this.name,
        this.eventType,
        newValue,
        this.actions,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels,
        this.autoModRule);
  }

  public AutoModRuleEditMono withTriggerMetaData(AutoModTriggerMetaData value) {
    Possible<AutoModTriggerMetaData> newValue = Possible.of(value);
    return new AutoModRuleEditMono(
        this.reason,
        this.name,
        this.eventType,
        newValue,
        this.actions,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels,
        this.autoModRule);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleEditMono#actions() actions}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleEditMono withActions(AutoModActionData... elements) {
    List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
    return new AutoModRuleEditMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        newValue,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels,
        this.autoModRule);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleEditMono#actions() actions}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of actions elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleEditMono withActions(Iterable<? extends AutoModActionData> elements) {
    if (this.actions == elements) return this;
    List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new AutoModRuleEditMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        newValue,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels,
        this.autoModRule);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleEditMono#enabled() enabled} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for enabled
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleEditMono withEnabled(boolean value) {
    if (this.enabled == value) return this;
    return new AutoModRuleEditMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        value,
        this.exemptRoles,
        this.exemptChannels,
        this.autoModRule);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleEditMono#exemptRoles() exemptRoles}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleEditMono withExemptRoles(Snowflake... elements) {
    List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
    return new AutoModRuleEditMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        newValue,
        this.exemptChannels,
        this.autoModRule);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleEditMono#exemptRoles() exemptRoles}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of exemptRoles elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleEditMono withExemptRoles(Iterable<? extends Snowflake> elements) {
    if (this.exemptRoles == elements) return this;
    List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new AutoModRuleEditMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        newValue,
        this.exemptChannels,
        this.autoModRule);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleEditMono#exemptChannels() exemptChannels}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleEditMono withExemptChannels(Snowflake... elements) {
    List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
    return new AutoModRuleEditMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        this.exemptRoles,
        newValue,
        this.autoModRule);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleEditMono#exemptChannels() exemptChannels}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of exemptChannels elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleEditMono withExemptChannels(Iterable<? extends Snowflake> elements) {
    if (this.exemptChannels == elements) return this;
    List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new AutoModRuleEditMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        this.exemptRoles,
        newValue,
        this.autoModRule);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleEditMono#autoModRule() autoModRule} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for autoModRule
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleEditMono withAutoModRule(AutoModRule value) {
    if (this.autoModRule == value) return this;
    AutoModRule newValue = Objects.requireNonNull(value, "autoModRule");
    return new AutoModRuleEditMono(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels,
        newValue);
  }

  /**
   * This instance is equal to all instances of {@code AutoModRuleEditMono} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof AutoModRuleEditMono
        && equalTo(0, (AutoModRuleEditMono) another);
  }

  private boolean equalTo(int synthetic, AutoModRuleEditMono another) {
    return Objects.equals(reason, another.reason)
        && name.equals(another.name)
        && eventType == another.eventType
        && this.triggerMetaData().equals(another.triggerMetaData())
        && actions.equals(another.actions)
        && enabled == another.enabled
        && exemptRoles.equals(another.exemptRoles)
        && exemptChannels.equals(another.exemptChannels)
        && autoModRule.equals(another.autoModRule);
  }

  /**
   * Computes a hash code from attributes: {@code reason}, {@code name}, {@code eventType}, {@code triggerMetaData}, {@code actions}, {@code enabled}, {@code exemptRoles}, {@code exemptChannels}, {@code autoModRule}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(reason);
    h += (h << 5) + name.hashCode();
    h += (h << 5) + eventType;
    h += (h << 5) + (triggerMetaData().hashCode());
    h += (h << 5) + actions.hashCode();
    h += (h << 5) + Boolean.hashCode(enabled);
    h += (h << 5) + exemptRoles.hashCode();
    h += (h << 5) + exemptChannels.hashCode();
    h += (h << 5) + autoModRule.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code AutoModRuleEditMono} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "AutoModRuleEditMono{"
        + "reason=" + reason
        + ", name=" + name
        + ", eventType=" + eventType
        + ", triggerMetaData=" + (triggerMetaData().toString())
        + ", actions=" + actions
        + ", enabled=" + enabled
        + ", exemptRoles=" + exemptRoles
        + ", exemptChannels=" + exemptChannels
        + ", autoModRule=" + autoModRule
        + "}";
  }

  /**
   * Construct a new immutable {@code AutoModRuleEditMono} instance.
   * @param name The value for the {@code name} attribute
   * @param eventType The value for the {@code eventType} attribute
   * @param enabled The value for the {@code enabled} attribute
   * @param autoModRule The value for the {@code autoModRule} attribute
   * @return An immutable AutoModRuleEditMono instance
   */
  public static AutoModRuleEditMono of(String name, int eventType, boolean enabled, AutoModRule autoModRule) {
    return new AutoModRuleEditMono(name, eventType, enabled, autoModRule);
  }

  /**
   * Creates an immutable copy of a {@link AutoModRuleEditMonoGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable AutoModRuleEditMono instance
   */
  static AutoModRuleEditMono copyOf(AutoModRuleEditMonoGenerator instance) {
    if (instance instanceof AutoModRuleEditMono) {
      return (AutoModRuleEditMono) instance;
    }
    return AutoModRuleEditMono.of(instance.name(), instance.eventType(), instance.enabled(), instance.autoModRule())
        .withReason(instance.reason())
        .withTriggerMetaData(instance.triggerMetaData())
        .withActions(instance.actions())
        .withExemptRoles(instance.exemptRoles())
        .withExemptChannels(instance.exemptChannels());
  }

  public boolean isTriggerMetaDataPresent() {
    return !triggerMetaData_absent;
  }

  public AutoModTriggerMetaData triggerMetaDataOrElse(AutoModTriggerMetaData defaultValue) {
    return !triggerMetaData_absent ? triggerMetaData_value : defaultValue;
  }

  private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
    ArrayList<T> list;
    if (iterable instanceof Collection<?>) {
      int size = ((Collection<?>) iterable).size();
      if (size == 0) return Collections.emptyList();
      list = new ArrayList<>();
    } else {
      list = new ArrayList<>();
    }
    for (T element : iterable) {
      if (skipNulls && element == null) continue;
      if (checkNulls) Objects.requireNonNull(element, "element");
      list.add(element);
    }
    return list;
  }

  private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
    switch(list.size()) {
    case 0: return Collections.emptyList();
    case 1: return Collections.singletonList(list.get(0));
    default:
      if (clone) {
        return Collections.unmodifiableList(new ArrayList<>(list));
      } else {
        if (list instanceof ArrayList<?>) {
          ((ArrayList<?>) list).trimToSize();
        }
        return Collections.unmodifiableList(list);
      }
    }
  }
}
