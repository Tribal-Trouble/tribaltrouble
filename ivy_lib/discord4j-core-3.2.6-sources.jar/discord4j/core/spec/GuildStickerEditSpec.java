package discord4j.core.spec;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import discord4j.discordjson.possible.Possible;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.immutables.value.Generated;
import reactor.util.annotation.Nullable;

/**
 * Immutable implementation of {@link GuildStickerEditSpecGenerator}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code GuildStickerEditSpec.builder()}.
 * Use the static factory method to get the default singleton instance:
 * {@code GuildStickerEditSpec.create()}.
 */
@Generated(from = "GuildStickerEditSpecGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class GuildStickerEditSpec implements GuildStickerEditSpecGenerator {
  private final @Nullable String reason;
  private final String name_value;
  private final boolean name_absent;
  private final String description_value;
  private final boolean description_absent;
  private final String tags_value;
  private final boolean tags_absent;

  private GuildStickerEditSpec() {
    this.reason = null;
    Possible<String> name$impl = Possible.absent();
    Possible<String> description$impl = Possible.absent();
    Possible<String> tags$impl = Possible.absent();
    this.name_value = name$impl.toOptional().orElse(null);
    this.name_absent = name$impl.isAbsent();
    this.description_value = description$impl.toOptional().orElse(null);
    this.description_absent = description$impl.isAbsent();
    this.tags_value = tags$impl.toOptional().orElse(null);
    this.tags_absent = tags$impl.isAbsent();
    this.initShim = null;
  }

  private GuildStickerEditSpec(
      @Nullable String reason,
      Possible<String> name,
      Possible<String> description,
      Possible<String> tags) {
    this.reason = reason;
    Possible<String> name$impl = name;
    Possible<String> description$impl = description;
    Possible<String> tags$impl = tags;
    this.name_value = name$impl.toOptional().orElse(null);
    this.name_absent = name$impl.isAbsent();
    this.description_value = description$impl.toOptional().orElse(null);
    this.description_absent = description$impl.isAbsent();
    this.tags_value = tags$impl.toOptional().orElse(null);
    this.tags_absent = tags$impl.isAbsent();
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "GuildStickerEditSpecGenerator", generator = "Immutables")
  private final class InitShim {
    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      return "Cannot build GuildStickerEditSpec, attribute initializers form cycle " + attributes;
    }
  }

  /**
   * Returns the current audit log reason set on the spec.
   * @return The current audit log reason.
   */
  @Override
  public @Nullable String reason() {
    return reason;
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public Possible<String> name() {
    return name_absent ? Possible.absent() : Possible.of(name_value);
  }

  /**
   * @return The value of the {@code description} attribute
   */
  @Override
  public Possible<String> description() {
    return description_absent ? Possible.absent() : Possible.of(description_value);
  }

  /**
   * @return The value of the {@code tags} attribute
   */
  @Override
  public Possible<String> tags() {
    return tags_absent ? Possible.absent() : Possible.of(tags_value);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerEditSpec#reason() reason} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for reason (can be {@code null})
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerEditSpec withReason(@Nullable String value) {
    if (Objects.equals(this.reason, value)) return this;
    return validate(new GuildStickerEditSpec(value, this.name(), this.description(), this.tags()));
  }

  public GuildStickerEditSpec withName(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return validate(new GuildStickerEditSpec(this.reason, newValue, this.description(), this.tags()));
  }

  public GuildStickerEditSpec withName(String value) {
    Possible<String> newValue = Possible.of(value);
    return validate(new GuildStickerEditSpec(this.reason, newValue, this.description(), this.tags()));
  }

  public GuildStickerEditSpec withDescription(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return validate(new GuildStickerEditSpec(this.reason, this.name(), newValue, this.tags()));
  }

  public GuildStickerEditSpec withDescription(String value) {
    Possible<String> newValue = Possible.of(value);
    return validate(new GuildStickerEditSpec(this.reason, this.name(), newValue, this.tags()));
  }

  public GuildStickerEditSpec withTags(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return validate(new GuildStickerEditSpec(this.reason, this.name(), this.description(), newValue));
  }

  public GuildStickerEditSpec withTags(String value) {
    Possible<String> newValue = Possible.of(value);
    return validate(new GuildStickerEditSpec(this.reason, this.name(), this.description(), newValue));
  }

  /**
   * This instance is equal to all instances of {@code GuildStickerEditSpec} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof GuildStickerEditSpec
        && equalTo(0, (GuildStickerEditSpec) another);
  }

  private boolean equalTo(int synthetic, GuildStickerEditSpec another) {
    return Objects.equals(reason, another.reason)
        && this.name().equals(another.name())
        && this.description().equals(another.description())
        && this.tags().equals(another.tags());
  }

  /**
   * Computes a hash code from attributes: {@code reason}, {@code name}, {@code description}, {@code tags}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(reason);
    h += (h << 5) + (name().hashCode());
    h += (h << 5) + (description().hashCode());
    h += (h << 5) + (tags().hashCode());
    return h;
  }

  /**
   * Prints the immutable value {@code GuildStickerEditSpec} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "GuildStickerEditSpec{"
        + "reason=" + reason
        + ", name=" + (name().toString())
        + ", description=" + (description().toString())
        + ", tags=" + (tags().toString())
        + "}";
  }

  private static final GuildStickerEditSpec INSTANCE = validate(new GuildStickerEditSpec());

  /**
   * Returns the default immutable singleton value of {@code GuildStickerEditSpec}
   * @return An immutable instance of GuildStickerEditSpec
   */
  public static GuildStickerEditSpec create() {
    return INSTANCE;
  }

  private static GuildStickerEditSpec validate(GuildStickerEditSpec instance) {
    return INSTANCE != null && INSTANCE.equalTo(0, instance) ? INSTANCE : instance;
  }

  /**
   * Creates an immutable copy of a {@link GuildStickerEditSpecGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable GuildStickerEditSpec instance
   */
  static GuildStickerEditSpec copyOf(GuildStickerEditSpecGenerator instance) {
    if (instance instanceof GuildStickerEditSpec) {
      return (GuildStickerEditSpec) instance;
    }
    return GuildStickerEditSpec.builder()
        .from(instance)
        .build();
  }

  public boolean isNamePresent() {
    return !name_absent;
  }

  public String nameOrElse(String defaultValue) {
    return !name_absent ? name_value : defaultValue;
  }

  public boolean isDescriptionPresent() {
    return !description_absent;
  }

  public String descriptionOrElse(String defaultValue) {
    return !description_absent ? description_value : defaultValue;
  }

  public boolean isTagsPresent() {
    return !tags_absent;
  }

  public String tagsOrElse(String defaultValue) {
    return !tags_absent ? tags_value : defaultValue;
  }

  /**
   * Creates a builder for {@link GuildStickerEditSpec GuildStickerEditSpec}.
   * <pre>
   * GuildStickerEditSpec.builder()
   *    .reason(String | null) // nullable {@link GuildStickerEditSpec#reason() reason}
   *    .name(discord4j.discordjson.possible.Possible&amp;lt;String&amp;gt;) // {@link GuildStickerEditSpec#name() name}
   *    .description(discord4j.discordjson.possible.Possible&amp;lt;String&amp;gt;) // {@link GuildStickerEditSpec#description() description}
   *    .tags(discord4j.discordjson.possible.Possible&amp;lt;String&amp;gt;) // {@link GuildStickerEditSpec#tags() tags}
   *    .build();
   * </pre>
   * @return A new GuildStickerEditSpec builder
   */
  public static GuildStickerEditSpec.Builder builder() {
    return new GuildStickerEditSpec.Builder();
  }

  /**
   * Builds instances of type {@link GuildStickerEditSpec GuildStickerEditSpec}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "GuildStickerEditSpecGenerator", generator = "Immutables")
  public static final class Builder {
    private Possible<String> name_possible = Possible.absent();
    private Possible<String> description_possible = Possible.absent();
    private Possible<String> tags_possible = Possible.absent();
    private String reason;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code GuildStickerEditSpec} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder from(GuildStickerEditSpec instance) {
      return from((GuildStickerEditSpecGenerator) instance);
    }

    /**
     * Copy abstract value type {@code GuildStickerEditSpecGenerator} instance into builder.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    final Builder from(GuildStickerEditSpecGenerator instance) {
      Objects.requireNonNull(instance, "instance");
      String reasonValue = instance.reason();
      if (reasonValue != null) {
        reason(reasonValue);
      }
      name(instance.name());
      description(instance.description());
      tags(instance.tags());
      return this;
    }

    /**
     * Initializes the value for the {@link GuildStickerEditSpec#reason() reason} attribute.
     * @param reason The value for reason (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder reason(@Nullable String reason) {
      this.reason = reason;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder name(Possible<String> value) {
      this.name_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder name(String value) {
      this.name_possible = Possible.of(value);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder description(Possible<String> value) {
      this.description_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder description(String value) {
      this.description_possible = Possible.of(value);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder tags(Possible<String> value) {
      this.tags_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder tags(String value) {
      this.tags_possible = Possible.of(value);
      return this;
    }

    /**
     * Builds a new {@link GuildStickerEditSpec GuildStickerEditSpec}.
     * @return An immutable instance of GuildStickerEditSpec
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public GuildStickerEditSpec build() {
      return GuildStickerEditSpec.validate(new GuildStickerEditSpec(reason, name_build(), description_build(), tags_build()));
    }

    private Possible<String> name_build() {
      return this.name_possible;
    }

    private Possible<String> description_build() {
      return this.description_possible;
    }

    private Possible<String> tags_build() {
      return this.tags_possible;
    }
  }
}
