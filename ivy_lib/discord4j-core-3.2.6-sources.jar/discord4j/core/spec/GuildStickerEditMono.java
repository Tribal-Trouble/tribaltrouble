package discord4j.core.spec;

import com.google.errorprone.annotations.Var;
import discord4j.core.object.entity.GuildSticker;
import discord4j.discordjson.possible.Possible;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.immutables.value.Generated;
import reactor.util.annotation.Nullable;

/**
 * Immutable implementation of {@link GuildStickerEditMonoGenerator}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code GuildStickerEditMono.of()}.
 */
@Generated(from = "GuildStickerEditMonoGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class GuildStickerEditMono extends GuildStickerEditMonoGenerator {
  private final @Nullable String reason;
  private final String name_value;
  private final boolean name_absent;
  private final String description_value;
  private final boolean description_absent;
  private final String tags_value;
  private final boolean tags_absent;
  private final GuildSticker sticker;

  private GuildStickerEditMono(GuildSticker sticker) {
    this.sticker = Objects.requireNonNull(sticker, "sticker");
    this.reason = null;
    Possible<String> name$impl = Possible.absent();
    Possible<String> description$impl = Possible.absent();
    Possible<String> tags$impl = Possible.absent();
    this.name_value = name$impl.toOptional().orElse(null);
    this.name_absent = name$impl.isAbsent();
    this.description_value = description$impl.toOptional().orElse(null);
    this.description_absent = description$impl.isAbsent();
    this.tags_value = tags$impl.toOptional().orElse(null);
    this.tags_absent = tags$impl.isAbsent();
    this.initShim = null;
  }

  private GuildStickerEditMono(
      @Nullable String reason,
      Possible<String> name,
      Possible<String> description,
      Possible<String> tags,
      GuildSticker sticker) {
    this.reason = reason;
    Possible<String> name$impl = name;
    Possible<String> description$impl = description;
    Possible<String> tags$impl = tags;
    this.sticker = sticker;
    this.name_value = name$impl.toOptional().orElse(null);
    this.name_absent = name$impl.isAbsent();
    this.description_value = description$impl.toOptional().orElse(null);
    this.description_absent = description$impl.isAbsent();
    this.tags_value = tags$impl.toOptional().orElse(null);
    this.tags_absent = tags$impl.isAbsent();
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "GuildStickerEditMonoGenerator", generator = "Immutables")
  private final class InitShim {
    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      return "Cannot build GuildStickerEditMono, attribute initializers form cycle " + attributes;
    }
  }

  /**
   * Returns the current audit log reason set on the spec.
   * @return The current audit log reason.
   */
  @Override
  public @Nullable String reason() {
    return reason;
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public Possible<String> name() {
    return name_absent ? Possible.absent() : Possible.of(name_value);
  }

  /**
   * @return The value of the {@code description} attribute
   */
  @Override
  public Possible<String> description() {
    return description_absent ? Possible.absent() : Possible.of(description_value);
  }

  /**
   * @return The value of the {@code tags} attribute
   */
  @Override
  public Possible<String> tags() {
    return tags_absent ? Possible.absent() : Possible.of(tags_value);
  }

  /**
   * @return The value of the {@code sticker} attribute
   */
  @Override
  public GuildSticker sticker() {
    return sticker;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerEditMono#reason() reason} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for reason (can be {@code null})
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerEditMono withReason(@Nullable String value) {
    if (Objects.equals(this.reason, value)) return this;
    return new GuildStickerEditMono(value, this.name(), this.description(), this.tags(), this.sticker);
  }

  public GuildStickerEditMono withName(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return new GuildStickerEditMono(this.reason, newValue, this.description(), this.tags(), this.sticker);
  }

  public GuildStickerEditMono withName(String value) {
    Possible<String> newValue = Possible.of(value);
    return new GuildStickerEditMono(this.reason, newValue, this.description(), this.tags(), this.sticker);
  }

  public GuildStickerEditMono withDescription(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return new GuildStickerEditMono(this.reason, this.name(), newValue, this.tags(), this.sticker);
  }

  public GuildStickerEditMono withDescription(String value) {
    Possible<String> newValue = Possible.of(value);
    return new GuildStickerEditMono(this.reason, this.name(), newValue, this.tags(), this.sticker);
  }

  public GuildStickerEditMono withTags(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return new GuildStickerEditMono(this.reason, this.name(), this.description(), newValue, this.sticker);
  }

  public GuildStickerEditMono withTags(String value) {
    Possible<String> newValue = Possible.of(value);
    return new GuildStickerEditMono(this.reason, this.name(), this.description(), newValue, this.sticker);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerEditMono#sticker() sticker} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for sticker
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerEditMono withSticker(GuildSticker value) {
    if (this.sticker == value) return this;
    GuildSticker newValue = Objects.requireNonNull(value, "sticker");
    return new GuildStickerEditMono(this.reason, this.name(), this.description(), this.tags(), newValue);
  }

  /**
   * This instance is equal to all instances of {@code GuildStickerEditMono} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof GuildStickerEditMono
        && equalTo(0, (GuildStickerEditMono) another);
  }

  private boolean equalTo(int synthetic, GuildStickerEditMono another) {
    return Objects.equals(reason, another.reason)
        && this.name().equals(another.name())
        && this.description().equals(another.description())
        && this.tags().equals(another.tags())
        && sticker.equals(another.sticker);
  }

  /**
   * Computes a hash code from attributes: {@code reason}, {@code name}, {@code description}, {@code tags}, {@code sticker}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(reason);
    h += (h << 5) + (name().hashCode());
    h += (h << 5) + (description().hashCode());
    h += (h << 5) + (tags().hashCode());
    h += (h << 5) + sticker.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code GuildStickerEditMono} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "GuildStickerEditMono{"
        + "reason=" + reason
        + ", name=" + (name().toString())
        + ", description=" + (description().toString())
        + ", tags=" + (tags().toString())
        + ", sticker=" + sticker
        + "}";
  }

  /**
   * Construct a new immutable {@code GuildStickerEditMono} instance.
   * @param sticker The value for the {@code sticker} attribute
   * @return An immutable GuildStickerEditMono instance
   */
  public static GuildStickerEditMono of(GuildSticker sticker) {
    return new GuildStickerEditMono(sticker);
  }

  /**
   * Creates an immutable copy of a {@link GuildStickerEditMonoGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable GuildStickerEditMono instance
   */
  static GuildStickerEditMono copyOf(GuildStickerEditMonoGenerator instance) {
    if (instance instanceof GuildStickerEditMono) {
      return (GuildStickerEditMono) instance;
    }
    return GuildStickerEditMono.of(instance.sticker())
        .withReason(instance.reason())
        .withName(instance.name())
        .withDescription(instance.description())
        .withTags(instance.tags());
  }

  public boolean isNamePresent() {
    return !name_absent;
  }

  public String nameOrElse(String defaultValue) {
    return !name_absent ? name_value : defaultValue;
  }

  public boolean isDescriptionPresent() {
    return !description_absent;
  }

  public String descriptionOrElse(String defaultValue) {
    return !description_absent ? description_value : defaultValue;
  }

  public boolean isTagsPresent() {
    return !tags_absent;
  }

  public String tagsOrElse(String defaultValue) {
    return !tags_absent ? tags_value : defaultValue;
  }
}
