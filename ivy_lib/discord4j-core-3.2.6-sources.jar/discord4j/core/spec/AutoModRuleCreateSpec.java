package discord4j.core.spec;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import discord4j.common.util.Snowflake;
import discord4j.discordjson.json.AutoModActionData;
import discord4j.discordjson.json.AutoModActionMetaData;
import discord4j.discordjson.json.AutoModTriggerMetaData;
import discord4j.discordjson.json.ImmutableAutoModActionData;
import discord4j.discordjson.possible.Possible;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.immutables.value.Generated;
import reactor.util.annotation.Nullable;

/**
 * Immutable implementation of {@link AutoModRuleCreateSpecGenerator}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code AutoModRuleCreateSpec.builder()}.
 * Use the static factory method to create immutable instances:
 * {@code AutoModRuleCreateSpec.of()}.
 */
@Generated(from = "AutoModRuleCreateSpecGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class AutoModRuleCreateSpec implements AutoModRuleCreateSpecGenerator {
  private final @Nullable String reason;
  private final String name;
  private final int eventType;
  private final int triggerType;
  private final AutoModTriggerMetaData triggerMetaData_value;
  private final boolean triggerMetaData_absent;
  private final List<AutoModActionData> actions;
  private final Boolean enabled_value;
  private final boolean enabled_absent;
  private final List<Snowflake> exemptRoles_value;
  private final boolean exemptRoles_absent;
  private final List<Snowflake> exemptChannels_value;
  private final boolean exemptChannels_absent;

  private AutoModRuleCreateSpec(String name, int eventType, int triggerType) {
    this.name = Objects.requireNonNull(name, "name");
    this.eventType = eventType;
    this.triggerType = triggerType;
    this.reason = null;
    Possible<AutoModTriggerMetaData> triggerMetaData$impl = Possible.absent();
    Possible<Boolean> enabled$impl = Possible.absent();
    Possible<List<Snowflake>> exemptRoles$impl = Possible.absent();
    Possible<List<Snowflake>> exemptChannels$impl = Possible.absent();
    this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null);
    this.triggerMetaData_absent = triggerMetaData$impl.isAbsent();
    this.enabled_value = enabled$impl.toOptional().orElse(null);
    this.enabled_absent = enabled$impl.isAbsent();
    this.exemptRoles_value = exemptRoles$impl.toOptional().orElse(null);
    this.exemptRoles_absent = exemptRoles$impl.isAbsent();
    this.exemptChannels_value = exemptChannels$impl.toOptional().orElse(null);
    this.exemptChannels_absent = exemptChannels$impl.isAbsent();
    this.actions = initShim.actions();
    this.initShim = null;
  }

  private AutoModRuleCreateSpec(AutoModRuleCreateSpec.Builder builder) {
    this.reason = builder.reason;
    this.name = builder.name;
    this.eventType = builder.eventType;
    this.triggerType = builder.triggerType;
    Possible<AutoModTriggerMetaData> triggerMetaData$impl = builder.triggerMetaData_build();
    Possible<Boolean> enabled$impl = builder.enabled_build();
    Possible<List<Snowflake>> exemptRoles$impl = builder.exemptRoles_build();
    Possible<List<Snowflake>> exemptChannels$impl = builder.exemptChannels_build();
    if (builder.actionsIsSet()) {
      initShim.actions(createUnmodifiableList(true, builder.actions));
    }
    this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null);
    this.triggerMetaData_absent = triggerMetaData$impl.isAbsent();
    this.enabled_value = enabled$impl.toOptional().orElse(null);
    this.enabled_absent = enabled$impl.isAbsent();
    this.exemptRoles_value = exemptRoles$impl.toOptional().orElse(null);
    this.exemptRoles_absent = exemptRoles$impl.isAbsent();
    this.exemptChannels_value = exemptChannels$impl.toOptional().orElse(null);
    this.exemptChannels_absent = exemptChannels$impl.isAbsent();
    this.actions = initShim.actions();
    this.initShim = null;
  }

  private AutoModRuleCreateSpec(
      @Nullable String reason,
      String name,
      int eventType,
      int triggerType,
      Possible<AutoModTriggerMetaData> triggerMetaData,
      List<AutoModActionData> actions,
      Possible<Boolean> enabled,
      Possible<List<Snowflake>> exemptRoles,
      Possible<List<Snowflake>> exemptChannels) {
    this.reason = reason;
    this.name = name;
    this.eventType = eventType;
    this.triggerType = triggerType;
    Possible<AutoModTriggerMetaData> triggerMetaData$impl = triggerMetaData;
    initShim.actions(actions);
    Possible<Boolean> enabled$impl = enabled;
    Possible<List<Snowflake>> exemptRoles$impl = exemptRoles;
    Possible<List<Snowflake>> exemptChannels$impl = exemptChannels;
    this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null);
    this.triggerMetaData_absent = triggerMetaData$impl.isAbsent();
    this.enabled_value = enabled$impl.toOptional().orElse(null);
    this.enabled_absent = enabled$impl.isAbsent();
    this.exemptRoles_value = exemptRoles$impl.toOptional().orElse(null);
    this.exemptRoles_absent = exemptRoles$impl.isAbsent();
    this.exemptChannels_value = exemptChannels$impl.toOptional().orElse(null);
    this.exemptChannels_absent = exemptChannels$impl.isAbsent();
    this.actions = initShim.actions();
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "AutoModRuleCreateSpecGenerator", generator = "Immutables")
  private final class InitShim {
    private byte actionsBuildStage = STAGE_UNINITIALIZED;
    private List<AutoModActionData> actions;

    List<AutoModActionData> actions() {
      if (actionsBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (actionsBuildStage == STAGE_UNINITIALIZED) {
        actionsBuildStage = STAGE_INITIALIZING;
        this.actions = createUnmodifiableList(false, createSafeList(actionsInitialize(), true, false));
        actionsBuildStage = STAGE_INITIALIZED;
      }
      return this.actions;
    }

    void actions(List<AutoModActionData> actions) {
      this.actions = actions;
      actionsBuildStage = STAGE_INITIALIZED;
    }

    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      if (actionsBuildStage == STAGE_INITIALIZING) attributes.add("actions");
      return "Cannot build AutoModRuleCreateSpec, attribute initializers form cycle " + attributes;
    }
  }

  private List<AutoModActionData> actionsInitialize() {
    return AutoModRuleCreateSpecGenerator.super.actions();
  }

  /**
   * Returns the current audit log reason set on the spec.
   * @return The current audit log reason.
   */
  @Override
  public @Nullable String reason() {
    return reason;
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public String name() {
    return name;
  }

  /**
   * @return The value of the {@code eventType} attribute
   */
  @Override
  public int eventType() {
    return eventType;
  }

  /**
   * @return The value of the {@code triggerType} attribute
   */
  @Override
  public int triggerType() {
    return triggerType;
  }

  /**
   * @return The value of the {@code triggerMetaData} attribute
   */
  @Override
  public Possible<AutoModTriggerMetaData> triggerMetaData() {
    return triggerMetaData_absent ? Possible.absent() : Possible.of(triggerMetaData_value);
  }

  /**
   * @return The value of the {@code actions} attribute
   */
  @Override
  public List<AutoModActionData> actions() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.actions()
        : this.actions;
  }

  /**
   * @return The value of the {@code enabled} attribute
   */
  @Override
  public Possible<Boolean> enabled() {
    return enabled_absent ? Possible.absent() : Possible.of(enabled_value);
  }

  /**
   * @return The value of the {@code exemptRoles} attribute
   */
  @Override
  public Possible<List<Snowflake>> exemptRoles() {
    return exemptRoles_absent ? Possible.absent() :
        Possible.of(exemptRoles_value);
  }

  /**
   * @return The value of the {@code exemptChannels} attribute
   */
  @Override
  public Possible<List<Snowflake>> exemptChannels() {
    return exemptChannels_absent ? Possible.absent() :
        Possible.of(exemptChannels_value);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleCreateSpec#reason() reason} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for reason (can be {@code null})
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleCreateSpec withReason(@Nullable String value) {
    if (Objects.equals(this.reason, value)) return this;
    return new AutoModRuleCreateSpec(
        value,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels());
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleCreateSpec#name() name} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for name
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleCreateSpec withName(String value) {
    String newValue = Objects.requireNonNull(value, "name");
    if (this.name.equals(newValue)) return this;
    return new AutoModRuleCreateSpec(
        this.reason,
        newValue,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels());
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleCreateSpec#eventType() eventType} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for eventType
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleCreateSpec withEventType(int value) {
    if (this.eventType == value) return this;
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        value,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels());
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleCreateSpec#triggerType() triggerType} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for triggerType
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleCreateSpec withTriggerType(int value) {
    if (this.triggerType == value) return this;
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        this.eventType,
        value,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels());
  }

  public AutoModRuleCreateSpec withTriggerMetaData(Possible<AutoModTriggerMetaData> value) {
    Possible<AutoModTriggerMetaData> newValue = Objects.requireNonNull(value);
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        newValue,
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels());
  }

  public AutoModRuleCreateSpec withTriggerMetaData(AutoModTriggerMetaData value) {
    Possible<AutoModTriggerMetaData> newValue = Possible.of(value);
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        newValue,
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels());
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleCreateSpec#actions() actions}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleCreateSpec withActions(AutoModActionData... elements) {
    List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        newValue,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels());
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleCreateSpec#actions() actions}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of actions elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleCreateSpec withActions(Iterable<? extends AutoModActionData> elements) {
    if (this.actions == elements) return this;
    List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        newValue,
        this.enabled(),
        this.exemptRoles(),
        this.exemptChannels());
  }

  public AutoModRuleCreateSpec withEnabled(Possible<Boolean> value) {
    Possible<Boolean> newValue = Objects.requireNonNull(value);
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        newValue,
        this.exemptRoles(),
        this.exemptChannels());
  }

  public AutoModRuleCreateSpec withEnabled(Boolean value) {
    Possible<Boolean> newValue = Possible.of(value);
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        newValue,
        this.exemptRoles(),
        this.exemptChannels());
  }

  public AutoModRuleCreateSpec withExemptRoles(Possible<List<Snowflake>> possible) {
    Possible<List<Snowflake>> newValue = Objects.requireNonNull(possible);
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        newValue,
        this.exemptChannels());
  }

  public AutoModRuleCreateSpec withExemptRoles(java.lang.Iterable<Snowflake> elements) {
    Possible<List<Snowflake>> newValue = Possible.of(
      StreamSupport.stream(Objects.requireNonNull(elements).spliterator(), false).collect(Collectors.toList()));
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        newValue,
        this.exemptChannels());
  }

  @SafeVarargs
  public final AutoModRuleCreateSpec withExemptRoles(Snowflake... elements) {
    Possible<List<Snowflake>> newValue = Possible.of(Arrays.asList(elements));
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        newValue,
        this.exemptChannels());
  }

  public AutoModRuleCreateSpec withExemptChannels(Possible<List<Snowflake>> possible) {
    Possible<List<Snowflake>> newValue = Objects.requireNonNull(possible);
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        newValue);
  }

  public AutoModRuleCreateSpec withExemptChannels(java.lang.Iterable<Snowflake> elements) {
    Possible<List<Snowflake>> newValue = Possible.of(
      StreamSupport.stream(Objects.requireNonNull(elements).spliterator(), false).collect(Collectors.toList()));
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        newValue);
  }

  @SafeVarargs
  public final AutoModRuleCreateSpec withExemptChannels(Snowflake... elements) {
    Possible<List<Snowflake>> newValue = Possible.of(Arrays.asList(elements));
    return new AutoModRuleCreateSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerType,
        this.triggerMetaData(),
        this.actions,
        this.enabled(),
        this.exemptRoles(),
        newValue);
  }

  /**
   * This instance is equal to all instances of {@code AutoModRuleCreateSpec} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof AutoModRuleCreateSpec
        && equalTo(0, (AutoModRuleCreateSpec) another);
  }

  private boolean equalTo(int synthetic, AutoModRuleCreateSpec another) {
    return Objects.equals(reason, another.reason)
        && name.equals(another.name)
        && eventType == another.eventType
        && triggerType == another.triggerType
        && this.triggerMetaData().equals(another.triggerMetaData())
        && actions.equals(another.actions)
        && this.enabled().equals(another.enabled())
        && Objects.equals(exemptRoles_value, another.exemptRoles_value)
        && Objects.equals(exemptChannels_value, another.exemptChannels_value);
  }

  /**
   * Computes a hash code from attributes: {@code reason}, {@code name}, {@code eventType}, {@code triggerType}, {@code triggerMetaData}, {@code actions}, {@code enabled}, {@code exemptRoles}, {@code exemptChannels}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(reason);
    h += (h << 5) + name.hashCode();
    h += (h << 5) + eventType;
    h += (h << 5) + triggerType;
    h += (h << 5) + (triggerMetaData().hashCode());
    h += (h << 5) + actions.hashCode();
    h += (h << 5) + (enabled().hashCode());
    h += (h << 5) + (Objects.hashCode(exemptRoles_value));
    h += (h << 5) + (Objects.hashCode(exemptChannels_value));
    return h;
  }

  /**
   * Prints the immutable value {@code AutoModRuleCreateSpec} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "AutoModRuleCreateSpec{"
        + "reason=" + reason
        + ", name=" + name
        + ", eventType=" + eventType
        + ", triggerType=" + triggerType
        + ", triggerMetaData=" + (triggerMetaData().toString())
        + ", actions=" + actions
        + ", enabled=" + (enabled().toString())
        + ", exemptRoles=" + (Objects.toString(exemptRoles_value))
        + ", exemptChannels=" + (Objects.toString(exemptChannels_value))
        + "}";
  }

  /**
   * Construct a new immutable {@code AutoModRuleCreateSpec} instance.
   * @param name The value for the {@code name} attribute
   * @param eventType The value for the {@code eventType} attribute
   * @param triggerType The value for the {@code triggerType} attribute
   * @return An immutable AutoModRuleCreateSpec instance
   */
  public static AutoModRuleCreateSpec of(String name, int eventType, int triggerType) {
    return new AutoModRuleCreateSpec(name, eventType, triggerType);
  }

  /**
   * Creates an immutable copy of a {@link AutoModRuleCreateSpecGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable AutoModRuleCreateSpec instance
   */
  static AutoModRuleCreateSpec copyOf(AutoModRuleCreateSpecGenerator instance) {
    if (instance instanceof AutoModRuleCreateSpec) {
      return (AutoModRuleCreateSpec) instance;
    }
    return AutoModRuleCreateSpec.builder()
        .from(instance)
        .build();
  }

  public boolean isTriggerMetaDataPresent() {
    return !triggerMetaData_absent;
  }

  public AutoModTriggerMetaData triggerMetaDataOrElse(AutoModTriggerMetaData defaultValue) {
    return !triggerMetaData_absent ? triggerMetaData_value : defaultValue;
  }

  public boolean isEnabledPresent() {
    return !enabled_absent;
  }

  public Boolean enabledOrElse(Boolean defaultValue) {
    return !enabled_absent ? enabled_value : defaultValue;
  }

  public boolean isExemptRolesPresent() {
    return !exemptRoles_absent;
  }

  public List<Snowflake> exemptRolesOrElse(List<Snowflake> defaultValue) {
    return !exemptRoles_absent ? exemptRoles_value : defaultValue;
  }

  public boolean isExemptChannelsPresent() {
    return !exemptChannels_absent;
  }

  public List<Snowflake> exemptChannelsOrElse(List<Snowflake> defaultValue) {
    return !exemptChannels_absent ? exemptChannels_value : defaultValue;
  }

  /**
   * Creates a builder for {@link AutoModRuleCreateSpec AutoModRuleCreateSpec}.
   * <pre>
   * AutoModRuleCreateSpec.builder()
   *    .reason(String | null) // nullable {@link AutoModRuleCreateSpec#reason() reason}
   *    .name(String) // required {@link AutoModRuleCreateSpec#name() name}
   *    .eventType(int) // required {@link AutoModRuleCreateSpec#eventType() eventType}
   *    .triggerType(int) // required {@link AutoModRuleCreateSpec#triggerType() triggerType}
   *    .triggerMetaData(discord4j.discordjson.possible.Possible&amp;lt;discord4j.discordjson.json.AutoModTriggerMetaData&amp;gt;) // {@link AutoModRuleCreateSpec#triggerMetaData() triggerMetaData}
   *    .addAction|addAllActions(discord4j.discordjson.json.AutoModActionData) // {@link AutoModRuleCreateSpec#actions() actions} elements
   *    .enabled(discord4j.discordjson.possible.Possible&amp;lt;Boolean&amp;gt;) // {@link AutoModRuleCreateSpec#enabled() enabled}
   *    .exemptRoles(discord4j.discordjson.possible.Possible&amp;lt;List&amp;lt;discord4j.common.util.Snowflake&amp;gt;&amp;gt;) // {@link AutoModRuleCreateSpec#exemptRoles() exemptRoles}
   *    .exemptChannels(discord4j.discordjson.possible.Possible&amp;lt;List&amp;lt;discord4j.common.util.Snowflake&amp;gt;&amp;gt;) // {@link AutoModRuleCreateSpec#exemptChannels() exemptChannels}
   *    .build();
   * </pre>
   * @return A new AutoModRuleCreateSpec builder
   */
  public static AutoModRuleCreateSpec.Builder builder() {
    return new AutoModRuleCreateSpec.Builder();
  }

  /**
   * Builds instances of type {@link AutoModRuleCreateSpec AutoModRuleCreateSpec}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "AutoModRuleCreateSpecGenerator", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_NAME = 0x1L;
    private static final long INIT_BIT_EVENT_TYPE = 0x2L;
    private static final long INIT_BIT_TRIGGER_TYPE = 0x4L;
    private static final long OPT_BIT_ACTIONS = 0x1L;
    private long initBits = 0x7L;
    private long optBits;

    private Possible<AutoModTriggerMetaData> triggerMetaData_possible = Possible.absent();
    private Possible<Boolean> enabled_possible = Possible.absent();
    private List<Snowflake> exemptRoles_list = null;
    private List<Snowflake> exemptChannels_list = null;
    private String reason;
    private String name;
    private int eventType;
    private int triggerType;
    private List<AutoModActionData> actions = new ArrayList<AutoModActionData>();

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code AutoModRuleCreateSpec} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * Collection elements and entries will be added, not replaced.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder from(AutoModRuleCreateSpec instance) {
      return from((AutoModRuleCreateSpecGenerator) instance);
    }

    /**
     * Copy abstract value type {@code AutoModRuleCreateSpecGenerator} instance into builder.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    final Builder from(AutoModRuleCreateSpecGenerator instance) {
      Objects.requireNonNull(instance, "instance");
      String reasonValue = instance.reason();
      if (reasonValue != null) {
        reason(reasonValue);
      }
      name(instance.name());
      eventType(instance.eventType());
      triggerType(instance.triggerType());
      triggerMetaData(instance.triggerMetaData());
      addAllActions(instance.actions());
      enabled(instance.enabled());
      exemptRoles(instance.exemptRoles());
      exemptChannels(instance.exemptChannels());
      return this;
    }

    /**
     * Initializes the value for the {@link AutoModRuleCreateSpec#reason() reason} attribute.
     * @param reason The value for reason (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder reason(@Nullable String reason) {
      this.reason = reason;
      return this;
    }

    /**
     * Initializes the value for the {@link AutoModRuleCreateSpec#name() name} attribute.
     * @param name The value for name 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder name(String name) {
      this.name = Objects.requireNonNull(name, "name");
      initBits &= ~INIT_BIT_NAME;
      return this;
    }

    /**
     * Initializes the value for the {@link AutoModRuleCreateSpec#eventType() eventType} attribute.
     * @param eventType The value for eventType 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder eventType(int eventType) {
      this.eventType = eventType;
      initBits &= ~INIT_BIT_EVENT_TYPE;
      return this;
    }

    /**
     * Initializes the value for the {@link AutoModRuleCreateSpec#triggerType() triggerType} attribute.
     * @param triggerType The value for triggerType 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder triggerType(int triggerType) {
      this.triggerType = triggerType;
      initBits &= ~INIT_BIT_TRIGGER_TYPE;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder triggerMetaData(Possible<AutoModTriggerMetaData> value) {
      this.triggerMetaData_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder triggerMetaData(AutoModTriggerMetaData value) {
      this.triggerMetaData_possible = Possible.of(value);
      return this;
    }

    /**
     * Adds one element to {@link AutoModRuleCreateSpec#actions() actions} list.
     * @param element A actions element
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addAction(AutoModActionData element) {
      element = ImmutableAutoModActionData.copyOf(element);
      this.actions.add(Objects.requireNonNull(element, "actions element"));
      optBits |= OPT_BIT_ACTIONS;
      return this;
    }

    /**
     * Constructs and adds an element for the {@link AutoModRuleCreateSpec#actions() actions} list.
     * @param type The value for {@code actions.type} 
     * @param metadata The value for {@code actions.metadata} 
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder addAction(int type, Possible<AutoModActionMetaData> metadata) {
      return addAction(ImmutableAutoModActionData.of(type, metadata));
    }

    /**
     * Adds elements to {@link AutoModRuleCreateSpec#actions() actions} list.
     * @param elements An array of actions elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addActions(AutoModActionData... elements) {
      for (AutoModActionData element : elements) {
        element = ImmutableAutoModActionData.copyOf(element);
        this.actions.add(Objects.requireNonNull(element, "actions element"));
      }
      optBits |= OPT_BIT_ACTIONS;
      return this;
    }


    /**
     * Sets or replaces all elements for {@link AutoModRuleCreateSpec#actions() actions} list.
     * @param elements An iterable of actions elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder actions(Iterable<? extends AutoModActionData> elements) {
      this.actions.clear();
      return addAllActions(elements);
    }

    /**
     * Adds elements to {@link AutoModRuleCreateSpec#actions() actions} list.
     * @param elements An iterable of actions elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addAllActions(Iterable<? extends AutoModActionData> elements) {
      for (AutoModActionData element : elements) {
        element = ImmutableAutoModActionData.copyOf(element);
        this.actions.add(Objects.requireNonNull(element, "actions element"));
      }
      optBits |= OPT_BIT_ACTIONS;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder enabled(Possible<Boolean> value) {
      this.enabled_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder enabled(Boolean value) {
      this.enabled_possible = Possible.of(value);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder addExemptRole(Snowflake element) {
      exemptRoles_getOrCreate().add(element);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder addAllExemptRoles(List<Snowflake> elements) {
      exemptRoles_getOrCreate().addAll(elements);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder exemptRoles(Possible<List<Snowflake>> elements) {
      this.exemptRoles_list = null;
      elements.toOptional().ifPresent(e -> exemptRoles_getOrCreate().addAll(e));
      return this;
    }

    @CanIgnoreReturnValue
    public Builder exemptRoles(List<Snowflake> elements) {
      this.exemptRoles_list = new ArrayList<>(elements);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder exemptRoles(java.lang.Iterable<Snowflake> elements) {
      this.exemptRoles_list = StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
      return this;
    }

    @CanIgnoreReturnValue
    public Builder addExemptChannel(Snowflake element) {
      exemptChannels_getOrCreate().add(element);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder addAllExemptChannels(List<Snowflake> elements) {
      exemptChannels_getOrCreate().addAll(elements);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder exemptChannels(Possible<List<Snowflake>> elements) {
      this.exemptChannels_list = null;
      elements.toOptional().ifPresent(e -> exemptChannels_getOrCreate().addAll(e));
      return this;
    }

    @CanIgnoreReturnValue
    public Builder exemptChannels(List<Snowflake> elements) {
      this.exemptChannels_list = new ArrayList<>(elements);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder exemptChannels(java.lang.Iterable<Snowflake> elements) {
      this.exemptChannels_list = StreamSupport.stream(elements.spliterator(), false).collect(Collectors.toList());
      return this;
    }

    /**
     * Builds a new {@link AutoModRuleCreateSpec AutoModRuleCreateSpec}.
     * @return An immutable instance of AutoModRuleCreateSpec
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public AutoModRuleCreateSpec build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new AutoModRuleCreateSpec(this);
    }

    private boolean actionsIsSet() {
      return (optBits & OPT_BIT_ACTIONS) != 0;
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_NAME) != 0) attributes.add("name");
      if ((initBits & INIT_BIT_EVENT_TYPE) != 0) attributes.add("eventType");
      if ((initBits & INIT_BIT_TRIGGER_TYPE) != 0) attributes.add("triggerType");
      return "Cannot build AutoModRuleCreateSpec, some of required attributes are not set " + attributes;
    }

    private Possible<AutoModTriggerMetaData> triggerMetaData_build() {
      return this.triggerMetaData_possible;
    }

    private Possible<Boolean> enabled_build() {
      return this.enabled_possible;
    }

    private Possible<List<Snowflake>> exemptRoles_build() {
      return this.exemptRoles_list == null ? Possible.absent() :
          Possible.of(this.exemptRoles_list);
    }

    private List<Snowflake> exemptRoles_getOrCreate() {
      if (this.exemptRoles_list == null) {
        this.exemptRoles_list = new ArrayList<>();
      }
      return this.exemptRoles_list;
    }

    private Possible<List<Snowflake>> exemptChannels_build() {
      return this.exemptChannels_list == null ? Possible.absent() :
          Possible.of(this.exemptChannels_list);
    }

    private List<Snowflake> exemptChannels_getOrCreate() {
      if (this.exemptChannels_list == null) {
        this.exemptChannels_list = new ArrayList<>();
      }
      return this.exemptChannels_list;
    }
  }

  private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
    ArrayList<T> list;
    if (iterable instanceof Collection<?>) {
      int size = ((Collection<?>) iterable).size();
      if (size == 0) return Collections.emptyList();
      list = new ArrayList<>();
    } else {
      list = new ArrayList<>();
    }
    for (T element : iterable) {
      if (skipNulls && element == null) continue;
      if (checkNulls) Objects.requireNonNull(element, "element");
      list.add(element);
    }
    return list;
  }

  private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
    switch(list.size()) {
    case 0: return Collections.emptyList();
    case 1: return Collections.singletonList(list.get(0));
    default:
      if (clone) {
        return Collections.unmodifiableList(new ArrayList<>(list));
      } else {
        if (list instanceof ArrayList<?>) {
          ((ArrayList<?>) list).trimToSize();
        }
        return Collections.unmodifiableList(list);
      }
    }
  }
}
