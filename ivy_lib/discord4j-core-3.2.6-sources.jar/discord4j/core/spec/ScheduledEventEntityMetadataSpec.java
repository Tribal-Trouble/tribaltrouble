package discord4j.core.spec;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import discord4j.discordjson.possible.Possible;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link ScheduledEventEntityMetadataSpecGenerator}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ScheduledEventEntityMetadataSpec.builder()}.
 */
@Generated(from = "ScheduledEventEntityMetadataSpecGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class ScheduledEventEntityMetadataSpec
    implements ScheduledEventEntityMetadataSpecGenerator {
  private final String location_value;
  private final boolean location_absent;

  private ScheduledEventEntityMetadataSpec(Possible<String> location) {
    Possible<String> location$impl = location;
    this.location_value = location$impl.toOptional().orElse(null);
    this.location_absent = location$impl.isAbsent();
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "ScheduledEventEntityMetadataSpecGenerator", generator = "Immutables")
  private final class InitShim {
    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      return "Cannot build ScheduledEventEntityMetadataSpec, attribute initializers form cycle " + attributes;
    }
  }

  /**
   * @return The value of the {@code location} attribute
   */
  @Override
  public Possible<String> location() {
    return location_absent ? Possible.absent() : Possible.of(location_value);
  }

  public ScheduledEventEntityMetadataSpec withLocation(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEntityMetadataSpec(newValue);
  }

  public ScheduledEventEntityMetadataSpec withLocation(String value) {
    Possible<String> newValue = Possible.of(value);
    return new ScheduledEventEntityMetadataSpec(newValue);
  }

  /**
   * This instance is equal to all instances of {@code ScheduledEventEntityMetadataSpec} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof ScheduledEventEntityMetadataSpec
        && equalTo(0, (ScheduledEventEntityMetadataSpec) another);
  }

  private boolean equalTo(int synthetic, ScheduledEventEntityMetadataSpec another) {
    return this.location().equals(another.location());
  }

  /**
   * Computes a hash code from attributes: {@code location}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + (location().hashCode());
    return h;
  }

  /**
   * Prints the immutable value {@code ScheduledEventEntityMetadataSpec} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "ScheduledEventEntityMetadataSpec{"
        + "location=" + (location().toString())
        + "}";
  }

  /**
   * Creates an immutable copy of a {@link ScheduledEventEntityMetadataSpecGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable ScheduledEventEntityMetadataSpec instance
   */
  public static ScheduledEventEntityMetadataSpec copyOf(ScheduledEventEntityMetadataSpecGenerator instance) {
    if (instance instanceof ScheduledEventEntityMetadataSpec) {
      return (ScheduledEventEntityMetadataSpec) instance;
    }
    return ScheduledEventEntityMetadataSpec.builder()
        .from(instance)
        .build();
  }

  public boolean isLocationPresent() {
    return !location_absent;
  }

  public String locationOrElse(String defaultValue) {
    return !location_absent ? location_value : defaultValue;
  }

  /**
   * Creates a builder for {@link ScheduledEventEntityMetadataSpec ScheduledEventEntityMetadataSpec}.
   * <pre>
   * ScheduledEventEntityMetadataSpec.builder()
   *    .location(discord4j.discordjson.possible.Possible&amp;lt;String&amp;gt;) // {@link ScheduledEventEntityMetadataSpecGenerator#location() location}
   *    .build();
   * </pre>
   * @return A new ScheduledEventEntityMetadataSpec builder
   */
  public static ScheduledEventEntityMetadataSpec.Builder builder() {
    return new ScheduledEventEntityMetadataSpec.Builder();
  }

  /**
   * Builds instances of type {@link ScheduledEventEntityMetadataSpec ScheduledEventEntityMetadataSpec}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "ScheduledEventEntityMetadataSpecGenerator", generator = "Immutables")
  public static final class Builder {
    private Possible<String> location_possible = Possible.absent();

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code ScheduledEventEntityMetadataSpecGenerator} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(ScheduledEventEntityMetadataSpecGenerator instance) {
      Objects.requireNonNull(instance, "instance");
      location(instance.location());
      return this;
    }

    @CanIgnoreReturnValue
    public Builder location(Possible<String> value) {
      this.location_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder location(String value) {
      this.location_possible = Possible.of(value);
      return this;
    }

    /**
     * Builds a new {@link ScheduledEventEntityMetadataSpec ScheduledEventEntityMetadataSpec}.
     * @return An immutable instance of ScheduledEventEntityMetadataSpec
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ScheduledEventEntityMetadataSpec build() {
      return new ScheduledEventEntityMetadataSpec(location_build());
    }

    private Possible<String> location_build() {
      return this.location_possible;
    }
  }
}
