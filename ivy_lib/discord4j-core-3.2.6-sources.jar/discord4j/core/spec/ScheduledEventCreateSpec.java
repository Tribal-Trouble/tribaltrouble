package discord4j.core.spec;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import discord4j.common.util.Snowflake;
import discord4j.core.object.entity.ScheduledEvent;
import discord4j.discordjson.possible.Possible;
import discord4j.rest.util.Image;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.immutables.value.Generated;
import reactor.util.annotation.Nullable;

/**
 * Immutable implementation of {@link ScheduledEventCreateSpecGenerator}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ScheduledEventCreateSpec.builder()}.
 * Use the static factory method to create immutable instances:
 * {@code ScheduledEventCreateSpec.of()}.
 */
@Generated(from = "ScheduledEventCreateSpecGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class ScheduledEventCreateSpec implements ScheduledEventCreateSpecGenerator {
  private final @Nullable String reason;
  private final Snowflake channelId_value;
  private final boolean channelId_absent;
  private final ScheduledEventEntityMetadataSpec entityMetadata_value;
  private final boolean entityMetadata_absent;
  private final String name;
  private final ScheduledEvent.PrivacyLevel privacyLevel;
  private final Instant scheduledStartTime;
  private final Instant scheduledEndTime_value;
  private final boolean scheduledEndTime_absent;
  private final String description_value;
  private final boolean description_absent;
  private final ScheduledEvent.EntityType entityType;
  private final Image image_value;
  private final boolean image_absent;

  private ScheduledEventCreateSpec(
      String name,
      ScheduledEvent.PrivacyLevel privacyLevel,
      Instant scheduledStartTime,
      ScheduledEvent.EntityType entityType) {
    this.name = Objects.requireNonNull(name, "name");
    this.privacyLevel = Objects.requireNonNull(privacyLevel, "privacyLevel");
    this.scheduledStartTime = Objects.requireNonNull(scheduledStartTime, "scheduledStartTime");
    this.entityType = Objects.requireNonNull(entityType, "entityType");
    this.reason = null;
    Possible<Snowflake> channelId$impl = Possible.absent();
    Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = Possible.absent();
    Possible<Instant> scheduledEndTime$impl = Possible.absent();
    Possible<String> description$impl = Possible.absent();
    Possible<Image> image$impl = Possible.absent();
    this.channelId_value = channelId$impl.toOptional().orElse(null);
    this.channelId_absent = channelId$impl.isAbsent();
    this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null);
    this.entityMetadata_absent = entityMetadata$impl.isAbsent();
    this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
    this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
    this.description_value = description$impl.toOptional().orElse(null);
    this.description_absent = description$impl.isAbsent();
    this.image_value = image$impl.toOptional().orElse(null);
    this.image_absent = image$impl.isAbsent();
    this.initShim = null;
  }

  private ScheduledEventCreateSpec(
      @Nullable String reason,
      Possible<Snowflake> channelId,
      Possible<ScheduledEventEntityMetadataSpec> entityMetadata,
      String name,
      ScheduledEvent.PrivacyLevel privacyLevel,
      Instant scheduledStartTime,
      Possible<Instant> scheduledEndTime,
      Possible<String> description,
      ScheduledEvent.EntityType entityType,
      Possible<Image> image) {
    this.reason = reason;
    Possible<Snowflake> channelId$impl = channelId;
    Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = entityMetadata;
    this.name = name;
    this.privacyLevel = privacyLevel;
    this.scheduledStartTime = scheduledStartTime;
    Possible<Instant> scheduledEndTime$impl = scheduledEndTime;
    Possible<String> description$impl = description;
    this.entityType = entityType;
    Possible<Image> image$impl = image;
    this.channelId_value = channelId$impl.toOptional().orElse(null);
    this.channelId_absent = channelId$impl.isAbsent();
    this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null);
    this.entityMetadata_absent = entityMetadata$impl.isAbsent();
    this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
    this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
    this.description_value = description$impl.toOptional().orElse(null);
    this.description_absent = description$impl.isAbsent();
    this.image_value = image$impl.toOptional().orElse(null);
    this.image_absent = image$impl.isAbsent();
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "ScheduledEventCreateSpecGenerator", generator = "Immutables")
  private final class InitShim {
    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      return "Cannot build ScheduledEventCreateSpec, attribute initializers form cycle " + attributes;
    }
  }

  /**
   * Returns the current audit log reason set on the spec.
   * @return The current audit log reason.
   */
  @Override
  public @Nullable String reason() {
    return reason;
  }

  /**
   * @return The value of the {@code channelId} attribute
   */
  @Override
  public Possible<Snowflake> channelId() {
    return channelId_absent ? Possible.absent() : Possible.of(channelId_value);
  }

  /**
   * @return The value of the {@code entityMetadata} attribute
   */
  @Override
  public Possible<ScheduledEventEntityMetadataSpec> entityMetadata() {
    return entityMetadata_absent ? Possible.absent() : Possible.of(entityMetadata_value);
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public String name() {
    return name;
  }

  /**
   * @return The value of the {@code privacyLevel} attribute
   */
  @Override
  public ScheduledEvent.PrivacyLevel privacyLevel() {
    return privacyLevel;
  }

  /**
   * @return The value of the {@code scheduledStartTime} attribute
   */
  @Override
  public Instant scheduledStartTime() {
    return scheduledStartTime;
  }

  /**
   * @return The value of the {@code scheduledEndTime} attribute
   */
  @Override
  public Possible<Instant> scheduledEndTime() {
    return scheduledEndTime_absent ? Possible.absent() : Possible.of(scheduledEndTime_value);
  }

  /**
   * @return The value of the {@code description} attribute
   */
  @Override
  public Possible<String> description() {
    return description_absent ? Possible.absent() : Possible.of(description_value);
  }

  /**
   * @return The value of the {@code entityType} attribute
   */
  @Override
  public ScheduledEvent.EntityType entityType() {
    return entityType;
  }

  /**
   * @return The value of the {@code image} attribute
   */
  @Override
  public Possible<Image> image() {
    return image_absent ? Possible.absent() : Possible.of(image_value);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventCreateSpecGenerator#reason() reason} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for reason (can be {@code null})
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventCreateSpec withReason(@Nullable String value) {
    if (Objects.equals(this.reason, value)) return this;
    return new ScheduledEventCreateSpec(
        value,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image());
  }

  public ScheduledEventCreateSpec withChannelId(Possible<Snowflake> value) {
    Possible<Snowflake> newValue = Objects.requireNonNull(value);
    return new ScheduledEventCreateSpec(
        this.reason,
        newValue,
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image());
  }

  public ScheduledEventCreateSpec withChannelId(Snowflake value) {
    Possible<Snowflake> newValue = Possible.of(value);
    return new ScheduledEventCreateSpec(
        this.reason,
        newValue,
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image());
  }

  public ScheduledEventCreateSpec withEntityMetadata(Possible<ScheduledEventEntityMetadataSpec> value) {
    Possible<ScheduledEventEntityMetadataSpec> newValue = Objects.requireNonNull(value);
    return new ScheduledEventCreateSpec(
        this.reason,
        this.channelId(),
        newValue,
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image());
  }

  public ScheduledEventCreateSpec withEntityMetadata(ScheduledEventEntityMetadataSpec value) {
    Possible<ScheduledEventEntityMetadataSpec> newValue = Possible.of(value);
    return new ScheduledEventCreateSpec(
        this.reason,
        this.channelId(),
        newValue,
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image());
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventCreateSpecGenerator#name() name} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for name
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventCreateSpec withName(String value) {
    String newValue = Objects.requireNonNull(value, "name");
    if (this.name.equals(newValue)) return this;
    return new ScheduledEventCreateSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        newValue,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image());
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventCreateSpecGenerator#privacyLevel() privacyLevel} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for privacyLevel
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventCreateSpec withPrivacyLevel(ScheduledEvent.PrivacyLevel value) {
    ScheduledEvent.PrivacyLevel newValue = Objects.requireNonNull(value, "privacyLevel");
    if (this.privacyLevel == newValue) return this;
    return new ScheduledEventCreateSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        newValue,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image());
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventCreateSpecGenerator#scheduledStartTime() scheduledStartTime} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for scheduledStartTime
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventCreateSpec withScheduledStartTime(Instant value) {
    if (this.scheduledStartTime == value) return this;
    Instant newValue = Objects.requireNonNull(value, "scheduledStartTime");
    return new ScheduledEventCreateSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        newValue,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image());
  }

  public ScheduledEventCreateSpec withScheduledEndTime(Possible<Instant> value) {
    Possible<Instant> newValue = Objects.requireNonNull(value);
    return new ScheduledEventCreateSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        newValue,
        this.description(),
        this.entityType,
        this.image());
  }

  public ScheduledEventCreateSpec withScheduledEndTime(Instant value) {
    Possible<Instant> newValue = Possible.of(value);
    return new ScheduledEventCreateSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        newValue,
        this.description(),
        this.entityType,
        this.image());
  }

  public ScheduledEventCreateSpec withDescription(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return new ScheduledEventCreateSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        newValue,
        this.entityType,
        this.image());
  }

  public ScheduledEventCreateSpec withDescription(String value) {
    Possible<String> newValue = Possible.of(value);
    return new ScheduledEventCreateSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        newValue,
        this.entityType,
        this.image());
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventCreateSpecGenerator#entityType() entityType} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for entityType
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventCreateSpec withEntityType(ScheduledEvent.EntityType value) {
    ScheduledEvent.EntityType newValue = Objects.requireNonNull(value, "entityType");
    if (this.entityType == newValue) return this;
    return new ScheduledEventCreateSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        newValue,
        this.image());
  }

  public ScheduledEventCreateSpec withImage(Possible<Image> value) {
    Possible<Image> newValue = Objects.requireNonNull(value);
    return new ScheduledEventCreateSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        newValue);
  }

  public ScheduledEventCreateSpec withImage(Image value) {
    Possible<Image> newValue = Possible.of(value);
    return new ScheduledEventCreateSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        newValue);
  }

  /**
   * This instance is equal to all instances of {@code ScheduledEventCreateSpec} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof ScheduledEventCreateSpec
        && equalTo(0, (ScheduledEventCreateSpec) another);
  }

  private boolean equalTo(int synthetic, ScheduledEventCreateSpec another) {
    return Objects.equals(reason, another.reason)
        && this.channelId().equals(another.channelId())
        && this.entityMetadata().equals(another.entityMetadata())
        && name.equals(another.name)
        && privacyLevel.equals(another.privacyLevel)
        && scheduledStartTime.equals(another.scheduledStartTime)
        && this.scheduledEndTime().equals(another.scheduledEndTime())
        && this.description().equals(another.description())
        && entityType.equals(another.entityType)
        && this.image().equals(another.image());
  }

  /**
   * Computes a hash code from attributes: {@code reason}, {@code channelId}, {@code entityMetadata}, {@code name}, {@code privacyLevel}, {@code scheduledStartTime}, {@code scheduledEndTime}, {@code description}, {@code entityType}, {@code image}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(reason);
    h += (h << 5) + (channelId().hashCode());
    h += (h << 5) + (entityMetadata().hashCode());
    h += (h << 5) + name.hashCode();
    h += (h << 5) + privacyLevel.hashCode();
    h += (h << 5) + scheduledStartTime.hashCode();
    h += (h << 5) + (scheduledEndTime().hashCode());
    h += (h << 5) + (description().hashCode());
    h += (h << 5) + entityType.hashCode();
    h += (h << 5) + (image().hashCode());
    return h;
  }

  /**
   * Prints the immutable value {@code ScheduledEventCreateSpec} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "ScheduledEventCreateSpec{"
        + "reason=" + reason
        + ", channelId=" + (channelId().toString())
        + ", entityMetadata=" + (entityMetadata().toString())
        + ", name=" + name
        + ", privacyLevel=" + privacyLevel
        + ", scheduledStartTime=" + scheduledStartTime
        + ", scheduledEndTime=" + (scheduledEndTime().toString())
        + ", description=" + (description().toString())
        + ", entityType=" + entityType
        + ", image=" + (image().toString())
        + "}";
  }

  /**
   * Construct a new immutable {@code ScheduledEventCreateSpec} instance.
   * @param name The value for the {@code name} attribute
   * @param privacyLevel The value for the {@code privacyLevel} attribute
   * @param scheduledStartTime The value for the {@code scheduledStartTime} attribute
   * @param entityType The value for the {@code entityType} attribute
   * @return An immutable ScheduledEventCreateSpec instance
   */
  public static ScheduledEventCreateSpec of(String name, ScheduledEvent.PrivacyLevel privacyLevel, Instant scheduledStartTime, ScheduledEvent.EntityType entityType) {
    return new ScheduledEventCreateSpec(name, privacyLevel, scheduledStartTime, entityType);
  }

  /**
   * Creates an immutable copy of a {@link ScheduledEventCreateSpecGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable ScheduledEventCreateSpec instance
   */
  public static ScheduledEventCreateSpec copyOf(ScheduledEventCreateSpecGenerator instance) {
    if (instance instanceof ScheduledEventCreateSpec) {
      return (ScheduledEventCreateSpec) instance;
    }
    return ScheduledEventCreateSpec.builder()
        .from(instance)
        .build();
  }

  public boolean isChannelIdPresent() {
    return !channelId_absent;
  }

  public Snowflake channelIdOrElse(Snowflake defaultValue) {
    return !channelId_absent ? channelId_value : defaultValue;
  }

  public boolean isEntityMetadataPresent() {
    return !entityMetadata_absent;
  }

  public ScheduledEventEntityMetadataSpec entityMetadataOrElse(ScheduledEventEntityMetadataSpec defaultValue) {
    return !entityMetadata_absent ? entityMetadata_value : defaultValue;
  }

  public boolean isScheduledEndTimePresent() {
    return !scheduledEndTime_absent;
  }

  public Instant scheduledEndTimeOrElse(Instant defaultValue) {
    return !scheduledEndTime_absent ? scheduledEndTime_value : defaultValue;
  }

  public boolean isDescriptionPresent() {
    return !description_absent;
  }

  public String descriptionOrElse(String defaultValue) {
    return !description_absent ? description_value : defaultValue;
  }

  public boolean isImagePresent() {
    return !image_absent;
  }

  public Image imageOrElse(Image defaultValue) {
    return !image_absent ? image_value : defaultValue;
  }

  /**
   * Creates a builder for {@link ScheduledEventCreateSpec ScheduledEventCreateSpec}.
   * <pre>
   * ScheduledEventCreateSpec.builder()
   *    .reason(String | null) // nullable {@link ScheduledEventCreateSpecGenerator#reason() reason}
   *    .channelId(discord4j.discordjson.possible.Possible&amp;lt;discord4j.common.util.Snowflake&amp;gt;) // {@link ScheduledEventCreateSpecGenerator#channelId() channelId}
   *    .entityMetadata(discord4j.discordjson.possible.Possible&amp;lt;ScheduledEventEntityMetadataSpec&amp;gt;) // {@link ScheduledEventCreateSpecGenerator#entityMetadata() entityMetadata}
   *    .name(String) // required {@link ScheduledEventCreateSpecGenerator#name() name}
   *    .privacyLevel(discord4j.core.object.entity.ScheduledEvent.PrivacyLevel) // required {@link ScheduledEventCreateSpecGenerator#privacyLevel() privacyLevel}
   *    .scheduledStartTime(java.time.Instant) // required {@link ScheduledEventCreateSpecGenerator#scheduledStartTime() scheduledStartTime}
   *    .scheduledEndTime(discord4j.discordjson.possible.Possible&amp;lt;java.time.Instant&amp;gt;) // {@link ScheduledEventCreateSpecGenerator#scheduledEndTime() scheduledEndTime}
   *    .description(discord4j.discordjson.possible.Possible&amp;lt;String&amp;gt;) // {@link ScheduledEventCreateSpecGenerator#description() description}
   *    .entityType(discord4j.core.object.entity.ScheduledEvent.EntityType) // required {@link ScheduledEventCreateSpecGenerator#entityType() entityType}
   *    .image(discord4j.discordjson.possible.Possible&amp;lt;discord4j.rest.util.Image&amp;gt;) // {@link ScheduledEventCreateSpecGenerator#image() image}
   *    .build();
   * </pre>
   * @return A new ScheduledEventCreateSpec builder
   */
  public static ScheduledEventCreateSpec.Builder builder() {
    return new ScheduledEventCreateSpec.Builder();
  }

  /**
   * Builds instances of type {@link ScheduledEventCreateSpec ScheduledEventCreateSpec}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "ScheduledEventCreateSpecGenerator", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_NAME = 0x1L;
    private static final long INIT_BIT_PRIVACY_LEVEL = 0x2L;
    private static final long INIT_BIT_SCHEDULED_START_TIME = 0x4L;
    private static final long INIT_BIT_ENTITY_TYPE = 0x8L;
    private long initBits = 0xfL;

    private Possible<Snowflake> channelId_possible = Possible.absent();
    private Possible<ScheduledEventEntityMetadataSpec> entityMetadata_possible = Possible.absent();
    private Possible<Instant> scheduledEndTime_possible = Possible.absent();
    private Possible<String> description_possible = Possible.absent();
    private Possible<Image> image_possible = Possible.absent();
    private String reason;
    private String name;
    private ScheduledEvent.PrivacyLevel privacyLevel;
    private Instant scheduledStartTime;
    private ScheduledEvent.EntityType entityType;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code ScheduledEventCreateSpecGenerator} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(ScheduledEventCreateSpecGenerator instance) {
      Objects.requireNonNull(instance, "instance");
      String reasonValue = instance.reason();
      if (reasonValue != null) {
        reason(reasonValue);
      }
      channelId(instance.channelId());
      entityMetadata(instance.entityMetadata());
      name(instance.name());
      privacyLevel(instance.privacyLevel());
      scheduledStartTime(instance.scheduledStartTime());
      scheduledEndTime(instance.scheduledEndTime());
      description(instance.description());
      entityType(instance.entityType());
      image(instance.image());
      return this;
    }

    /**
     * Initializes the value for the {@link ScheduledEventCreateSpecGenerator#reason() reason} attribute.
     * @param reason The value for reason (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder reason(@Nullable String reason) {
      this.reason = reason;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder channelId(Possible<Snowflake> value) {
      this.channelId_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder channelId(Snowflake value) {
      this.channelId_possible = Possible.of(value);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder entityMetadata(Possible<ScheduledEventEntityMetadataSpec> value) {
      this.entityMetadata_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder entityMetadata(ScheduledEventEntityMetadataSpec value) {
      this.entityMetadata_possible = Possible.of(value);
      return this;
    }

    /**
     * Initializes the value for the {@link ScheduledEventCreateSpecGenerator#name() name} attribute.
     * @param name The value for name 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder name(String name) {
      this.name = Objects.requireNonNull(name, "name");
      initBits &= ~INIT_BIT_NAME;
      return this;
    }

    /**
     * Initializes the value for the {@link ScheduledEventCreateSpecGenerator#privacyLevel() privacyLevel} attribute.
     * @param privacyLevel The value for privacyLevel 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder privacyLevel(ScheduledEvent.PrivacyLevel privacyLevel) {
      this.privacyLevel = Objects.requireNonNull(privacyLevel, "privacyLevel");
      initBits &= ~INIT_BIT_PRIVACY_LEVEL;
      return this;
    }

    /**
     * Initializes the value for the {@link ScheduledEventCreateSpecGenerator#scheduledStartTime() scheduledStartTime} attribute.
     * @param scheduledStartTime The value for scheduledStartTime 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder scheduledStartTime(Instant scheduledStartTime) {
      this.scheduledStartTime = Objects.requireNonNull(scheduledStartTime, "scheduledStartTime");
      initBits &= ~INIT_BIT_SCHEDULED_START_TIME;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder scheduledEndTime(Possible<Instant> value) {
      this.scheduledEndTime_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder scheduledEndTime(Instant value) {
      this.scheduledEndTime_possible = Possible.of(value);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder description(Possible<String> value) {
      this.description_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder description(String value) {
      this.description_possible = Possible.of(value);
      return this;
    }

    /**
     * Initializes the value for the {@link ScheduledEventCreateSpecGenerator#entityType() entityType} attribute.
     * @param entityType The value for entityType 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder entityType(ScheduledEvent.EntityType entityType) {
      this.entityType = Objects.requireNonNull(entityType, "entityType");
      initBits &= ~INIT_BIT_ENTITY_TYPE;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder image(Possible<Image> value) {
      this.image_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder image(Image value) {
      this.image_possible = Possible.of(value);
      return this;
    }

    /**
     * Builds a new {@link ScheduledEventCreateSpec ScheduledEventCreateSpec}.
     * @return An immutable instance of ScheduledEventCreateSpec
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ScheduledEventCreateSpec build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ScheduledEventCreateSpec(
          reason,
          channelId_build(),
          entityMetadata_build(),
          name,
          privacyLevel,
          scheduledStartTime,
          scheduledEndTime_build(),
          description_build(),
          entityType,
          image_build());
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_NAME) != 0) attributes.add("name");
      if ((initBits & INIT_BIT_PRIVACY_LEVEL) != 0) attributes.add("privacyLevel");
      if ((initBits & INIT_BIT_SCHEDULED_START_TIME) != 0) attributes.add("scheduledStartTime");
      if ((initBits & INIT_BIT_ENTITY_TYPE) != 0) attributes.add("entityType");
      return "Cannot build ScheduledEventCreateSpec, some of required attributes are not set " + attributes;
    }

    private Possible<Snowflake> channelId_build() {
      return this.channelId_possible;
    }

    private Possible<ScheduledEventEntityMetadataSpec> entityMetadata_build() {
      return this.entityMetadata_possible;
    }

    private Possible<Instant> scheduledEndTime_build() {
      return this.scheduledEndTime_possible;
    }

    private Possible<String> description_build() {
      return this.description_possible;
    }

    private Possible<Image> image_build() {
      return this.image_possible;
    }
  }
}
