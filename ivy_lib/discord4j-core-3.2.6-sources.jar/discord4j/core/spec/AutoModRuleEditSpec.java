package discord4j.core.spec;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import discord4j.common.util.Snowflake;
import discord4j.discordjson.json.AutoModActionData;
import discord4j.discordjson.json.AutoModActionMetaData;
import discord4j.discordjson.json.AutoModTriggerMetaData;
import discord4j.discordjson.json.ImmutableAutoModActionData;
import discord4j.discordjson.possible.Possible;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import org.immutables.value.Generated;
import reactor.util.annotation.Nullable;

/**
 * Immutable implementation of {@link AutoModRuleEditSpecGenerator}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code AutoModRuleEditSpec.builder()}.
 * Use the static factory method to create immutable instances:
 * {@code AutoModRuleEditSpec.of()}.
 */
@Generated(from = "AutoModRuleEditSpecGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class AutoModRuleEditSpec implements AutoModRuleEditSpecGenerator {
  private final @Nullable String reason;
  private final String name;
  private final int eventType;
  private final AutoModTriggerMetaData triggerMetaData_value;
  private final boolean triggerMetaData_absent;
  private final List<AutoModActionData> actions;
  private final boolean enabled;
  private final List<Snowflake> exemptRoles;
  private final List<Snowflake> exemptChannels;

  private AutoModRuleEditSpec(String name, int eventType, boolean enabled) {
    this.name = Objects.requireNonNull(name, "name");
    this.eventType = eventType;
    this.enabled = enabled;
    this.reason = null;
    Possible<AutoModTriggerMetaData> triggerMetaData$impl = Possible.absent();
    this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null);
    this.triggerMetaData_absent = triggerMetaData$impl.isAbsent();
    this.actions = initShim.actions();
    this.exemptRoles = initShim.exemptRoles();
    this.exemptChannels = initShim.exemptChannels();
    this.initShim = null;
  }

  private AutoModRuleEditSpec(AutoModRuleEditSpec.Builder builder) {
    this.reason = builder.reason;
    this.name = builder.name;
    this.eventType = builder.eventType;
    Possible<AutoModTriggerMetaData> triggerMetaData$impl = builder.triggerMetaData_build();
    this.enabled = builder.enabled;
    if (builder.actionsIsSet()) {
      initShim.actions(createUnmodifiableList(true, builder.actions));
    }
    if (builder.exemptRolesIsSet()) {
      initShim.exemptRoles(createUnmodifiableList(true, builder.exemptRoles));
    }
    if (builder.exemptChannelsIsSet()) {
      initShim.exemptChannels(createUnmodifiableList(true, builder.exemptChannels));
    }
    this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null);
    this.triggerMetaData_absent = triggerMetaData$impl.isAbsent();
    this.actions = initShim.actions();
    this.exemptRoles = initShim.exemptRoles();
    this.exemptChannels = initShim.exemptChannels();
    this.initShim = null;
  }

  private AutoModRuleEditSpec(
      @Nullable String reason,
      String name,
      int eventType,
      Possible<AutoModTriggerMetaData> triggerMetaData,
      List<AutoModActionData> actions,
      boolean enabled,
      List<Snowflake> exemptRoles,
      List<Snowflake> exemptChannels) {
    this.reason = reason;
    this.name = name;
    this.eventType = eventType;
    Possible<AutoModTriggerMetaData> triggerMetaData$impl = triggerMetaData;
    initShim.actions(actions);
    this.enabled = enabled;
    initShim.exemptRoles(exemptRoles);
    initShim.exemptChannels(exemptChannels);
    this.triggerMetaData_value = triggerMetaData$impl.toOptional().orElse(null);
    this.triggerMetaData_absent = triggerMetaData$impl.isAbsent();
    this.actions = initShim.actions();
    this.exemptRoles = initShim.exemptRoles();
    this.exemptChannels = initShim.exemptChannels();
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "AutoModRuleEditSpecGenerator", generator = "Immutables")
  private final class InitShim {
    private byte actionsBuildStage = STAGE_UNINITIALIZED;
    private List<AutoModActionData> actions;

    List<AutoModActionData> actions() {
      if (actionsBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (actionsBuildStage == STAGE_UNINITIALIZED) {
        actionsBuildStage = STAGE_INITIALIZING;
        this.actions = createUnmodifiableList(false, createSafeList(actionsInitialize(), true, false));
        actionsBuildStage = STAGE_INITIALIZED;
      }
      return this.actions;
    }

    void actions(List<AutoModActionData> actions) {
      this.actions = actions;
      actionsBuildStage = STAGE_INITIALIZED;
    }

    private byte exemptRolesBuildStage = STAGE_UNINITIALIZED;
    private List<Snowflake> exemptRoles;

    List<Snowflake> exemptRoles() {
      if (exemptRolesBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (exemptRolesBuildStage == STAGE_UNINITIALIZED) {
        exemptRolesBuildStage = STAGE_INITIALIZING;
        this.exemptRoles = createUnmodifiableList(false, createSafeList(exemptRolesInitialize(), true, false));
        exemptRolesBuildStage = STAGE_INITIALIZED;
      }
      return this.exemptRoles;
    }

    void exemptRoles(List<Snowflake> exemptRoles) {
      this.exemptRoles = exemptRoles;
      exemptRolesBuildStage = STAGE_INITIALIZED;
    }

    private byte exemptChannelsBuildStage = STAGE_UNINITIALIZED;
    private List<Snowflake> exemptChannels;

    List<Snowflake> exemptChannels() {
      if (exemptChannelsBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (exemptChannelsBuildStage == STAGE_UNINITIALIZED) {
        exemptChannelsBuildStage = STAGE_INITIALIZING;
        this.exemptChannels = createUnmodifiableList(false, createSafeList(exemptChannelsInitialize(), true, false));
        exemptChannelsBuildStage = STAGE_INITIALIZED;
      }
      return this.exemptChannels;
    }

    void exemptChannels(List<Snowflake> exemptChannels) {
      this.exemptChannels = exemptChannels;
      exemptChannelsBuildStage = STAGE_INITIALIZED;
    }

    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      if (actionsBuildStage == STAGE_INITIALIZING) attributes.add("actions");
      if (exemptRolesBuildStage == STAGE_INITIALIZING) attributes.add("exemptRoles");
      if (exemptChannelsBuildStage == STAGE_INITIALIZING) attributes.add("exemptChannels");
      return "Cannot build AutoModRuleEditSpec, attribute initializers form cycle " + attributes;
    }
  }

  private List<AutoModActionData> actionsInitialize() {
    return AutoModRuleEditSpecGenerator.super.actions();
  }

  private List<Snowflake> exemptRolesInitialize() {
    return AutoModRuleEditSpecGenerator.super.exemptRoles();
  }

  private List<Snowflake> exemptChannelsInitialize() {
    return AutoModRuleEditSpecGenerator.super.exemptChannels();
  }

  /**
   * Returns the current audit log reason set on the spec.
   * @return The current audit log reason.
   */
  @Override
  public @Nullable String reason() {
    return reason;
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public String name() {
    return name;
  }

  /**
   * @return The value of the {@code eventType} attribute
   */
  @Override
  public int eventType() {
    return eventType;
  }

  /**
   * @return The value of the {@code triggerMetaData} attribute
   */
  @Override
  public Possible<AutoModTriggerMetaData> triggerMetaData() {
    return triggerMetaData_absent ? Possible.absent() : Possible.of(triggerMetaData_value);
  }

  /**
   * @return The value of the {@code actions} attribute
   */
  @Override
  public List<AutoModActionData> actions() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.actions()
        : this.actions;
  }

  /**
   * @return The value of the {@code enabled} attribute
   */
  @Override
  public boolean enabled() {
    return enabled;
  }

  /**
   * @return The value of the {@code exemptRoles} attribute
   */
  @Override
  public List<Snowflake> exemptRoles() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.exemptRoles()
        : this.exemptRoles;
  }

  /**
   * @return The value of the {@code exemptChannels} attribute
   */
  @Override
  public List<Snowflake> exemptChannels() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.exemptChannels()
        : this.exemptChannels;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleEditSpecGenerator#reason() reason} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for reason (can be {@code null})
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleEditSpec withReason(@Nullable String value) {
    if (Objects.equals(this.reason, value)) return this;
    return new AutoModRuleEditSpec(
        value,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleEditSpecGenerator#name() name} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for name
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleEditSpec withName(String value) {
    String newValue = Objects.requireNonNull(value, "name");
    if (this.name.equals(newValue)) return this;
    return new AutoModRuleEditSpec(
        this.reason,
        newValue,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleEditSpecGenerator#eventType() eventType} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for eventType
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleEditSpec withEventType(int value) {
    if (this.eventType == value) return this;
    return new AutoModRuleEditSpec(
        this.reason,
        this.name,
        value,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels);
  }

  public AutoModRuleEditSpec withTriggerMetaData(Possible<AutoModTriggerMetaData> value) {
    Possible<AutoModTriggerMetaData> newValue = Objects.requireNonNull(value);
    return new AutoModRuleEditSpec(
        this.reason,
        this.name,
        this.eventType,
        newValue,
        this.actions,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels);
  }

  public AutoModRuleEditSpec withTriggerMetaData(AutoModTriggerMetaData value) {
    Possible<AutoModTriggerMetaData> newValue = Possible.of(value);
    return new AutoModRuleEditSpec(
        this.reason,
        this.name,
        this.eventType,
        newValue,
        this.actions,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleEditSpecGenerator#actions() actions}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleEditSpec withActions(AutoModActionData... elements) {
    List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
    return new AutoModRuleEditSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        newValue,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleEditSpecGenerator#actions() actions}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of actions elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleEditSpec withActions(Iterable<? extends AutoModActionData> elements) {
    if (this.actions == elements) return this;
    List<AutoModActionData> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new AutoModRuleEditSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        newValue,
        this.enabled,
        this.exemptRoles,
        this.exemptChannels);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link AutoModRuleEditSpecGenerator#enabled() enabled} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for enabled
   * @return A modified copy of the {@code this} object
   */
  public final AutoModRuleEditSpec withEnabled(boolean value) {
    if (this.enabled == value) return this;
    return new AutoModRuleEditSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        value,
        this.exemptRoles,
        this.exemptChannels);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleEditSpecGenerator#exemptRoles() exemptRoles}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleEditSpec withExemptRoles(Snowflake... elements) {
    List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
    return new AutoModRuleEditSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        newValue,
        this.exemptChannels);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleEditSpecGenerator#exemptRoles() exemptRoles}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of exemptRoles elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleEditSpec withExemptRoles(Iterable<? extends Snowflake> elements) {
    if (this.exemptRoles == elements) return this;
    List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new AutoModRuleEditSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        newValue,
        this.exemptChannels);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleEditSpecGenerator#exemptChannels() exemptChannels}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleEditSpec withExemptChannels(Snowflake... elements) {
    List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
    return new AutoModRuleEditSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        this.exemptRoles,
        newValue);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link AutoModRuleEditSpecGenerator#exemptChannels() exemptChannels}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of exemptChannels elements to set
   * @return A modified copy of {@code this} object
   */
  public final AutoModRuleEditSpec withExemptChannels(Iterable<? extends Snowflake> elements) {
    if (this.exemptChannels == elements) return this;
    List<Snowflake> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new AutoModRuleEditSpec(
        this.reason,
        this.name,
        this.eventType,
        this.triggerMetaData(),
        this.actions,
        this.enabled,
        this.exemptRoles,
        newValue);
  }

  /**
   * This instance is equal to all instances of {@code AutoModRuleEditSpec} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof AutoModRuleEditSpec
        && equalTo(0, (AutoModRuleEditSpec) another);
  }

  private boolean equalTo(int synthetic, AutoModRuleEditSpec another) {
    return Objects.equals(reason, another.reason)
        && name.equals(another.name)
        && eventType == another.eventType
        && this.triggerMetaData().equals(another.triggerMetaData())
        && actions.equals(another.actions)
        && enabled == another.enabled
        && exemptRoles.equals(another.exemptRoles)
        && exemptChannels.equals(another.exemptChannels);
  }

  /**
   * Computes a hash code from attributes: {@code reason}, {@code name}, {@code eventType}, {@code triggerMetaData}, {@code actions}, {@code enabled}, {@code exemptRoles}, {@code exemptChannels}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(reason);
    h += (h << 5) + name.hashCode();
    h += (h << 5) + eventType;
    h += (h << 5) + (triggerMetaData().hashCode());
    h += (h << 5) + actions.hashCode();
    h += (h << 5) + Boolean.hashCode(enabled);
    h += (h << 5) + exemptRoles.hashCode();
    h += (h << 5) + exemptChannels.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code AutoModRuleEditSpec} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "AutoModRuleEditSpec{"
        + "reason=" + reason
        + ", name=" + name
        + ", eventType=" + eventType
        + ", triggerMetaData=" + (triggerMetaData().toString())
        + ", actions=" + actions
        + ", enabled=" + enabled
        + ", exemptRoles=" + exemptRoles
        + ", exemptChannels=" + exemptChannels
        + "}";
  }

  /**
   * Construct a new immutable {@code AutoModRuleEditSpec} instance.
   * @param name The value for the {@code name} attribute
   * @param eventType The value for the {@code eventType} attribute
   * @param enabled The value for the {@code enabled} attribute
   * @return An immutable AutoModRuleEditSpec instance
   */
  public static AutoModRuleEditSpec of(String name, int eventType, boolean enabled) {
    return new AutoModRuleEditSpec(name, eventType, enabled);
  }

  /**
   * Creates an immutable copy of a {@link AutoModRuleEditSpecGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable AutoModRuleEditSpec instance
   */
  public static AutoModRuleEditSpec copyOf(AutoModRuleEditSpecGenerator instance) {
    if (instance instanceof AutoModRuleEditSpec) {
      return (AutoModRuleEditSpec) instance;
    }
    return AutoModRuleEditSpec.builder()
        .from(instance)
        .build();
  }

  public boolean isTriggerMetaDataPresent() {
    return !triggerMetaData_absent;
  }

  public AutoModTriggerMetaData triggerMetaDataOrElse(AutoModTriggerMetaData defaultValue) {
    return !triggerMetaData_absent ? triggerMetaData_value : defaultValue;
  }

  /**
   * Creates a builder for {@link AutoModRuleEditSpec AutoModRuleEditSpec}.
   * <pre>
   * AutoModRuleEditSpec.builder()
   *    .reason(String | null) // nullable {@link AutoModRuleEditSpecGenerator#reason() reason}
   *    .name(String) // required {@link AutoModRuleEditSpecGenerator#name() name}
   *    .eventType(int) // required {@link AutoModRuleEditSpecGenerator#eventType() eventType}
   *    .triggerMetaData(discord4j.discordjson.possible.Possible&amp;lt;discord4j.discordjson.json.AutoModTriggerMetaData&amp;gt;) // {@link AutoModRuleEditSpecGenerator#triggerMetaData() triggerMetaData}
   *    .addAction|addAllActions(discord4j.discordjson.json.AutoModActionData) // {@link AutoModRuleEditSpecGenerator#actions() actions} elements
   *    .enabled(boolean) // required {@link AutoModRuleEditSpecGenerator#enabled() enabled}
   *    .addExemptRole|addAllExemptRoles(discord4j.common.util.Snowflake) // {@link AutoModRuleEditSpecGenerator#exemptRoles() exemptRoles} elements
   *    .addExemptChannel|addAllExemptChannels(discord4j.common.util.Snowflake) // {@link AutoModRuleEditSpecGenerator#exemptChannels() exemptChannels} elements
   *    .build();
   * </pre>
   * @return A new AutoModRuleEditSpec builder
   */
  public static AutoModRuleEditSpec.Builder builder() {
    return new AutoModRuleEditSpec.Builder();
  }

  /**
   * Builds instances of type {@link AutoModRuleEditSpec AutoModRuleEditSpec}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "AutoModRuleEditSpecGenerator", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_NAME = 0x1L;
    private static final long INIT_BIT_EVENT_TYPE = 0x2L;
    private static final long INIT_BIT_ENABLED = 0x4L;
    private static final long OPT_BIT_ACTIONS = 0x1L;
    private static final long OPT_BIT_EXEMPT_ROLES = 0x2L;
    private static final long OPT_BIT_EXEMPT_CHANNELS = 0x4L;
    private long initBits = 0x7L;
    private long optBits;

    private Possible<AutoModTriggerMetaData> triggerMetaData_possible = Possible.absent();
    private String reason;
    private String name;
    private int eventType;
    private List<AutoModActionData> actions = new ArrayList<AutoModActionData>();
    private boolean enabled;
    private List<Snowflake> exemptRoles = new ArrayList<Snowflake>();
    private List<Snowflake> exemptChannels = new ArrayList<Snowflake>();

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code AutoModRuleEditSpecGenerator} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * Collection elements and entries will be added, not replaced.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(AutoModRuleEditSpecGenerator instance) {
      Objects.requireNonNull(instance, "instance");
      String reasonValue = instance.reason();
      if (reasonValue != null) {
        reason(reasonValue);
      }
      name(instance.name());
      eventType(instance.eventType());
      triggerMetaData(instance.triggerMetaData());
      addAllActions(instance.actions());
      enabled(instance.enabled());
      addAllExemptRoles(instance.exemptRoles());
      addAllExemptChannels(instance.exemptChannels());
      return this;
    }

    /**
     * Initializes the value for the {@link AutoModRuleEditSpecGenerator#reason() reason} attribute.
     * @param reason The value for reason (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder reason(@Nullable String reason) {
      this.reason = reason;
      return this;
    }

    /**
     * Initializes the value for the {@link AutoModRuleEditSpecGenerator#name() name} attribute.
     * @param name The value for name 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder name(String name) {
      this.name = Objects.requireNonNull(name, "name");
      initBits &= ~INIT_BIT_NAME;
      return this;
    }

    /**
     * Initializes the value for the {@link AutoModRuleEditSpecGenerator#eventType() eventType} attribute.
     * @param eventType The value for eventType 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder eventType(int eventType) {
      this.eventType = eventType;
      initBits &= ~INIT_BIT_EVENT_TYPE;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder triggerMetaData(Possible<AutoModTriggerMetaData> value) {
      this.triggerMetaData_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder triggerMetaData(AutoModTriggerMetaData value) {
      this.triggerMetaData_possible = Possible.of(value);
      return this;
    }

    /**
     * Adds one element to {@link AutoModRuleEditSpecGenerator#actions() actions} list.
     * @param element A actions element
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addAction(AutoModActionData element) {
      element = ImmutableAutoModActionData.copyOf(element);
      this.actions.add(Objects.requireNonNull(element, "actions element"));
      optBits |= OPT_BIT_ACTIONS;
      return this;
    }

    /**
     * Constructs and adds an element for the {@link AutoModRuleEditSpecGenerator#actions() actions} list.
     * @param type The value for {@code actions.type} 
     * @param metadata The value for {@code actions.metadata} 
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder addAction(int type, Possible<AutoModActionMetaData> metadata) {
      return addAction(ImmutableAutoModActionData.of(type, metadata));
    }

    /**
     * Adds elements to {@link AutoModRuleEditSpecGenerator#actions() actions} list.
     * @param elements An array of actions elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addActions(AutoModActionData... elements) {
      for (AutoModActionData element : elements) {
        element = ImmutableAutoModActionData.copyOf(element);
        this.actions.add(Objects.requireNonNull(element, "actions element"));
      }
      optBits |= OPT_BIT_ACTIONS;
      return this;
    }


    /**
     * Sets or replaces all elements for {@link AutoModRuleEditSpecGenerator#actions() actions} list.
     * @param elements An iterable of actions elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder actions(Iterable<? extends AutoModActionData> elements) {
      this.actions.clear();
      return addAllActions(elements);
    }

    /**
     * Adds elements to {@link AutoModRuleEditSpecGenerator#actions() actions} list.
     * @param elements An iterable of actions elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addAllActions(Iterable<? extends AutoModActionData> elements) {
      for (AutoModActionData element : elements) {
        element = ImmutableAutoModActionData.copyOf(element);
        this.actions.add(Objects.requireNonNull(element, "actions element"));
      }
      optBits |= OPT_BIT_ACTIONS;
      return this;
    }

    /**
     * Initializes the value for the {@link AutoModRuleEditSpecGenerator#enabled() enabled} attribute.
     * @param enabled The value for enabled 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder enabled(boolean enabled) {
      this.enabled = enabled;
      initBits &= ~INIT_BIT_ENABLED;
      return this;
    }

    /**
     * Adds one element to {@link AutoModRuleEditSpecGenerator#exemptRoles() exemptRoles} list.
     * @param element A exemptRoles element
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addExemptRole(Snowflake element) {
      this.exemptRoles.add(Objects.requireNonNull(element, "exemptRoles element"));
      optBits |= OPT_BIT_EXEMPT_ROLES;
      return this;
    }

    /**
     * Adds elements to {@link AutoModRuleEditSpecGenerator#exemptRoles() exemptRoles} list.
     * @param elements An array of exemptRoles elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addExemptRoles(Snowflake... elements) {
      for (Snowflake element : elements) {
        this.exemptRoles.add(Objects.requireNonNull(element, "exemptRoles element"));
      }
      optBits |= OPT_BIT_EXEMPT_ROLES;
      return this;
    }


    /**
     * Sets or replaces all elements for {@link AutoModRuleEditSpecGenerator#exemptRoles() exemptRoles} list.
     * @param elements An iterable of exemptRoles elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder exemptRoles(Iterable<? extends Snowflake> elements) {
      this.exemptRoles.clear();
      return addAllExemptRoles(elements);
    }

    /**
     * Adds elements to {@link AutoModRuleEditSpecGenerator#exemptRoles() exemptRoles} list.
     * @param elements An iterable of exemptRoles elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addAllExemptRoles(Iterable<? extends Snowflake> elements) {
      for (Snowflake element : elements) {
        this.exemptRoles.add(Objects.requireNonNull(element, "exemptRoles element"));
      }
      optBits |= OPT_BIT_EXEMPT_ROLES;
      return this;
    }

    /**
     * Adds one element to {@link AutoModRuleEditSpecGenerator#exemptChannels() exemptChannels} list.
     * @param element A exemptChannels element
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addExemptChannel(Snowflake element) {
      this.exemptChannels.add(Objects.requireNonNull(element, "exemptChannels element"));
      optBits |= OPT_BIT_EXEMPT_CHANNELS;
      return this;
    }

    /**
     * Adds elements to {@link AutoModRuleEditSpecGenerator#exemptChannels() exemptChannels} list.
     * @param elements An array of exemptChannels elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addExemptChannels(Snowflake... elements) {
      for (Snowflake element : elements) {
        this.exemptChannels.add(Objects.requireNonNull(element, "exemptChannels element"));
      }
      optBits |= OPT_BIT_EXEMPT_CHANNELS;
      return this;
    }


    /**
     * Sets or replaces all elements for {@link AutoModRuleEditSpecGenerator#exemptChannels() exemptChannels} list.
     * @param elements An iterable of exemptChannels elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder exemptChannels(Iterable<? extends Snowflake> elements) {
      this.exemptChannels.clear();
      return addAllExemptChannels(elements);
    }

    /**
     * Adds elements to {@link AutoModRuleEditSpecGenerator#exemptChannels() exemptChannels} list.
     * @param elements An iterable of exemptChannels elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addAllExemptChannels(Iterable<? extends Snowflake> elements) {
      for (Snowflake element : elements) {
        this.exemptChannels.add(Objects.requireNonNull(element, "exemptChannels element"));
      }
      optBits |= OPT_BIT_EXEMPT_CHANNELS;
      return this;
    }

    /**
     * Builds a new {@link AutoModRuleEditSpec AutoModRuleEditSpec}.
     * @return An immutable instance of AutoModRuleEditSpec
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public AutoModRuleEditSpec build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new AutoModRuleEditSpec(this);
    }

    private boolean actionsIsSet() {
      return (optBits & OPT_BIT_ACTIONS) != 0;
    }

    private boolean exemptRolesIsSet() {
      return (optBits & OPT_BIT_EXEMPT_ROLES) != 0;
    }

    private boolean exemptChannelsIsSet() {
      return (optBits & OPT_BIT_EXEMPT_CHANNELS) != 0;
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_NAME) != 0) attributes.add("name");
      if ((initBits & INIT_BIT_EVENT_TYPE) != 0) attributes.add("eventType");
      if ((initBits & INIT_BIT_ENABLED) != 0) attributes.add("enabled");
      return "Cannot build AutoModRuleEditSpec, some of required attributes are not set " + attributes;
    }

    private Possible<AutoModTriggerMetaData> triggerMetaData_build() {
      return this.triggerMetaData_possible;
    }
  }

  private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
    ArrayList<T> list;
    if (iterable instanceof Collection<?>) {
      int size = ((Collection<?>) iterable).size();
      if (size == 0) return Collections.emptyList();
      list = new ArrayList<>();
    } else {
      list = new ArrayList<>();
    }
    for (T element : iterable) {
      if (skipNulls && element == null) continue;
      if (checkNulls) Objects.requireNonNull(element, "element");
      list.add(element);
    }
    return list;
  }

  private static <T> List<T> createUnmodifiableList(boolean clone, List<T> list) {
    switch(list.size()) {
    case 0: return Collections.emptyList();
    case 1: return Collections.singletonList(list.get(0));
    default:
      if (clone) {
        return Collections.unmodifiableList(new ArrayList<>(list));
      } else {
        if (list instanceof ArrayList<?>) {
          ((ArrayList<?>) list).trimToSize();
        }
        return Collections.unmodifiableList(list);
      }
    }
  }
}
