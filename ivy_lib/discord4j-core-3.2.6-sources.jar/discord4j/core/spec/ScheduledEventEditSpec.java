package discord4j.core.spec;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import discord4j.common.util.Snowflake;
import discord4j.core.object.entity.ScheduledEvent;
import discord4j.discordjson.possible.Possible;
import discord4j.rest.util.Image;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.immutables.value.Generated;
import reactor.util.annotation.Nullable;

/**
 * Immutable implementation of {@link ScheduledEventEditSpecGenerator}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ScheduledEventEditSpec.builder()}.
 */
@Generated(from = "ScheduledEventEditSpecGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class ScheduledEventEditSpec implements ScheduledEventEditSpecGenerator {
  private final @Nullable String reason;
  private final Snowflake channelId_value;
  private final boolean channelId_absent;
  private final ScheduledEventEntityMetadataSpec entityMetadata_value;
  private final boolean entityMetadata_absent;
  private final String name_value;
  private final boolean name_absent;
  private final ScheduledEvent.PrivacyLevel privacyLevel_value;
  private final boolean privacyLevel_absent;
  private final Instant scheduledStartTime_value;
  private final boolean scheduledStartTime_absent;
  private final Instant scheduledEndTime_value;
  private final boolean scheduledEndTime_absent;
  private final String description_value;
  private final boolean description_absent;
  private final ScheduledEvent.EntityType entityType_value;
  private final boolean entityType_absent;
  private final ScheduledEvent.Status status_value;
  private final boolean status_absent;
  private final Image image_value;
  private final boolean image_absent;

  private ScheduledEventEditSpec(
      @Nullable String reason,
      Possible<Optional<Snowflake>> channelId,
      Possible<ScheduledEventEntityMetadataSpec> entityMetadata,
      Possible<String> name,
      Possible<ScheduledEvent.PrivacyLevel> privacyLevel,
      Possible<Instant> scheduledStartTime,
      Possible<Instant> scheduledEndTime,
      Possible<String> description,
      Possible<ScheduledEvent.EntityType> entityType,
      Possible<ScheduledEvent.Status> status,
      Possible<Image> image) {
    this.reason = reason;
    Possible<Optional<Snowflake>> channelId$impl = channelId;
    Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = entityMetadata;
    Possible<String> name$impl = name;
    Possible<ScheduledEvent.PrivacyLevel> privacyLevel$impl = privacyLevel;
    Possible<Instant> scheduledStartTime$impl = scheduledStartTime;
    Possible<Instant> scheduledEndTime$impl = scheduledEndTime;
    Possible<String> description$impl = description;
    Possible<ScheduledEvent.EntityType> entityType$impl = entityType;
    Possible<ScheduledEvent.Status> status$impl = status;
    Possible<Image> image$impl = image;
    this.channelId_value = Possible.flatOpt(channelId$impl).orElse(null);
    this.channelId_absent = channelId$impl.isAbsent();
    this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null);
    this.entityMetadata_absent = entityMetadata$impl.isAbsent();
    this.name_value = name$impl.toOptional().orElse(null);
    this.name_absent = name$impl.isAbsent();
    this.privacyLevel_value = privacyLevel$impl.toOptional().orElse(null);
    this.privacyLevel_absent = privacyLevel$impl.isAbsent();
    this.scheduledStartTime_value = scheduledStartTime$impl.toOptional().orElse(null);
    this.scheduledStartTime_absent = scheduledStartTime$impl.isAbsent();
    this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
    this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
    this.description_value = description$impl.toOptional().orElse(null);
    this.description_absent = description$impl.isAbsent();
    this.entityType_value = entityType$impl.toOptional().orElse(null);
    this.entityType_absent = entityType$impl.isAbsent();
    this.status_value = status$impl.toOptional().orElse(null);
    this.status_absent = status$impl.isAbsent();
    this.image_value = image$impl.toOptional().orElse(null);
    this.image_absent = image$impl.isAbsent();
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "ScheduledEventEditSpecGenerator", generator = "Immutables")
  private final class InitShim {
    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      return "Cannot build ScheduledEventEditSpec, attribute initializers form cycle " + attributes;
    }
  }

  /**
   * Returns the current audit log reason set on the spec.
   * @return The current audit log reason.
   */
  @Override
  public @Nullable String reason() {
    return reason;
  }

  /**
   * @return The value of the {@code channelId} attribute
   */
  @Override
  public Possible<Optional<Snowflake>> channelId() {
    return channelId_absent ? Possible.absent() :
        Possible.of(Optional.ofNullable(channelId_value));
  }

  /**
   * @return The value of the {@code entityMetadata} attribute
   */
  @Override
  public Possible<ScheduledEventEntityMetadataSpec> entityMetadata() {
    return entityMetadata_absent ? Possible.absent() : Possible.of(entityMetadata_value);
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public Possible<String> name() {
    return name_absent ? Possible.absent() : Possible.of(name_value);
  }

  /**
   * @return The value of the {@code privacyLevel} attribute
   */
  @Override
  public Possible<ScheduledEvent.PrivacyLevel> privacyLevel() {
    return privacyLevel_absent ? Possible.absent() : Possible.of(privacyLevel_value);
  }

  /**
   * @return The value of the {@code scheduledStartTime} attribute
   */
  @Override
  public Possible<Instant> scheduledStartTime() {
    return scheduledStartTime_absent ? Possible.absent() : Possible.of(scheduledStartTime_value);
  }

  /**
   * @return The value of the {@code scheduledEndTime} attribute
   */
  @Override
  public Possible<Instant> scheduledEndTime() {
    return scheduledEndTime_absent ? Possible.absent() : Possible.of(scheduledEndTime_value);
  }

  /**
   * @return The value of the {@code description} attribute
   */
  @Override
  public Possible<String> description() {
    return description_absent ? Possible.absent() : Possible.of(description_value);
  }

  /**
   * @return The value of the {@code entityType} attribute
   */
  @Override
  public Possible<ScheduledEvent.EntityType> entityType() {
    return entityType_absent ? Possible.absent() : Possible.of(entityType_value);
  }

  /**
   * @return The value of the {@code status} attribute
   */
  @Override
  public Possible<ScheduledEvent.Status> status() {
    return status_absent ? Possible.absent() : Possible.of(status_value);
  }

  /**
   * @return The value of the {@code image} attribute
   */
  @Override
  public Possible<Image> image() {
    return image_absent ? Possible.absent() : Possible.of(image_value);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventEditSpecGenerator#reason() reason} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for reason (can be {@code null})
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventEditSpec withReason(@Nullable String value) {
    if (Objects.equals(this.reason, value)) return this;
    return new ScheduledEventEditSpec(
        value,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withChannelId(Possible<Optional<Snowflake>> value) {
    Possible<Optional<Snowflake>> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditSpec(
        this.reason,
        newValue,
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  @Deprecated
  public ScheduledEventEditSpec withChannelId(@Nullable Snowflake value) {
    Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
    return new ScheduledEventEditSpec(
        this.reason,
        newValue,
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withChannelIdOrNull(@Nullable Snowflake value) {
    Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
    return new ScheduledEventEditSpec(
        this.reason,
        newValue,
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withEntityMetadata(Possible<ScheduledEventEntityMetadataSpec> value) {
    Possible<ScheduledEventEntityMetadataSpec> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        newValue,
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withEntityMetadata(ScheduledEventEntityMetadataSpec value) {
    Possible<ScheduledEventEntityMetadataSpec> newValue = Possible.of(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        newValue,
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withName(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        newValue,
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withName(String value) {
    Possible<String> newValue = Possible.of(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        newValue,
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withPrivacyLevel(Possible<ScheduledEvent.PrivacyLevel> value) {
    Possible<ScheduledEvent.PrivacyLevel> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        newValue,
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withPrivacyLevel(ScheduledEvent.PrivacyLevel value) {
    Possible<ScheduledEvent.PrivacyLevel> newValue = Possible.of(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        newValue,
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withScheduledStartTime(Possible<Instant> value) {
    Possible<Instant> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        newValue,
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withScheduledStartTime(Instant value) {
    Possible<Instant> newValue = Possible.of(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        newValue,
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withScheduledEndTime(Possible<Instant> value) {
    Possible<Instant> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        newValue,
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withScheduledEndTime(Instant value) {
    Possible<Instant> newValue = Possible.of(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        newValue,
        this.description(),
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withDescription(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        newValue,
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withDescription(String value) {
    Possible<String> newValue = Possible.of(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        newValue,
        this.entityType(),
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withEntityType(Possible<ScheduledEvent.EntityType> value) {
    Possible<ScheduledEvent.EntityType> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        newValue,
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withEntityType(ScheduledEvent.EntityType value) {
    Possible<ScheduledEvent.EntityType> newValue = Possible.of(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        newValue,
        this.status(),
        this.image());
  }

  public ScheduledEventEditSpec withStatus(Possible<ScheduledEvent.Status> value) {
    Possible<ScheduledEvent.Status> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        newValue,
        this.image());
  }

  public ScheduledEventEditSpec withStatus(ScheduledEvent.Status value) {
    Possible<ScheduledEvent.Status> newValue = Possible.of(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        newValue,
        this.image());
  }

  public ScheduledEventEditSpec withImage(Possible<Image> value) {
    Possible<Image> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        newValue);
  }

  public ScheduledEventEditSpec withImage(Image value) {
    Possible<Image> newValue = Possible.of(value);
    return new ScheduledEventEditSpec(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        newValue);
  }

  /**
   * This instance is equal to all instances of {@code ScheduledEventEditSpec} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof ScheduledEventEditSpec
        && equalTo(0, (ScheduledEventEditSpec) another);
  }

  private boolean equalTo(int synthetic, ScheduledEventEditSpec another) {
    return Objects.equals(reason, another.reason)
        && this.channelId().equals(another.channelId())
        && this.entityMetadata().equals(another.entityMetadata())
        && this.name().equals(another.name())
        && this.privacyLevel().equals(another.privacyLevel())
        && this.scheduledStartTime().equals(another.scheduledStartTime())
        && this.scheduledEndTime().equals(another.scheduledEndTime())
        && this.description().equals(another.description())
        && this.entityType().equals(another.entityType())
        && this.status().equals(another.status())
        && this.image().equals(another.image());
  }

  /**
   * Computes a hash code from attributes: {@code reason}, {@code channelId}, {@code entityMetadata}, {@code name}, {@code privacyLevel}, {@code scheduledStartTime}, {@code scheduledEndTime}, {@code description}, {@code entityType}, {@code status}, {@code image}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(reason);
    h += (h << 5) + (channelId().hashCode());
    h += (h << 5) + (entityMetadata().hashCode());
    h += (h << 5) + (name().hashCode());
    h += (h << 5) + (privacyLevel().hashCode());
    h += (h << 5) + (scheduledStartTime().hashCode());
    h += (h << 5) + (scheduledEndTime().hashCode());
    h += (h << 5) + (description().hashCode());
    h += (h << 5) + (entityType().hashCode());
    h += (h << 5) + (status().hashCode());
    h += (h << 5) + (image().hashCode());
    return h;
  }

  /**
   * Prints the immutable value {@code ScheduledEventEditSpec} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "ScheduledEventEditSpec{"
        + "reason=" + reason
        + ", channelId=" + (channelId().toString())
        + ", entityMetadata=" + (entityMetadata().toString())
        + ", name=" + (name().toString())
        + ", privacyLevel=" + (privacyLevel().toString())
        + ", scheduledStartTime=" + (scheduledStartTime().toString())
        + ", scheduledEndTime=" + (scheduledEndTime().toString())
        + ", description=" + (description().toString())
        + ", entityType=" + (entityType().toString())
        + ", status=" + (status().toString())
        + ", image=" + (image().toString())
        + "}";
  }

  /**
   * Creates an immutable copy of a {@link ScheduledEventEditSpecGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable ScheduledEventEditSpec instance
   */
  public static ScheduledEventEditSpec copyOf(ScheduledEventEditSpecGenerator instance) {
    if (instance instanceof ScheduledEventEditSpec) {
      return (ScheduledEventEditSpec) instance;
    }
    return ScheduledEventEditSpec.builder()
        .from(instance)
        .build();
  }

  public boolean isChannelIdPresent() {
    return !channelId_absent;
  }

  public Snowflake channelIdOrElse(Snowflake defaultValue) {
    return !channelId_absent ? channelId_value : defaultValue;
  }

  public boolean isEntityMetadataPresent() {
    return !entityMetadata_absent;
  }

  public ScheduledEventEntityMetadataSpec entityMetadataOrElse(ScheduledEventEntityMetadataSpec defaultValue) {
    return !entityMetadata_absent ? entityMetadata_value : defaultValue;
  }

  public boolean isNamePresent() {
    return !name_absent;
  }

  public String nameOrElse(String defaultValue) {
    return !name_absent ? name_value : defaultValue;
  }

  public boolean isPrivacyLevelPresent() {
    return !privacyLevel_absent;
  }

  public ScheduledEvent.PrivacyLevel privacyLevelOrElse(ScheduledEvent.PrivacyLevel defaultValue) {
    return !privacyLevel_absent ? privacyLevel_value : defaultValue;
  }

  public boolean isScheduledStartTimePresent() {
    return !scheduledStartTime_absent;
  }

  public Instant scheduledStartTimeOrElse(Instant defaultValue) {
    return !scheduledStartTime_absent ? scheduledStartTime_value : defaultValue;
  }

  public boolean isScheduledEndTimePresent() {
    return !scheduledEndTime_absent;
  }

  public Instant scheduledEndTimeOrElse(Instant defaultValue) {
    return !scheduledEndTime_absent ? scheduledEndTime_value : defaultValue;
  }

  public boolean isDescriptionPresent() {
    return !description_absent;
  }

  public String descriptionOrElse(String defaultValue) {
    return !description_absent ? description_value : defaultValue;
  }

  public boolean isEntityTypePresent() {
    return !entityType_absent;
  }

  public ScheduledEvent.EntityType entityTypeOrElse(ScheduledEvent.EntityType defaultValue) {
    return !entityType_absent ? entityType_value : defaultValue;
  }

  public boolean isStatusPresent() {
    return !status_absent;
  }

  public ScheduledEvent.Status statusOrElse(ScheduledEvent.Status defaultValue) {
    return !status_absent ? status_value : defaultValue;
  }

  public boolean isImagePresent() {
    return !image_absent;
  }

  public Image imageOrElse(Image defaultValue) {
    return !image_absent ? image_value : defaultValue;
  }

  /**
   * Creates a builder for {@link ScheduledEventEditSpec ScheduledEventEditSpec}.
   * <pre>
   * ScheduledEventEditSpec.builder()
   *    .reason(String | null) // nullable {@link ScheduledEventEditSpecGenerator#reason() reason}
   *    .channelId(discord4j.discordjson.possible.Possible&amp;lt;Optional&amp;lt;discord4j.common.util.Snowflake&amp;gt;&amp;gt;) // {@link ScheduledEventEditSpecGenerator#channelId() channelId}
   *    .entityMetadata(discord4j.discordjson.possible.Possible&amp;lt;ScheduledEventEntityMetadataSpec&amp;gt;) // {@link ScheduledEventEditSpecGenerator#entityMetadata() entityMetadata}
   *    .name(discord4j.discordjson.possible.Possible&amp;lt;String&amp;gt;) // {@link ScheduledEventEditSpecGenerator#name() name}
   *    .privacyLevel(discord4j.discordjson.possible.Possible&amp;lt;discord4j.core.object.entity.ScheduledEvent.PrivacyLevel&amp;gt;) // {@link ScheduledEventEditSpecGenerator#privacyLevel() privacyLevel}
   *    .scheduledStartTime(discord4j.discordjson.possible.Possible&amp;lt;java.time.Instant&amp;gt;) // {@link ScheduledEventEditSpecGenerator#scheduledStartTime() scheduledStartTime}
   *    .scheduledEndTime(discord4j.discordjson.possible.Possible&amp;lt;java.time.Instant&amp;gt;) // {@link ScheduledEventEditSpecGenerator#scheduledEndTime() scheduledEndTime}
   *    .description(discord4j.discordjson.possible.Possible&amp;lt;String&amp;gt;) // {@link ScheduledEventEditSpecGenerator#description() description}
   *    .entityType(discord4j.discordjson.possible.Possible&amp;lt;discord4j.core.object.entity.ScheduledEvent.EntityType&amp;gt;) // {@link ScheduledEventEditSpecGenerator#entityType() entityType}
   *    .status(discord4j.discordjson.possible.Possible&amp;lt;discord4j.core.object.entity.ScheduledEvent.Status&amp;gt;) // {@link ScheduledEventEditSpecGenerator#status() status}
   *    .image(discord4j.discordjson.possible.Possible&amp;lt;discord4j.rest.util.Image&amp;gt;) // {@link ScheduledEventEditSpecGenerator#image() image}
   *    .build();
   * </pre>
   * @return A new ScheduledEventEditSpec builder
   */
  public static ScheduledEventEditSpec.Builder builder() {
    return new ScheduledEventEditSpec.Builder();
  }

  /**
   * Builds instances of type {@link ScheduledEventEditSpec ScheduledEventEditSpec}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "ScheduledEventEditSpecGenerator", generator = "Immutables")
  public static final class Builder {
    private Possible<Optional<Snowflake>> channelId_possible = Possible.absent();
    private Possible<ScheduledEventEntityMetadataSpec> entityMetadata_possible = Possible.absent();
    private Possible<String> name_possible = Possible.absent();
    private Possible<ScheduledEvent.PrivacyLevel> privacyLevel_possible = Possible.absent();
    private Possible<Instant> scheduledStartTime_possible = Possible.absent();
    private Possible<Instant> scheduledEndTime_possible = Possible.absent();
    private Possible<String> description_possible = Possible.absent();
    private Possible<ScheduledEvent.EntityType> entityType_possible = Possible.absent();
    private Possible<ScheduledEvent.Status> status_possible = Possible.absent();
    private Possible<Image> image_possible = Possible.absent();
    private String reason;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code ScheduledEventEditSpecGenerator} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(ScheduledEventEditSpecGenerator instance) {
      Objects.requireNonNull(instance, "instance");
      String reasonValue = instance.reason();
      if (reasonValue != null) {
        reason(reasonValue);
      }
      channelId(instance.channelId());
      entityMetadata(instance.entityMetadata());
      name(instance.name());
      privacyLevel(instance.privacyLevel());
      scheduledStartTime(instance.scheduledStartTime());
      scheduledEndTime(instance.scheduledEndTime());
      description(instance.description());
      entityType(instance.entityType());
      status(instance.status());
      image(instance.image());
      return this;
    }

    /**
     * Initializes the value for the {@link ScheduledEventEditSpecGenerator#reason() reason} attribute.
     * @param reason The value for reason (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder reason(@Nullable String reason) {
      this.reason = reason;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder channelId(Possible<Optional<Snowflake>> value) {
      this.channelId_possible = value;
      return this;
    }

    @Deprecated
    @CanIgnoreReturnValue
    public Builder channelId(@Nullable Snowflake value) {
      this.channelId_possible = Possible.of(Optional.ofNullable(value));
      return this;
    }

    @CanIgnoreReturnValue
    public Builder channelIdOrNull(@Nullable Snowflake value) {
      this.channelId_possible = Possible.of(Optional.ofNullable(value));
      return this;
    }

    @CanIgnoreReturnValue
    public Builder entityMetadata(Possible<ScheduledEventEntityMetadataSpec> value) {
      this.entityMetadata_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder entityMetadata(ScheduledEventEntityMetadataSpec value) {
      this.entityMetadata_possible = Possible.of(value);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder name(Possible<String> value) {
      this.name_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder name(String value) {
      this.name_possible = Possible.of(value);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder privacyLevel(Possible<ScheduledEvent.PrivacyLevel> value) {
      this.privacyLevel_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder privacyLevel(ScheduledEvent.PrivacyLevel value) {
      this.privacyLevel_possible = Possible.of(value);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder scheduledStartTime(Possible<Instant> value) {
      this.scheduledStartTime_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder scheduledStartTime(Instant value) {
      this.scheduledStartTime_possible = Possible.of(value);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder scheduledEndTime(Possible<Instant> value) {
      this.scheduledEndTime_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder scheduledEndTime(Instant value) {
      this.scheduledEndTime_possible = Possible.of(value);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder description(Possible<String> value) {
      this.description_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder description(String value) {
      this.description_possible = Possible.of(value);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder entityType(Possible<ScheduledEvent.EntityType> value) {
      this.entityType_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder entityType(ScheduledEvent.EntityType value) {
      this.entityType_possible = Possible.of(value);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder status(Possible<ScheduledEvent.Status> value) {
      this.status_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder status(ScheduledEvent.Status value) {
      this.status_possible = Possible.of(value);
      return this;
    }

    @CanIgnoreReturnValue
    public Builder image(Possible<Image> value) {
      this.image_possible = value;
      return this;
    }

    @CanIgnoreReturnValue
    public Builder image(Image value) {
      this.image_possible = Possible.of(value);
      return this;
    }

    /**
     * Builds a new {@link ScheduledEventEditSpec ScheduledEventEditSpec}.
     * @return An immutable instance of ScheduledEventEditSpec
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ScheduledEventEditSpec build() {
      return new ScheduledEventEditSpec(
          reason,
          channelId_build(),
          entityMetadata_build(),
          name_build(),
          privacyLevel_build(),
          scheduledStartTime_build(),
          scheduledEndTime_build(),
          description_build(),
          entityType_build(),
          status_build(),
          image_build());
    }

    private Possible<Optional<Snowflake>> channelId_build() {
      return this.channelId_possible;
    }

    private Possible<ScheduledEventEntityMetadataSpec> entityMetadata_build() {
      return this.entityMetadata_possible;
    }

    private Possible<String> name_build() {
      return this.name_possible;
    }

    private Possible<ScheduledEvent.PrivacyLevel> privacyLevel_build() {
      return this.privacyLevel_possible;
    }

    private Possible<Instant> scheduledStartTime_build() {
      return this.scheduledStartTime_possible;
    }

    private Possible<Instant> scheduledEndTime_build() {
      return this.scheduledEndTime_possible;
    }

    private Possible<String> description_build() {
      return this.description_possible;
    }

    private Possible<ScheduledEvent.EntityType> entityType_build() {
      return this.entityType_possible;
    }

    private Possible<ScheduledEvent.Status> status_build() {
      return this.status_possible;
    }

    private Possible<Image> image_build() {
      return this.image_possible;
    }
  }
}
