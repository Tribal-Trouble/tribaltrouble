package discord4j.core.spec;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.immutables.value.Generated;
import reactor.util.annotation.Nullable;

/**
 * Immutable implementation of {@link GuildStickerCreateSpecGenerator}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code GuildStickerCreateSpec.builder()}.
 * Use the static factory method to create immutable instances:
 * {@code GuildStickerCreateSpec.of()}.
 */
@Generated(from = "GuildStickerCreateSpecGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class GuildStickerCreateSpec implements GuildStickerCreateSpecGenerator {
  private final @Nullable String reason;
  private final String name;
  private final String description;
  private final String tags;
  private final String file;

  private GuildStickerCreateSpec(String name, String description, String tags, String file) {
    this.name = Objects.requireNonNull(name, "name");
    this.description = Objects.requireNonNull(description, "description");
    this.tags = Objects.requireNonNull(tags, "tags");
    this.file = Objects.requireNonNull(file, "file");
    this.reason = null;
  }

  private GuildStickerCreateSpec(
      @Nullable String reason,
      String name,
      String description,
      String tags,
      String file) {
    this.reason = reason;
    this.name = name;
    this.description = description;
    this.tags = tags;
    this.file = file;
  }

  /**
   * Returns the current audit log reason set on the spec.
   * @return The current audit log reason.
   */
  @Override
  public @Nullable String reason() {
    return reason;
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public String name() {
    return name;
  }

  /**
   * @return The value of the {@code description} attribute
   */
  @Override
  public String description() {
    return description;
  }

  /**
   * @return The value of the {@code tags} attribute
   */
  @Override
  public String tags() {
    return tags;
  }

  /**
   * @return The value of the {@code file} attribute
   */
  @Override
  public String file() {
    return file;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerCreateSpec#reason() reason} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for reason (can be {@code null})
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerCreateSpec withReason(@Nullable String value) {
    if (Objects.equals(this.reason, value)) return this;
    return new GuildStickerCreateSpec(value, this.name, this.description, this.tags, this.file);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerCreateSpec#name() name} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for name
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerCreateSpec withName(String value) {
    String newValue = Objects.requireNonNull(value, "name");
    if (this.name.equals(newValue)) return this;
    return new GuildStickerCreateSpec(this.reason, newValue, this.description, this.tags, this.file);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerCreateSpec#description() description} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for description
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerCreateSpec withDescription(String value) {
    String newValue = Objects.requireNonNull(value, "description");
    if (this.description.equals(newValue)) return this;
    return new GuildStickerCreateSpec(this.reason, this.name, newValue, this.tags, this.file);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerCreateSpec#tags() tags} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for tags
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerCreateSpec withTags(String value) {
    String newValue = Objects.requireNonNull(value, "tags");
    if (this.tags.equals(newValue)) return this;
    return new GuildStickerCreateSpec(this.reason, this.name, this.description, newValue, this.file);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerCreateSpec#file() file} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for file
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerCreateSpec withFile(String value) {
    String newValue = Objects.requireNonNull(value, "file");
    if (this.file.equals(newValue)) return this;
    return new GuildStickerCreateSpec(this.reason, this.name, this.description, this.tags, newValue);
  }

  /**
   * This instance is equal to all instances of {@code GuildStickerCreateSpec} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof GuildStickerCreateSpec
        && equalTo(0, (GuildStickerCreateSpec) another);
  }

  private boolean equalTo(int synthetic, GuildStickerCreateSpec another) {
    return Objects.equals(reason, another.reason)
        && name.equals(another.name)
        && description.equals(another.description)
        && tags.equals(another.tags)
        && file.equals(another.file);
  }

  /**
   * Computes a hash code from attributes: {@code reason}, {@code name}, {@code description}, {@code tags}, {@code file}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(reason);
    h += (h << 5) + name.hashCode();
    h += (h << 5) + description.hashCode();
    h += (h << 5) + tags.hashCode();
    h += (h << 5) + file.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code GuildStickerCreateSpec} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "GuildStickerCreateSpec{"
        + "reason=" + reason
        + ", name=" + name
        + ", description=" + description
        + ", tags=" + tags
        + ", file=" + file
        + "}";
  }

  /**
   * Construct a new immutable {@code GuildStickerCreateSpec} instance.
   * @param name The value for the {@code name} attribute
   * @param description The value for the {@code description} attribute
   * @param tags The value for the {@code tags} attribute
   * @param file The value for the {@code file} attribute
   * @return An immutable GuildStickerCreateSpec instance
   */
  public static GuildStickerCreateSpec of(String name, String description, String tags, String file) {
    return new GuildStickerCreateSpec(name, description, tags, file);
  }

  /**
   * Creates an immutable copy of a {@link GuildStickerCreateSpecGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable GuildStickerCreateSpec instance
   */
  static GuildStickerCreateSpec copyOf(GuildStickerCreateSpecGenerator instance) {
    if (instance instanceof GuildStickerCreateSpec) {
      return (GuildStickerCreateSpec) instance;
    }
    return GuildStickerCreateSpec.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link GuildStickerCreateSpec GuildStickerCreateSpec}.
   * <pre>
   * GuildStickerCreateSpec.builder()
   *    .reason(String | null) // nullable {@link GuildStickerCreateSpec#reason() reason}
   *    .name(String) // required {@link GuildStickerCreateSpec#name() name}
   *    .description(String) // required {@link GuildStickerCreateSpec#description() description}
   *    .tags(String) // required {@link GuildStickerCreateSpec#tags() tags}
   *    .file(String) // required {@link GuildStickerCreateSpec#file() file}
   *    .build();
   * </pre>
   * @return A new GuildStickerCreateSpec builder
   */
  public static GuildStickerCreateSpec.Builder builder() {
    return new GuildStickerCreateSpec.Builder();
  }

  /**
   * Builds instances of type {@link GuildStickerCreateSpec GuildStickerCreateSpec}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "GuildStickerCreateSpecGenerator", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_NAME = 0x1L;
    private static final long INIT_BIT_DESCRIPTION = 0x2L;
    private static final long INIT_BIT_TAGS = 0x4L;
    private static final long INIT_BIT_FILE = 0x8L;
    private long initBits = 0xfL;

    private String reason;
    private String name;
    private String description;
    private String tags;
    private String file;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code GuildStickerCreateSpec} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder from(GuildStickerCreateSpec instance) {
      return from((GuildStickerCreateSpecGenerator) instance);
    }

    /**
     * Copy abstract value type {@code GuildStickerCreateSpecGenerator} instance into builder.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    final Builder from(GuildStickerCreateSpecGenerator instance) {
      Objects.requireNonNull(instance, "instance");
      String reasonValue = instance.reason();
      if (reasonValue != null) {
        reason(reasonValue);
      }
      name(instance.name());
      description(instance.description());
      tags(instance.tags());
      file(instance.file());
      return this;
    }

    /**
     * Initializes the value for the {@link GuildStickerCreateSpec#reason() reason} attribute.
     * @param reason The value for reason (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder reason(@Nullable String reason) {
      this.reason = reason;
      return this;
    }

    /**
     * Initializes the value for the {@link GuildStickerCreateSpec#name() name} attribute.
     * @param name The value for name 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder name(String name) {
      this.name = Objects.requireNonNull(name, "name");
      initBits &= ~INIT_BIT_NAME;
      return this;
    }

    /**
     * Initializes the value for the {@link GuildStickerCreateSpec#description() description} attribute.
     * @param description The value for description 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder description(String description) {
      this.description = Objects.requireNonNull(description, "description");
      initBits &= ~INIT_BIT_DESCRIPTION;
      return this;
    }

    /**
     * Initializes the value for the {@link GuildStickerCreateSpec#tags() tags} attribute.
     * @param tags The value for tags 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder tags(String tags) {
      this.tags = Objects.requireNonNull(tags, "tags");
      initBits &= ~INIT_BIT_TAGS;
      return this;
    }

    /**
     * Initializes the value for the {@link GuildStickerCreateSpec#file() file} attribute.
     * @param file The value for file 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder file(String file) {
      this.file = Objects.requireNonNull(file, "file");
      initBits &= ~INIT_BIT_FILE;
      return this;
    }

    /**
     * Builds a new {@link GuildStickerCreateSpec GuildStickerCreateSpec}.
     * @return An immutable instance of GuildStickerCreateSpec
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public GuildStickerCreateSpec build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new GuildStickerCreateSpec(reason, name, description, tags, file);
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_NAME) != 0) attributes.add("name");
      if ((initBits & INIT_BIT_DESCRIPTION) != 0) attributes.add("description");
      if ((initBits & INIT_BIT_TAGS) != 0) attributes.add("tags");
      if ((initBits & INIT_BIT_FILE) != 0) attributes.add("file");
      return "Cannot build GuildStickerCreateSpec, some of required attributes are not set " + attributes;
    }
  }
}
