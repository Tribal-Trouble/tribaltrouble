package discord4j.core.spec;

import com.google.errorprone.annotations.Var;
import discord4j.common.util.Snowflake;
import discord4j.core.object.entity.Guild;
import discord4j.core.object.entity.ScheduledEvent;
import discord4j.discordjson.possible.Possible;
import discord4j.rest.util.Image;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.immutables.value.Generated;
import reactor.util.annotation.Nullable;

/**
 * Immutable implementation of {@link ScheduledEventCreateMonoGenerator}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code ScheduledEventCreateMono.of()}.
 */
@Generated(from = "ScheduledEventCreateMonoGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class ScheduledEventCreateMono extends ScheduledEventCreateMonoGenerator {
  private final @Nullable String reason;
  private final Snowflake channelId_value;
  private final boolean channelId_absent;
  private final ScheduledEventEntityMetadataSpec entityMetadata_value;
  private final boolean entityMetadata_absent;
  private final String name;
  private final ScheduledEvent.PrivacyLevel privacyLevel;
  private final Instant scheduledStartTime;
  private final Instant scheduledEndTime_value;
  private final boolean scheduledEndTime_absent;
  private final String description_value;
  private final boolean description_absent;
  private final ScheduledEvent.EntityType entityType;
  private final Image image_value;
  private final boolean image_absent;
  private final Guild guild;

  private ScheduledEventCreateMono(
      String name,
      ScheduledEvent.PrivacyLevel privacyLevel,
      Instant scheduledStartTime,
      ScheduledEvent.EntityType entityType,
      Guild guild) {
    this.name = Objects.requireNonNull(name, "name");
    this.privacyLevel = Objects.requireNonNull(privacyLevel, "privacyLevel");
    this.scheduledStartTime = Objects.requireNonNull(scheduledStartTime, "scheduledStartTime");
    this.entityType = Objects.requireNonNull(entityType, "entityType");
    this.guild = Objects.requireNonNull(guild, "guild");
    this.reason = null;
    Possible<Snowflake> channelId$impl = Possible.absent();
    Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = Possible.absent();
    Possible<Instant> scheduledEndTime$impl = Possible.absent();
    Possible<String> description$impl = Possible.absent();
    Possible<Image> image$impl = Possible.absent();
    this.channelId_value = channelId$impl.toOptional().orElse(null);
    this.channelId_absent = channelId$impl.isAbsent();
    this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null);
    this.entityMetadata_absent = entityMetadata$impl.isAbsent();
    this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
    this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
    this.description_value = description$impl.toOptional().orElse(null);
    this.description_absent = description$impl.isAbsent();
    this.image_value = image$impl.toOptional().orElse(null);
    this.image_absent = image$impl.isAbsent();
    this.initShim = null;
  }

  private ScheduledEventCreateMono(
      @Nullable String reason,
      Possible<Snowflake> channelId,
      Possible<ScheduledEventEntityMetadataSpec> entityMetadata,
      String name,
      ScheduledEvent.PrivacyLevel privacyLevel,
      Instant scheduledStartTime,
      Possible<Instant> scheduledEndTime,
      Possible<String> description,
      ScheduledEvent.EntityType entityType,
      Possible<Image> image,
      Guild guild) {
    this.reason = reason;
    Possible<Snowflake> channelId$impl = channelId;
    Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = entityMetadata;
    this.name = name;
    this.privacyLevel = privacyLevel;
    this.scheduledStartTime = scheduledStartTime;
    Possible<Instant> scheduledEndTime$impl = scheduledEndTime;
    Possible<String> description$impl = description;
    this.entityType = entityType;
    Possible<Image> image$impl = image;
    this.guild = guild;
    this.channelId_value = channelId$impl.toOptional().orElse(null);
    this.channelId_absent = channelId$impl.isAbsent();
    this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null);
    this.entityMetadata_absent = entityMetadata$impl.isAbsent();
    this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
    this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
    this.description_value = description$impl.toOptional().orElse(null);
    this.description_absent = description$impl.isAbsent();
    this.image_value = image$impl.toOptional().orElse(null);
    this.image_absent = image$impl.isAbsent();
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "ScheduledEventCreateMonoGenerator", generator = "Immutables")
  private final class InitShim {
    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      return "Cannot build ScheduledEventCreateMono, attribute initializers form cycle " + attributes;
    }
  }

  /**
   * Returns the current audit log reason set on the spec.
   * @return The current audit log reason.
   */
  @Override
  public @Nullable String reason() {
    return reason;
  }

  /**
   * @return The value of the {@code channelId} attribute
   */
  @Override
  public Possible<Snowflake> channelId() {
    return channelId_absent ? Possible.absent() : Possible.of(channelId_value);
  }

  /**
   * @return The value of the {@code entityMetadata} attribute
   */
  @Override
  public Possible<ScheduledEventEntityMetadataSpec> entityMetadata() {
    return entityMetadata_absent ? Possible.absent() : Possible.of(entityMetadata_value);
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public String name() {
    return name;
  }

  /**
   * @return The value of the {@code privacyLevel} attribute
   */
  @Override
  public ScheduledEvent.PrivacyLevel privacyLevel() {
    return privacyLevel;
  }

  /**
   * @return The value of the {@code scheduledStartTime} attribute
   */
  @Override
  public Instant scheduledStartTime() {
    return scheduledStartTime;
  }

  /**
   * @return The value of the {@code scheduledEndTime} attribute
   */
  @Override
  public Possible<Instant> scheduledEndTime() {
    return scheduledEndTime_absent ? Possible.absent() : Possible.of(scheduledEndTime_value);
  }

  /**
   * @return The value of the {@code description} attribute
   */
  @Override
  public Possible<String> description() {
    return description_absent ? Possible.absent() : Possible.of(description_value);
  }

  /**
   * @return The value of the {@code entityType} attribute
   */
  @Override
  public ScheduledEvent.EntityType entityType() {
    return entityType;
  }

  /**
   * @return The value of the {@code image} attribute
   */
  @Override
  public Possible<Image> image() {
    return image_absent ? Possible.absent() : Possible.of(image_value);
  }

  /**
   * @return The value of the {@code guild} attribute
   */
  @Override
  public Guild guild() {
    return guild;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventCreateMono#reason() reason} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for reason (can be {@code null})
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventCreateMono withReason(@Nullable String value) {
    if (Objects.equals(this.reason, value)) return this;
    return new ScheduledEventCreateMono(
        value,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image(),
        this.guild);
  }

  public ScheduledEventCreateMono withChannelId(Possible<Snowflake> value) {
    Possible<Snowflake> newValue = Objects.requireNonNull(value);
    return new ScheduledEventCreateMono(
        this.reason,
        newValue,
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image(),
        this.guild);
  }

  public ScheduledEventCreateMono withChannelId(Snowflake value) {
    Possible<Snowflake> newValue = Possible.of(value);
    return new ScheduledEventCreateMono(
        this.reason,
        newValue,
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image(),
        this.guild);
  }

  public ScheduledEventCreateMono withEntityMetadata(Possible<ScheduledEventEntityMetadataSpec> value) {
    Possible<ScheduledEventEntityMetadataSpec> newValue = Objects.requireNonNull(value);
    return new ScheduledEventCreateMono(
        this.reason,
        this.channelId(),
        newValue,
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image(),
        this.guild);
  }

  public ScheduledEventCreateMono withEntityMetadata(ScheduledEventEntityMetadataSpec value) {
    Possible<ScheduledEventEntityMetadataSpec> newValue = Possible.of(value);
    return new ScheduledEventCreateMono(
        this.reason,
        this.channelId(),
        newValue,
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image(),
        this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventCreateMono#name() name} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for name
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventCreateMono withName(String value) {
    String newValue = Objects.requireNonNull(value, "name");
    if (this.name.equals(newValue)) return this;
    return new ScheduledEventCreateMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        newValue,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image(),
        this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventCreateMono#privacyLevel() privacyLevel} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for privacyLevel
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventCreateMono withPrivacyLevel(ScheduledEvent.PrivacyLevel value) {
    ScheduledEvent.PrivacyLevel newValue = Objects.requireNonNull(value, "privacyLevel");
    if (this.privacyLevel == newValue) return this;
    return new ScheduledEventCreateMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        newValue,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image(),
        this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventCreateMono#scheduledStartTime() scheduledStartTime} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for scheduledStartTime
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventCreateMono withScheduledStartTime(Instant value) {
    if (this.scheduledStartTime == value) return this;
    Instant newValue = Objects.requireNonNull(value, "scheduledStartTime");
    return new ScheduledEventCreateMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        newValue,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image(),
        this.guild);
  }

  public ScheduledEventCreateMono withScheduledEndTime(Possible<Instant> value) {
    Possible<Instant> newValue = Objects.requireNonNull(value);
    return new ScheduledEventCreateMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        newValue,
        this.description(),
        this.entityType,
        this.image(),
        this.guild);
  }

  public ScheduledEventCreateMono withScheduledEndTime(Instant value) {
    Possible<Instant> newValue = Possible.of(value);
    return new ScheduledEventCreateMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        newValue,
        this.description(),
        this.entityType,
        this.image(),
        this.guild);
  }

  public ScheduledEventCreateMono withDescription(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return new ScheduledEventCreateMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        newValue,
        this.entityType,
        this.image(),
        this.guild);
  }

  public ScheduledEventCreateMono withDescription(String value) {
    Possible<String> newValue = Possible.of(value);
    return new ScheduledEventCreateMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        newValue,
        this.entityType,
        this.image(),
        this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventCreateMono#entityType() entityType} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for entityType
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventCreateMono withEntityType(ScheduledEvent.EntityType value) {
    ScheduledEvent.EntityType newValue = Objects.requireNonNull(value, "entityType");
    if (this.entityType == newValue) return this;
    return new ScheduledEventCreateMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        newValue,
        this.image(),
        this.guild);
  }

  public ScheduledEventCreateMono withImage(Possible<Image> value) {
    Possible<Image> newValue = Objects.requireNonNull(value);
    return new ScheduledEventCreateMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        newValue,
        this.guild);
  }

  public ScheduledEventCreateMono withImage(Image value) {
    Possible<Image> newValue = Possible.of(value);
    return new ScheduledEventCreateMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        newValue,
        this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventCreateMono#guild() guild} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for guild
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventCreateMono withGuild(Guild value) {
    if (this.guild == value) return this;
    Guild newValue = Objects.requireNonNull(value, "guild");
    return new ScheduledEventCreateMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name,
        this.privacyLevel,
        this.scheduledStartTime,
        this.scheduledEndTime(),
        this.description(),
        this.entityType,
        this.image(),
        newValue);
  }

  /**
   * This instance is equal to all instances of {@code ScheduledEventCreateMono} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof ScheduledEventCreateMono
        && equalTo(0, (ScheduledEventCreateMono) another);
  }

  private boolean equalTo(int synthetic, ScheduledEventCreateMono another) {
    return Objects.equals(reason, another.reason)
        && this.channelId().equals(another.channelId())
        && this.entityMetadata().equals(another.entityMetadata())
        && name.equals(another.name)
        && privacyLevel.equals(another.privacyLevel)
        && scheduledStartTime.equals(another.scheduledStartTime)
        && this.scheduledEndTime().equals(another.scheduledEndTime())
        && this.description().equals(another.description())
        && entityType.equals(another.entityType)
        && this.image().equals(another.image())
        && guild.equals(another.guild);
  }

  /**
   * Computes a hash code from attributes: {@code reason}, {@code channelId}, {@code entityMetadata}, {@code name}, {@code privacyLevel}, {@code scheduledStartTime}, {@code scheduledEndTime}, {@code description}, {@code entityType}, {@code image}, {@code guild}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(reason);
    h += (h << 5) + (channelId().hashCode());
    h += (h << 5) + (entityMetadata().hashCode());
    h += (h << 5) + name.hashCode();
    h += (h << 5) + privacyLevel.hashCode();
    h += (h << 5) + scheduledStartTime.hashCode();
    h += (h << 5) + (scheduledEndTime().hashCode());
    h += (h << 5) + (description().hashCode());
    h += (h << 5) + entityType.hashCode();
    h += (h << 5) + (image().hashCode());
    h += (h << 5) + guild.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code ScheduledEventCreateMono} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "ScheduledEventCreateMono{"
        + "reason=" + reason
        + ", channelId=" + (channelId().toString())
        + ", entityMetadata=" + (entityMetadata().toString())
        + ", name=" + name
        + ", privacyLevel=" + privacyLevel
        + ", scheduledStartTime=" + scheduledStartTime
        + ", scheduledEndTime=" + (scheduledEndTime().toString())
        + ", description=" + (description().toString())
        + ", entityType=" + entityType
        + ", image=" + (image().toString())
        + ", guild=" + guild
        + "}";
  }

  /**
   * Construct a new immutable {@code ScheduledEventCreateMono} instance.
   * @param name The value for the {@code name} attribute
   * @param privacyLevel The value for the {@code privacyLevel} attribute
   * @param scheduledStartTime The value for the {@code scheduledStartTime} attribute
   * @param entityType The value for the {@code entityType} attribute
   * @param guild The value for the {@code guild} attribute
   * @return An immutable ScheduledEventCreateMono instance
   */
  public static ScheduledEventCreateMono of(String name, ScheduledEvent.PrivacyLevel privacyLevel, Instant scheduledStartTime, ScheduledEvent.EntityType entityType, Guild guild) {
    return new ScheduledEventCreateMono(name, privacyLevel, scheduledStartTime, entityType, guild);
  }

  /**
   * Creates an immutable copy of a {@link ScheduledEventCreateMonoGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable ScheduledEventCreateMono instance
   */
  static ScheduledEventCreateMono copyOf(ScheduledEventCreateMonoGenerator instance) {
    if (instance instanceof ScheduledEventCreateMono) {
      return (ScheduledEventCreateMono) instance;
    }
    return ScheduledEventCreateMono.of(instance.name(), instance.privacyLevel(), instance.scheduledStartTime(), instance.entityType(), instance.guild())
        .withReason(instance.reason())
        .withChannelId(instance.channelId())
        .withEntityMetadata(instance.entityMetadata())
        .withScheduledEndTime(instance.scheduledEndTime())
        .withDescription(instance.description())
        .withImage(instance.image());
  }

  public boolean isChannelIdPresent() {
    return !channelId_absent;
  }

  public Snowflake channelIdOrElse(Snowflake defaultValue) {
    return !channelId_absent ? channelId_value : defaultValue;
  }

  public boolean isEntityMetadataPresent() {
    return !entityMetadata_absent;
  }

  public ScheduledEventEntityMetadataSpec entityMetadataOrElse(ScheduledEventEntityMetadataSpec defaultValue) {
    return !entityMetadata_absent ? entityMetadata_value : defaultValue;
  }

  public boolean isScheduledEndTimePresent() {
    return !scheduledEndTime_absent;
  }

  public Instant scheduledEndTimeOrElse(Instant defaultValue) {
    return !scheduledEndTime_absent ? scheduledEndTime_value : defaultValue;
  }

  public boolean isDescriptionPresent() {
    return !description_absent;
  }

  public String descriptionOrElse(String defaultValue) {
    return !description_absent ? description_value : defaultValue;
  }

  public boolean isImagePresent() {
    return !image_absent;
  }

  public Image imageOrElse(Image defaultValue) {
    return !image_absent ? image_value : defaultValue;
  }
}
