package discord4j.core.spec;

import com.google.errorprone.annotations.Var;
import discord4j.core.object.entity.Guild;
import java.util.Objects;
import org.immutables.value.Generated;
import reactor.util.annotation.Nullable;

/**
 * Immutable implementation of {@link GuildStickerCreateMonoGenerator}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code GuildStickerCreateMono.of()}.
 */
@Generated(from = "GuildStickerCreateMonoGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class GuildStickerCreateMono extends GuildStickerCreateMonoGenerator {
  private final @Nullable String reason;
  private final String name;
  private final String description;
  private final String tags;
  private final String file;
  private final Guild guild;

  private GuildStickerCreateMono(
      String name,
      String description,
      String tags,
      String file,
      Guild guild) {
    this.name = Objects.requireNonNull(name, "name");
    this.description = Objects.requireNonNull(description, "description");
    this.tags = Objects.requireNonNull(tags, "tags");
    this.file = Objects.requireNonNull(file, "file");
    this.guild = Objects.requireNonNull(guild, "guild");
    this.reason = null;
  }

  private GuildStickerCreateMono(
      @Nullable String reason,
      String name,
      String description,
      String tags,
      String file,
      Guild guild) {
    this.reason = reason;
    this.name = name;
    this.description = description;
    this.tags = tags;
    this.file = file;
    this.guild = guild;
  }

  /**
   * Returns the current audit log reason set on the spec.
   * @return The current audit log reason.
   */
  @Override
  public @Nullable String reason() {
    return reason;
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public String name() {
    return name;
  }

  /**
   * @return The value of the {@code description} attribute
   */
  @Override
  public String description() {
    return description;
  }

  /**
   * @return The value of the {@code tags} attribute
   */
  @Override
  public String tags() {
    return tags;
  }

  /**
   * @return The value of the {@code file} attribute
   */
  @Override
  public String file() {
    return file;
  }

  /**
   * @return The value of the {@code guild} attribute
   */
  @Override
  public Guild guild() {
    return guild;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerCreateMono#reason() reason} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for reason (can be {@code null})
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerCreateMono withReason(@Nullable String value) {
    if (Objects.equals(this.reason, value)) return this;
    return new GuildStickerCreateMono(value, this.name, this.description, this.tags, this.file, this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerCreateMono#name() name} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for name
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerCreateMono withName(String value) {
    String newValue = Objects.requireNonNull(value, "name");
    if (this.name.equals(newValue)) return this;
    return new GuildStickerCreateMono(this.reason, newValue, this.description, this.tags, this.file, this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerCreateMono#description() description} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for description
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerCreateMono withDescription(String value) {
    String newValue = Objects.requireNonNull(value, "description");
    if (this.description.equals(newValue)) return this;
    return new GuildStickerCreateMono(this.reason, this.name, newValue, this.tags, this.file, this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerCreateMono#tags() tags} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for tags
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerCreateMono withTags(String value) {
    String newValue = Objects.requireNonNull(value, "tags");
    if (this.tags.equals(newValue)) return this;
    return new GuildStickerCreateMono(this.reason, this.name, this.description, newValue, this.file, this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerCreateMono#file() file} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for file
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerCreateMono withFile(String value) {
    String newValue = Objects.requireNonNull(value, "file");
    if (this.file.equals(newValue)) return this;
    return new GuildStickerCreateMono(this.reason, this.name, this.description, this.tags, newValue, this.guild);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link GuildStickerCreateMono#guild() guild} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for guild
   * @return A modified copy of the {@code this} object
   */
  public final GuildStickerCreateMono withGuild(Guild value) {
    if (this.guild == value) return this;
    Guild newValue = Objects.requireNonNull(value, "guild");
    return new GuildStickerCreateMono(this.reason, this.name, this.description, this.tags, this.file, newValue);
  }

  /**
   * This instance is equal to all instances of {@code GuildStickerCreateMono} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof GuildStickerCreateMono
        && equalTo(0, (GuildStickerCreateMono) another);
  }

  private boolean equalTo(int synthetic, GuildStickerCreateMono another) {
    return Objects.equals(reason, another.reason)
        && name.equals(another.name)
        && description.equals(another.description)
        && tags.equals(another.tags)
        && file.equals(another.file)
        && guild.equals(another.guild);
  }

  /**
   * Computes a hash code from attributes: {@code reason}, {@code name}, {@code description}, {@code tags}, {@code file}, {@code guild}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(reason);
    h += (h << 5) + name.hashCode();
    h += (h << 5) + description.hashCode();
    h += (h << 5) + tags.hashCode();
    h += (h << 5) + file.hashCode();
    h += (h << 5) + guild.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code GuildStickerCreateMono} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "GuildStickerCreateMono{"
        + "reason=" + reason
        + ", name=" + name
        + ", description=" + description
        + ", tags=" + tags
        + ", file=" + file
        + ", guild=" + guild
        + "}";
  }

  /**
   * Construct a new immutable {@code GuildStickerCreateMono} instance.
   * @param name The value for the {@code name} attribute
   * @param description The value for the {@code description} attribute
   * @param tags The value for the {@code tags} attribute
   * @param file The value for the {@code file} attribute
   * @param guild The value for the {@code guild} attribute
   * @return An immutable GuildStickerCreateMono instance
   */
  public static GuildStickerCreateMono of(String name, String description, String tags, String file, Guild guild) {
    return new GuildStickerCreateMono(name, description, tags, file, guild);
  }

  /**
   * Creates an immutable copy of a {@link GuildStickerCreateMonoGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable GuildStickerCreateMono instance
   */
  static GuildStickerCreateMono copyOf(GuildStickerCreateMonoGenerator instance) {
    if (instance instanceof GuildStickerCreateMono) {
      return (GuildStickerCreateMono) instance;
    }
    return GuildStickerCreateMono.of(instance.name(), instance.description(), instance.tags(), instance.file(), instance.guild())
        .withReason(instance.reason());
  }
}
