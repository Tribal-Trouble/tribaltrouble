package discord4j.core.spec;

import com.google.errorprone.annotations.Var;
import discord4j.common.util.Snowflake;
import discord4j.core.object.entity.ScheduledEvent;
import discord4j.discordjson.possible.Possible;
import discord4j.rest.util.Image;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.immutables.value.Generated;
import reactor.util.annotation.Nullable;

/**
 * Immutable implementation of {@link ScheduledEventEditMonoGenerator}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code ScheduledEventEditMono.of()}.
 */
@Generated(from = "ScheduledEventEditMonoGenerator", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class ScheduledEventEditMono extends ScheduledEventEditMonoGenerator {
  private final @Nullable String reason;
  private final Snowflake channelId_value;
  private final boolean channelId_absent;
  private final ScheduledEventEntityMetadataSpec entityMetadata_value;
  private final boolean entityMetadata_absent;
  private final String name_value;
  private final boolean name_absent;
  private final ScheduledEvent.PrivacyLevel privacyLevel_value;
  private final boolean privacyLevel_absent;
  private final Instant scheduledStartTime_value;
  private final boolean scheduledStartTime_absent;
  private final Instant scheduledEndTime_value;
  private final boolean scheduledEndTime_absent;
  private final String description_value;
  private final boolean description_absent;
  private final ScheduledEvent.EntityType entityType_value;
  private final boolean entityType_absent;
  private final ScheduledEvent.Status status_value;
  private final boolean status_absent;
  private final Image image_value;
  private final boolean image_absent;
  private final ScheduledEvent event;

  private ScheduledEventEditMono(ScheduledEvent event) {
    this.event = Objects.requireNonNull(event, "event");
    this.reason = null;
    Possible<Optional<Snowflake>> channelId$impl = Possible.absent();
    Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = Possible.absent();
    Possible<String> name$impl = Possible.absent();
    Possible<ScheduledEvent.PrivacyLevel> privacyLevel$impl = Possible.absent();
    Possible<Instant> scheduledStartTime$impl = Possible.absent();
    Possible<Instant> scheduledEndTime$impl = Possible.absent();
    Possible<String> description$impl = Possible.absent();
    Possible<ScheduledEvent.EntityType> entityType$impl = Possible.absent();
    Possible<ScheduledEvent.Status> status$impl = Possible.absent();
    Possible<Image> image$impl = Possible.absent();
    this.channelId_value = Possible.flatOpt(channelId$impl).orElse(null);
    this.channelId_absent = channelId$impl.isAbsent();
    this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null);
    this.entityMetadata_absent = entityMetadata$impl.isAbsent();
    this.name_value = name$impl.toOptional().orElse(null);
    this.name_absent = name$impl.isAbsent();
    this.privacyLevel_value = privacyLevel$impl.toOptional().orElse(null);
    this.privacyLevel_absent = privacyLevel$impl.isAbsent();
    this.scheduledStartTime_value = scheduledStartTime$impl.toOptional().orElse(null);
    this.scheduledStartTime_absent = scheduledStartTime$impl.isAbsent();
    this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
    this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
    this.description_value = description$impl.toOptional().orElse(null);
    this.description_absent = description$impl.isAbsent();
    this.entityType_value = entityType$impl.toOptional().orElse(null);
    this.entityType_absent = entityType$impl.isAbsent();
    this.status_value = status$impl.toOptional().orElse(null);
    this.status_absent = status$impl.isAbsent();
    this.image_value = image$impl.toOptional().orElse(null);
    this.image_absent = image$impl.isAbsent();
    this.initShim = null;
  }

  private ScheduledEventEditMono(
      @Nullable String reason,
      Possible<Optional<Snowflake>> channelId,
      Possible<ScheduledEventEntityMetadataSpec> entityMetadata,
      Possible<String> name,
      Possible<ScheduledEvent.PrivacyLevel> privacyLevel,
      Possible<Instant> scheduledStartTime,
      Possible<Instant> scheduledEndTime,
      Possible<String> description,
      Possible<ScheduledEvent.EntityType> entityType,
      Possible<ScheduledEvent.Status> status,
      Possible<Image> image,
      ScheduledEvent event) {
    this.reason = reason;
    Possible<Optional<Snowflake>> channelId$impl = channelId;
    Possible<ScheduledEventEntityMetadataSpec> entityMetadata$impl = entityMetadata;
    Possible<String> name$impl = name;
    Possible<ScheduledEvent.PrivacyLevel> privacyLevel$impl = privacyLevel;
    Possible<Instant> scheduledStartTime$impl = scheduledStartTime;
    Possible<Instant> scheduledEndTime$impl = scheduledEndTime;
    Possible<String> description$impl = description;
    Possible<ScheduledEvent.EntityType> entityType$impl = entityType;
    Possible<ScheduledEvent.Status> status$impl = status;
    Possible<Image> image$impl = image;
    this.event = event;
    this.channelId_value = Possible.flatOpt(channelId$impl).orElse(null);
    this.channelId_absent = channelId$impl.isAbsent();
    this.entityMetadata_value = entityMetadata$impl.toOptional().orElse(null);
    this.entityMetadata_absent = entityMetadata$impl.isAbsent();
    this.name_value = name$impl.toOptional().orElse(null);
    this.name_absent = name$impl.isAbsent();
    this.privacyLevel_value = privacyLevel$impl.toOptional().orElse(null);
    this.privacyLevel_absent = privacyLevel$impl.isAbsent();
    this.scheduledStartTime_value = scheduledStartTime$impl.toOptional().orElse(null);
    this.scheduledStartTime_absent = scheduledStartTime$impl.isAbsent();
    this.scheduledEndTime_value = scheduledEndTime$impl.toOptional().orElse(null);
    this.scheduledEndTime_absent = scheduledEndTime$impl.isAbsent();
    this.description_value = description$impl.toOptional().orElse(null);
    this.description_absent = description$impl.isAbsent();
    this.entityType_value = entityType$impl.toOptional().orElse(null);
    this.entityType_absent = entityType$impl.isAbsent();
    this.status_value = status$impl.toOptional().orElse(null);
    this.status_absent = status$impl.isAbsent();
    this.image_value = image$impl.toOptional().orElse(null);
    this.image_absent = image$impl.isAbsent();
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "ScheduledEventEditMonoGenerator", generator = "Immutables")
  private final class InitShim {
    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      return "Cannot build ScheduledEventEditMono, attribute initializers form cycle " + attributes;
    }
  }

  /**
   * Returns the current audit log reason set on the spec.
   * @return The current audit log reason.
   */
  @Override
  public @Nullable String reason() {
    return reason;
  }

  /**
   * @return The value of the {@code channelId} attribute
   */
  @Override
  public Possible<Optional<Snowflake>> channelId() {
    return channelId_absent ? Possible.absent() :
        Possible.of(Optional.ofNullable(channelId_value));
  }

  /**
   * @return The value of the {@code entityMetadata} attribute
   */
  @Override
  public Possible<ScheduledEventEntityMetadataSpec> entityMetadata() {
    return entityMetadata_absent ? Possible.absent() : Possible.of(entityMetadata_value);
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public Possible<String> name() {
    return name_absent ? Possible.absent() : Possible.of(name_value);
  }

  /**
   * @return The value of the {@code privacyLevel} attribute
   */
  @Override
  public Possible<ScheduledEvent.PrivacyLevel> privacyLevel() {
    return privacyLevel_absent ? Possible.absent() : Possible.of(privacyLevel_value);
  }

  /**
   * @return The value of the {@code scheduledStartTime} attribute
   */
  @Override
  public Possible<Instant> scheduledStartTime() {
    return scheduledStartTime_absent ? Possible.absent() : Possible.of(scheduledStartTime_value);
  }

  /**
   * @return The value of the {@code scheduledEndTime} attribute
   */
  @Override
  public Possible<Instant> scheduledEndTime() {
    return scheduledEndTime_absent ? Possible.absent() : Possible.of(scheduledEndTime_value);
  }

  /**
   * @return The value of the {@code description} attribute
   */
  @Override
  public Possible<String> description() {
    return description_absent ? Possible.absent() : Possible.of(description_value);
  }

  /**
   * @return The value of the {@code entityType} attribute
   */
  @Override
  public Possible<ScheduledEvent.EntityType> entityType() {
    return entityType_absent ? Possible.absent() : Possible.of(entityType_value);
  }

  /**
   * @return The value of the {@code status} attribute
   */
  @Override
  public Possible<ScheduledEvent.Status> status() {
    return status_absent ? Possible.absent() : Possible.of(status_value);
  }

  /**
   * @return The value of the {@code image} attribute
   */
  @Override
  public Possible<Image> image() {
    return image_absent ? Possible.absent() : Possible.of(image_value);
  }

  /**
   * @return The value of the {@code event} attribute
   */
  @Override
  public ScheduledEvent event() {
    return event;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventEditMono#reason() reason} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for reason (can be {@code null})
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventEditMono withReason(@Nullable String value) {
    if (Objects.equals(this.reason, value)) return this;
    return new ScheduledEventEditMono(
        value,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withChannelId(Possible<Optional<Snowflake>> value) {
    Possible<Optional<Snowflake>> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditMono(
        this.reason,
        newValue,
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  @Deprecated
  public ScheduledEventEditMono withChannelId(@Nullable Snowflake value) {
    Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
    return new ScheduledEventEditMono(
        this.reason,
        newValue,
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withChannelIdOrNull(@Nullable Snowflake value) {
    Possible<Optional<Snowflake>> newValue = Possible.of(Optional.ofNullable(value));
    return new ScheduledEventEditMono(
        this.reason,
        newValue,
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withEntityMetadata(Possible<ScheduledEventEntityMetadataSpec> value) {
    Possible<ScheduledEventEntityMetadataSpec> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        newValue,
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withEntityMetadata(ScheduledEventEntityMetadataSpec value) {
    Possible<ScheduledEventEntityMetadataSpec> newValue = Possible.of(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        newValue,
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withName(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        newValue,
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withName(String value) {
    Possible<String> newValue = Possible.of(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        newValue,
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withPrivacyLevel(Possible<ScheduledEvent.PrivacyLevel> value) {
    Possible<ScheduledEvent.PrivacyLevel> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        newValue,
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withPrivacyLevel(ScheduledEvent.PrivacyLevel value) {
    Possible<ScheduledEvent.PrivacyLevel> newValue = Possible.of(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        newValue,
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withScheduledStartTime(Possible<Instant> value) {
    Possible<Instant> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        newValue,
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withScheduledStartTime(Instant value) {
    Possible<Instant> newValue = Possible.of(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        newValue,
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withScheduledEndTime(Possible<Instant> value) {
    Possible<Instant> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        newValue,
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withScheduledEndTime(Instant value) {
    Possible<Instant> newValue = Possible.of(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        newValue,
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withDescription(Possible<String> value) {
    Possible<String> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        newValue,
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withDescription(String value) {
    Possible<String> newValue = Possible.of(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        newValue,
        this.entityType(),
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withEntityType(Possible<ScheduledEvent.EntityType> value) {
    Possible<ScheduledEvent.EntityType> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        newValue,
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withEntityType(ScheduledEvent.EntityType value) {
    Possible<ScheduledEvent.EntityType> newValue = Possible.of(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        newValue,
        this.status(),
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withStatus(Possible<ScheduledEvent.Status> value) {
    Possible<ScheduledEvent.Status> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        newValue,
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withStatus(ScheduledEvent.Status value) {
    Possible<ScheduledEvent.Status> newValue = Possible.of(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        newValue,
        this.image(),
        this.event);
  }

  public ScheduledEventEditMono withImage(Possible<Image> value) {
    Possible<Image> newValue = Objects.requireNonNull(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        newValue,
        this.event);
  }

  public ScheduledEventEditMono withImage(Image value) {
    Possible<Image> newValue = Possible.of(value);
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        newValue,
        this.event);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ScheduledEventEditMono#event() event} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for event
   * @return A modified copy of the {@code this} object
   */
  public final ScheduledEventEditMono withEvent(ScheduledEvent value) {
    if (this.event == value) return this;
    ScheduledEvent newValue = Objects.requireNonNull(value, "event");
    return new ScheduledEventEditMono(
        this.reason,
        this.channelId(),
        this.entityMetadata(),
        this.name(),
        this.privacyLevel(),
        this.scheduledStartTime(),
        this.scheduledEndTime(),
        this.description(),
        this.entityType(),
        this.status(),
        this.image(),
        newValue);
  }

  /**
   * This instance is equal to all instances of {@code ScheduledEventEditMono} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof ScheduledEventEditMono
        && equalTo(0, (ScheduledEventEditMono) another);
  }

  private boolean equalTo(int synthetic, ScheduledEventEditMono another) {
    return Objects.equals(reason, another.reason)
        && this.channelId().equals(another.channelId())
        && this.entityMetadata().equals(another.entityMetadata())
        && this.name().equals(another.name())
        && this.privacyLevel().equals(another.privacyLevel())
        && this.scheduledStartTime().equals(another.scheduledStartTime())
        && this.scheduledEndTime().equals(another.scheduledEndTime())
        && this.description().equals(another.description())
        && this.entityType().equals(another.entityType())
        && this.status().equals(another.status())
        && this.image().equals(another.image())
        && event.equals(another.event);
  }

  /**
   * Computes a hash code from attributes: {@code reason}, {@code channelId}, {@code entityMetadata}, {@code name}, {@code privacyLevel}, {@code scheduledStartTime}, {@code scheduledEndTime}, {@code description}, {@code entityType}, {@code status}, {@code image}, {@code event}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(reason);
    h += (h << 5) + (channelId().hashCode());
    h += (h << 5) + (entityMetadata().hashCode());
    h += (h << 5) + (name().hashCode());
    h += (h << 5) + (privacyLevel().hashCode());
    h += (h << 5) + (scheduledStartTime().hashCode());
    h += (h << 5) + (scheduledEndTime().hashCode());
    h += (h << 5) + (description().hashCode());
    h += (h << 5) + (entityType().hashCode());
    h += (h << 5) + (status().hashCode());
    h += (h << 5) + (image().hashCode());
    h += (h << 5) + event.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code ScheduledEventEditMono} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "ScheduledEventEditMono{"
        + "reason=" + reason
        + ", channelId=" + (channelId().toString())
        + ", entityMetadata=" + (entityMetadata().toString())
        + ", name=" + (name().toString())
        + ", privacyLevel=" + (privacyLevel().toString())
        + ", scheduledStartTime=" + (scheduledStartTime().toString())
        + ", scheduledEndTime=" + (scheduledEndTime().toString())
        + ", description=" + (description().toString())
        + ", entityType=" + (entityType().toString())
        + ", status=" + (status().toString())
        + ", image=" + (image().toString())
        + ", event=" + event
        + "}";
  }

  /**
   * Construct a new immutable {@code ScheduledEventEditMono} instance.
   * @param event The value for the {@code event} attribute
   * @return An immutable ScheduledEventEditMono instance
   */
  public static ScheduledEventEditMono of(ScheduledEvent event) {
    return new ScheduledEventEditMono(event);
  }

  /**
   * Creates an immutable copy of a {@link ScheduledEventEditMonoGenerator} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable ScheduledEventEditMono instance
   */
  static ScheduledEventEditMono copyOf(ScheduledEventEditMonoGenerator instance) {
    if (instance instanceof ScheduledEventEditMono) {
      return (ScheduledEventEditMono) instance;
    }
    return ScheduledEventEditMono.of(instance.event())
        .withReason(instance.reason())
        .withChannelId(instance.channelId())
        .withEntityMetadata(instance.entityMetadata())
        .withName(instance.name())
        .withPrivacyLevel(instance.privacyLevel())
        .withScheduledStartTime(instance.scheduledStartTime())
        .withScheduledEndTime(instance.scheduledEndTime())
        .withDescription(instance.description())
        .withEntityType(instance.entityType())
        .withStatus(instance.status())
        .withImage(instance.image());
  }

  public boolean isChannelIdPresent() {
    return !channelId_absent;
  }

  public Snowflake channelIdOrElse(Snowflake defaultValue) {
    return !channelId_absent ? channelId_value : defaultValue;
  }

  public boolean isEntityMetadataPresent() {
    return !entityMetadata_absent;
  }

  public ScheduledEventEntityMetadataSpec entityMetadataOrElse(ScheduledEventEntityMetadataSpec defaultValue) {
    return !entityMetadata_absent ? entityMetadata_value : defaultValue;
  }

  public boolean isNamePresent() {
    return !name_absent;
  }

  public String nameOrElse(String defaultValue) {
    return !name_absent ? name_value : defaultValue;
  }

  public boolean isPrivacyLevelPresent() {
    return !privacyLevel_absent;
  }

  public ScheduledEvent.PrivacyLevel privacyLevelOrElse(ScheduledEvent.PrivacyLevel defaultValue) {
    return !privacyLevel_absent ? privacyLevel_value : defaultValue;
  }

  public boolean isScheduledStartTimePresent() {
    return !scheduledStartTime_absent;
  }

  public Instant scheduledStartTimeOrElse(Instant defaultValue) {
    return !scheduledStartTime_absent ? scheduledStartTime_value : defaultValue;
  }

  public boolean isScheduledEndTimePresent() {
    return !scheduledEndTime_absent;
  }

  public Instant scheduledEndTimeOrElse(Instant defaultValue) {
    return !scheduledEndTime_absent ? scheduledEndTime_value : defaultValue;
  }

  public boolean isDescriptionPresent() {
    return !description_absent;
  }

  public String descriptionOrElse(String defaultValue) {
    return !description_absent ? description_value : defaultValue;
  }

  public boolean isEntityTypePresent() {
    return !entityType_absent;
  }

  public ScheduledEvent.EntityType entityTypeOrElse(ScheduledEvent.EntityType defaultValue) {
    return !entityType_absent ? entityType_value : defaultValue;
  }

  public boolean isStatusPresent() {
    return !status_absent;
  }

  public ScheduledEvent.Status statusOrElse(ScheduledEvent.Status defaultValue) {
    return !status_absent ? status_value : defaultValue;
  }

  public boolean isImagePresent() {
    return !image_absent;
  }

  public Image imageOrElse(Image defaultValue) {
    return !image_absent ? image_value : defaultValue;
  }
}
